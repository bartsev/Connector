﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Windows.Forms;

namespace SMEV
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlDocument xmlRequest = new XmlDocument();
            xmlRequest.LoadXml(String.Format(SmevMessageParts.SEND_REQUEST_REQUEST, SmevMessageParts.IMPORT_PAYMENT_REQUEST));
            xmlRequest.Save("request.xml");
            MessageBox.Show() 


        }
    }
}
