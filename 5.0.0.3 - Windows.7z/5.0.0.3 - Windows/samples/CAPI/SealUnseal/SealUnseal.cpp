/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rigc_lhts, in and to the Code are and will remain with Aladdin.
//
//  3. Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4. No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

// standard includes
#include <windows.h>
#include <winscard.h>
#include <wincrypt.h>

//stl include
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

#define DES_BLOCK_SIZE 8 
#define BLOCK_SIZE  (2048 - (2048%DES_BLOCK_SIZE))
#define ET_PROVIDER "eToken Base Cryptographic Provider"
#define ET_PROVIDER_W L"eToken Base Cryptographic Provider"
#define ET_CERT_STORE L"MY\\eToken"
#define MY_CERT_STORE L"MY"

//Selected token CSP context handle.
HCRYPTPROV g_hCryptProvider;   

//Structure that include token certifcate detailes.
struct TOKEN_CERT_DETAILS
{
  BYTE          keyContainerName[MAX_PATH + 1];  //saved for sign operation.
  string        certificateName;
  vector<BYTE>  certValue;
  DWORD         keyType;

  TOKEN_CERT_DETAILS() { memset(&keyContainerName,0x00,sizeof(keyContainerName)); };
};

//Input/Output parameter structure.
struct SEALED_DATA
{
	vector<BYTE>  ReceiverCertValue;
  vector<BYTE>  SenderCertValue;
  BYTE          secret_key_iv[8]; 
	vector<BYTE>  wrappedKey;
  vector<BYTE>  signatureMessage;

  SEALED_DATA() { memset(&secret_key_iv,0x00,sizeof(secret_key_iv)); };
};

//Helper functions.
void seal(ifstream& hSourceFile, ofstream& hDestFile);
void unseal(ifstream& hSourceFile, ofstream& hDestFile);

void selectToken();

void enumTokenCertificates(vector<TOKEN_CERT_DETAILS>& certTokenRefList);
int  selectTokenCertificates(vector<TOKEN_CERT_DETAILS>& certRefList);

void enumCertStoreCertificates(vector<PCCERT_CONTEXT>& certCertStoreRefList);
int  selectCertStoreCertificates(vector<PCCERT_CONTEXT>& certCertStoreRefList);
void releaseCertStoreRefList(vector<PCCERT_CONTEXT>& certCertStoreRefList);

bool prepareReceiverSealHandles(HCRYPTPROV* hReceiverProv, HCRYPTKEY* hReceiverPubKey , SEALED_DATA* output);
bool prepareSignerSealHandles(HCRYPTPROV* hSignerKeyContainer, HCRYPTHASH* hHash , DWORD* signKeyType, SEALED_DATA* output);

bool prepareReceiverUnSealHandles(HCRYPTPROV* hReceiverProv, HCRYPTKEY* hReceiverPrvKey, SEALED_DATA* input);
bool prepareSenderUnSealHandles(HCRYPTPROV* hSenderProv, HCRYPTKEY* hSenderPubKey, DWORD* pubKeyLen, HCRYPTHASH* hHash, SEALED_DATA* input);

bool wrapSecretKey(HCRYPTPROV hReceiverProv, HCRYPTKEY hReceiverPubKey, HCRYPTKEY* hSecretKey, SEALED_DATA* output);
bool unwrapSecretKey(HCRYPTPROV hReceiverProv, HCRYPTKEY hReceiverPrvKey, HCRYPTKEY* hSecretKey, SEALED_DATA* input);

void displayCertificateName(const BYTE* certValue, DWORD certValueLen);
string getCertificateName(BYTE* certValue, int certValueLen);

void writeHeaderToFile(SEALED_DATA* output,ofstream& hFile);
void writeBlockToFile(BYTE* buf, DWORD bufLen, ofstream& hFile);
void writeVectorToFile(BYTE* buf, DWORD bufLen, ofstream& hFile);
void readHeaderFromFile(SEALED_DATA* input, ifstream& hFile);
void readBlockFromFile(BYTE* buf, DWORD bufLen, ifstream& hFile);
void readVectorFromFile(vector<BYTE>& buf, ifstream& hFile);
DWORD getFileSize(ifstream& hFile);

//Delete destination file when operation fails.
static string dest_file;
ofstream hDestFile;

//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	if(message)
	{
		hDestFile.close();
    DeleteFile(dest_file.c_str());
  }  
	printf("\n\n");
  printf("Press Enter key to exit");
  getchar();
  exit(message ? -1 : 0);
}

//
int main(int argc, char* argv[])
{
  if (argc != 4)
  {
    leave("Usage:\n"
          "   SealUnseal <seal/unseal operation> <source-file> <destination-file>\n"
          "     Example: SealUnseal seal source.txt dest.bin\n"); 
  }

  string operation   = argv[1];
  string source_file = argv[2];
  dest_file   = argv[3];

  cout<<"Command line params: "<<endl;
  cout<<" operation: "<<operation.c_str()<<endl;
  cout<<" source_file: "<<source_file.c_str()<<endl;
  cout<<" dest_file: "<<dest_file.c_str()<<endl;
  
  //Input file.
  ifstream hSourceFile(source_file.c_str(), ios::binary | ios::in);
  if (! hSourceFile.is_open())
  {
    leave ("Source file failed to be open.\n");
  }

  //Output file
  //ofstream hDestFile(dest_file.c_str(), ios::out | ios::binary);
  hDestFile.open(dest_file.c_str(), ios::out | ios::binary);
  if (! hDestFile.is_open())
  {
    leave ("Dest file failed to be open.\n");
  }

  std::transform(operation.begin(),operation.end(),operation.begin(),tolower);
  if (operation == "seal")
  {
    //Sample will be activated using the first token inserted.
    //If more than one token is inserted, a CAPI Select Token dialog box appears.
    selectToken();
    seal(hSourceFile,hDestFile);
  }
  if (operation == "unseal")
  {
    unseal(hSourceFile,hDestFile);
  }

  hSourceFile.close(); 
  hDestFile.close();

  //Close PKCS #11 library.
  leave(NULL);

  return 0;
}

//
//
void seal(ifstream& hSourceFile, ofstream& hDestFile)
{
  cout<<"\n>>>Start Seal Operation."<<endl;
  cout<<"     Enumerate eToken Certificate Store Certificates (Receiver Certificate)."<<endl; 
  cout<<"     Select Receiver Certificate (include Public key)."<<endl;
  
  cout<<"     Enumerate Token Certificates (Sender certificate)."<<endl; 
  cout<<"     Select Sender Certificate (include Private key)."<<endl;

  cout<<"     Create 3Des Secret Key."<<endl; 
  cout<<"     Set IV to 3Des Secret Key."<<endl;
  cout<<"     Export 3Des Secret Key using the Receiver Public Key."<<endl;
  
  cout<<"     Hash and encrypt message data using simple Secret Key."<<endl;
  cout<<"     Sign hashed data with sender Private Key."<<endl<<endl;

  //Output parameters structure.
  SEALED_DATA output;

  //Enumerate Certificate Store certifcates, select receiver certifcate and
  //acquire provider public key handle.
  HCRYPTPROV hReceiverProv = NULL; 
  HCRYPTKEY  hReceiverPubKey = NULL;
  if (! prepareReceiverSealHandles(&hReceiverProv, &hReceiverPubKey,&output))
  {
    ::CryptReleaseContext(g_hCryptProvider, 0);
    leave("prepareReceiverHandles Failed...");
  }

  //Enumerate Token certifcates, select sender certifcate
  //and acquire signer key container and hash object handles.
  HCRYPTPROV hSignerKeyContainer;
  HCRYPTHASH hHash;
  DWORD			 signKeyType;
  if (! prepareSignerSealHandles(&hSignerKeyContainer, &hHash, &signKeyType, &output))
  {
    ::CryptReleaseContext(hReceiverProv, 0);
    leave("prepareSignerHandles Failed...");
  }

  HCRYPTKEY  hSecretKey = NULL;
  if(! wrapSecretKey(hReceiverProv, hReceiverPubKey, &hSecretKey, &output))
  {
    ::CryptReleaseContext(hReceiverProv,NULL);
    ::CryptReleaseContext(hSignerKeyContainer, 0);
    leave("wrapSecretKey Failed...");
  }

  //Save header data to destination file.
  writeHeaderToFile(&output,hDestFile);

  //Read data from source file and encrypt with secret key.
  BYTE block_message[BLOCK_SIZE];
 
  DWORD fileSize = getFileSize(hSourceFile);
  while(fileSize > 0)
  {
    DWORD len = min(BLOCK_SIZE,fileSize);
    readBlockFromFile(block_message,len,hSourceFile);
    fileSize -= len; 
    
		if(! CryptHashData(hHash, block_message, len, 0)) 
    {
      ::CryptReleaseContext(hReceiverProv,NULL);
      ::CryptReleaseContext(hSignerKeyContainer,NULL);
      leave("CryptHashData failed ...");
    }

    DWORD ulEncryptedDataLen = len;
    if(!CryptEncrypt(hSecretKey, NULL, (fileSize == 0), 0, NULL, &ulEncryptedDataLen, 0))
    {
      ::CryptReleaseContext(hReceiverProv,NULL);
      ::CryptReleaseContext(hSignerKeyContainer,NULL);
      leave("CryptEncrypt failed to get size... \n"); 
    }
    
		vector<BYTE> encData;
    encData.resize(ulEncryptedDataLen);
    std::copy(block_message,block_message+len,encData.begin());
    if(!CryptEncrypt(hSecretKey, NULL, (fileSize == 0), 0, &encData[0], &len, encData.size()))
    {
      ::CryptReleaseContext(hReceiverProv,NULL);
      ::CryptReleaseContext(hSignerKeyContainer,NULL);
      leave("CryptEncrypt failed ... \n"); 
    }
    //Write encrypted data to file.
    writeBlockToFile(&encData[0],encData.size(),hDestFile);
  }
  cout<<"Hash and Encrypt Data by plain 3Des Secret Key succeeded."<<endl;
  
  //Release context will close all open handles.
  ::CryptReleaseContext(hReceiverProv,NULL);

  //Determine the size of the signature and allocate memory.
  DWORD dwSigLen = 0;
  if(!CryptSignHash(hHash, signKeyType, NULL, 0, NULL, &dwSigLen)) 
  {
    ::CryptReleaseContext(hSignerKeyContainer,NULL);
    leave("CryptSignHash Failed to get Signature length ...");
  }

  //Sign the hash object with sender .
  output.signatureMessage.resize(dwSigLen);
  if(! CryptSignHash(hHash, signKeyType, NULL, 0, &output.signatureMessage[0], &dwSigLen)) 
  {
    ::CryptReleaseContext(hSignerKeyContainer,NULL);
    leave("CryptSignHash Failed to get Signature ...");
  }
  //Release context will close all open handles.
  ::CryptReleaseContext(hSignerKeyContainer,NULL);

  //For compatibility with PKCS#11 big-endian, Microsoft works in little-endian mode.
  std::reverse(output.signatureMessage.begin(),output.signatureMessage.end());

  writeVectorToFile(&output.signatureMessage[0],output.signatureMessage.size(),hDestFile);
  cout<<"Sign Digest data with Sender Private Key succeeded."<<endl;

  hSourceFile.close();
  hDestFile.close();

  cout<<"\n>>>Seal Operation Succeeded.\n"<<endl;
}

//
//
void unseal(ifstream& hSourceFile, ofstream& hDestFile)
{
  cout<<"\n>>>Start UnSeal Operation."<<endl;
  cout<<"     Acquire Receiver Certificate Private Key provider handle."<<endl;
  cout<<"     Get Receiver Private Key handle."<<endl;
  cout<<"     Import Sender Public Key."<<endl;
  cout<<"     Add SIMPLEBLOB header to saved wrapped Secret Key."<<endl;
  cout<<"     Import wrapped Secret Key with Receiver Private Key handle."<<endl;
  cout<<"     Set IV to plain 3Des Secret Key."<<endl;
  cout<<"     Decrypt and hash encrypted data with simple 3Des secret key."<<endl; 
  cout<<"     Verify Signature with digest by Sender Public Key.\n"<<endl;
  
  //Input paramameter structure.
  SEALED_DATA input;
  readHeaderFromFile(&input,hSourceFile);

  //Find receiver certificate in certificate store and get receiver private key handle from certificate context.
  HCRYPTPROV hReceiverProv = NULL; 
  HCRYPTKEY  hReceiverPrvKey = NULL;
  if (! prepareReceiverUnSealHandles(&hReceiverProv, &hReceiverPrvKey, &input))
  {
    leave("prepareReceiverUnSealHandles failed ..."); 
  }

  //Import sender public key information from certificate context and 
  //create hash object.
  HCRYPTPROV     hSenderProv = NULL;
  HCRYPTHASH     hHash = NULL;
  HCRYPTKEY      hSenderPubKey = NULL;
  DWORD          pubKeyLen = 0;
  if (! prepareSenderUnSealHandles(&hSenderProv, &hSenderPubKey, &pubKeyLen, &hHash, &input))
  {
    ::CryptReleaseContext(hReceiverProv,NULL);
    leave("prepareSenderUnSealHandles failed ..."); 
  }

  HCRYPTKEY hSecretKey = NULL; 
  if (! unwrapSecretKey(hReceiverProv, hReceiverPrvKey, &hSecretKey, &input))
  {
    ::CryptReleaseContext(hReceiverProv,NULL);
    ::CryptReleaseContext(hSenderProv,NULL);
    leave("unwrapSecretKey failed ..."); 
  }
  ::CryptDestroyKey(hReceiverPrvKey);

  //Read data from source file, decrypt and digest with secret key.
  BYTE block_message[BLOCK_SIZE];
  DWORD fileSize = getFileSize(hSourceFile);

  //Calculate encrypted data size (file size minus read data plus signature value size).
  DWORD readed = hSourceFile.tellg(); //was read
  fileSize -= readed;
  fileSize -= sizeof(DWORD);          //4 bytes for signature length

  //Calculate signature value length.
  fileSize -= pubKeyLen/8; //signature value size

  //Read encrypted data from source file.
  while(fileSize > 0)
  {
    DWORD len = min(BLOCK_SIZE,fileSize);
    readBlockFromFile(block_message,len,hSourceFile);
    fileSize -= len; 

    DWORD ulDecryptedDataLen = len;
		if(!CryptDecrypt(hSecretKey, NULL,(fileSize == 0), 0, block_message, &ulDecryptedDataLen))
    {
      ::CryptReleaseContext(hSenderProv,NULL);
      leave("CryptDecrypt failed ... \n");
    }

		//Write message to destination file.
    writeBlockToFile(block_message,ulDecryptedDataLen,hDestFile);
    
    if(! CryptHashData(hHash, block_message, ulDecryptedDataLen, 0)) 
    {
      ::CryptReleaseContext(hSenderProv,NULL);
      leave("CryptHashData failed ...");
    }
  }
  cout<<"Decrypt and hash of read data succeeded."<<endl;
  ::CryptReleaseContext(hReceiverProv,NULL);

  readVectorFromFile(input.signatureMessage,hSourceFile);

  //Compare signature length to sender public key length.
  if (input.signatureMessage.size() != pubKeyLen/8)
  {
    ::CryptReleaseContext(hSenderProv,NULL);
    leave("Read wrong signature length...");
  }

  //For compatibility with Pkcs#11 big-endian, Microsoft works in littel-endian mode.
  std::reverse(input.signatureMessage.begin(),input.signatureMessage.end());

  //Verifiy both new and read signatures with sender public key.
  if( ! CryptVerifySignature(hHash, 
                             &input.signatureMessage[0],
                             input.signatureMessage.size(),
                             hSenderPubKey,
                             NULL,
                             0))
  {
    ::CryptReleaseContext(hSenderProv,NULL);
    leave("CryptVerifySignature failed ...");
  }
	cout<<"Verification of both signatures with sender public key succeeded."<<endl;
  ::CryptReleaseContext(hSenderProv,NULL);
  
  hSourceFile.close();
  hDestFile.close();
  cout<<"\n>>>UnSeal operation succeeded.\n"<<endl;
}

//Select token by acquiring a handle not a particular key container within eToken CSP. 
void selectToken()
{
  if (! ::CryptAcquireContext(&g_hCryptProvider, NULL, ET_PROVIDER, PROV_RSA_FULL, 0))
    leave("selectToken - CryptAcquireContext failed ...");
}

//Enumerate certificates existing on token.
void enumTokenCertificates(vector<TOKEN_CERT_DETAILS>& certTokenRefList)
{
  //Enumerate key containers(KCs) on selected token. 
	DWORD dwFlags = CRYPT_FIRST;
  BYTE keyContainerName[MAX_PATH + 1]; // Long enough for a KC name.

  for(DWORD len = sizeof(keyContainerName); ::CryptGetProvParam(g_hCryptProvider, PP_ENUMCONTAINERS, keyContainerName, &len, dwFlags); len = sizeof(keyContainerName))
	{
	  //Remove the CRYPT_FIRST flag, as only the first call to CryptGetProvParam should use it.
		dwFlags = 0;
			
		//Handle to the key container found.
    HCRYPTPROV hKeyProv = 0;
		if (::CryptAcquireContext(&hKeyProv, (char*)keyContainerName, ET_PROVIDER, PROV_RSA_FULL, 0))
		{
      //Get a handle to the key pair.
			HCRYPTKEY hKey = 0;
      char* keyType = "AT_KEYEXCHANGE";
      if (! ::CryptGetUserKey(hKeyProv, AT_KEYEXCHANGE, &hKey))
			{
			  keyType = "AT_SIGNATURE";
        ::CryptGetUserKey(hKeyProv, AT_SIGNATURE, &hKey);
			}
      if (hKey)
      {
        // Get certificate value from key handle.
				DWORD certValueLen;
				if (::CryptGetKeyParam(hKey, KP_CERTIFICATE, NULL, &certValueLen, 0))
        {  
          TOKEN_CERT_DETAILS certTokenDetiels;
          certTokenDetiels.certValue.resize(certValueLen);
          if (::CryptGetKeyParam(hKey, KP_CERTIFICATE, &certTokenDetiels.certValue[0], &certValueLen, 0))
					{
						//Save certificate and its key handles in list.
            std::copy(keyContainerName,keyContainerName+sizeof(keyContainerName),certTokenDetiels.keyContainerName);
            certTokenDetiels.certificateName = getCertificateName(&certTokenDetiels.certValue[0],certValueLen);
            if(keyType == "AT_KEYEXCHANGE")
              certTokenDetiels.keyType = AT_KEYEXCHANGE;
            else if(keyType == "AT_SIGNATURE")
              certTokenDetiels.keyType = AT_SIGNATURE;
            certTokenRefList.push_back(certTokenDetiels);
					}
				}
			
        //Destroy the handle to the key pair.
				::CryptDestroyKey(hKey);
			}
			
      //Destroy the handle to the key container.
			::CryptReleaseContext(hKeyProv, 0);
		}
	}

  //After CryptEnumProviders returns false, the error code should be ERROR_NO_MORE_ITEMS - indicating the enumeration succeeded, finding all key containers (otherwise an error has occurred).
	if (GetLastError() != ERROR_NO_MORE_ITEMS)
	{
		leave("CryptEnumProviders failed ... \n");
	}
}

//
//Display and select index for X_509 certificate.
int selectTokenCertificates(vector<TOKEN_CERT_DETAILS>& certTokenRefList)
{
  int numOfCerts = 0; 
  for (vector<TOKEN_CERT_DETAILS>::iterator p = certTokenRefList.begin() ; p != certTokenRefList.end() ; ++p , numOfCerts++)
	{
    //Use Windows Crypt32 API to parse certifcate that is written in ASN-1 format.
    cout<<"   #"<<numOfCerts<<" - ";
    displayCertificateName(&p->certValue[0],p->certValue.size());
    cout<<"   ("<<(p->keyType == AT_SIGNATURE ? "AT_SIGNATURE" :"AT_KEYEXCHANGE")<<")."<<endl; 
  }

  int certListIndex = -1;
  if (certTokenRefList.size() == 1)
  {
    certListIndex = 0; //First certificate in vector.
    cout<<"   Certificate #"<<certListIndex<<" was selected."<<endl<<endl;
    return certListIndex;
  }
  cout<<"Please type index: ";
  cin>>certListIndex;
  cout<<endl;

  if ((certListIndex < 0) || (certListIndex > certTokenRefList.size()-1))
  {
    leave("Wrong index was selected...");
  }
  return certListIndex;
}

//
//Save only eToken certificates from the certificate store.
void enumCertStoreCertificates(vector<PCCERT_CONTEXT>& certCertStoreRefList)
{
  HCERTSTORE hCertStore; //Handle to a certificate store.
  PCCERT_CONTEXT pCertContext = NULL; //Hold certificate context.
  
  //Open a handle to the certificate store.
  if ((hCertStore = ::CertOpenStore(CERT_STORE_PROV_SYSTEM, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, NULL, CERT_SYSTEM_STORE_CURRENT_USER, MY_CERT_STORE)) != NULL)
  {
		//Go over every certificate within the certificate store.
    while (((pCertContext = ::CertEnumCertificatesInStore(hCertStore, pCertContext)) != NULL))
    {
      DWORD dwSize = NULL; 
      CRYPT_KEY_PROV_INFO* pKeyInfo = NULL;
      if(!(CertGetCertificateContextProperty(pCertContext,CERT_KEY_PROV_INFO_PROP_ID, 
																						 NULL, &dwSize))) 
			{ 
				leave("CertGetCertificateContextProperty failed to get key property ..."); 
			} 
      if(!(pKeyInfo = (CRYPT_KEY_PROV_INFO*)malloc(dwSize))) 
      { 
        leave("Error allocating memory for pKeyInfo."); 
      } 

      if(!(CertGetCertificateContextProperty(pCertContext, CERT_KEY_PROV_INFO_PROP_ID, 
                                             pKeyInfo, &dwSize))) 
			{ 
				leave("CertGetCertificateContextProperty failed ..."); 
			} 

      if (wmemcmp(pKeyInfo->pwszProvName,ET_PROVIDER_W,wcslen(ET_PROVIDER_W)) == 0)
      {
				PCCERT_CONTEXT pDupCertContext;  
				if(pDupCertContext = CertDuplicateCertificateContext(pCertContext))
				{
					certCertStoreRefList.push_back(pDupCertContext);
				}
				else
					leave("enumCertStoreCertificates - CertDuplicateCertificateContext failed ...\n");
        
      } 
      free(pKeyInfo);
    }

		//Free the certificate context. (Only the last pCertContext returned should be freed, as CertEnumCertificatesInStore will free the previous ones).
    ::CertFreeCertificateContext(pCertContext);

		//Close the handle to eTCertStore.
    ::CertCloseStore(hCertStore,0);
  }
}

//
//Display the X_509 certificate and select the certifcate index.
int selectCertStoreCertificates(vector<PCCERT_CONTEXT>& certCertStoreRefList)
{
  int numOfCerts = 0; 
  for (vector<PCCERT_CONTEXT>::iterator ppCertContext = certCertStoreRefList.begin() ; ppCertContext != certCertStoreRefList.end() ; ++ppCertContext , numOfCerts++)
	{
    //Use Windows Crypt32 API to parse certifcates written in ASN-1 format.
    cout<<"   #"<<numOfCerts<<" - ";

    string certificateName = getCertificateName(((PCCERT_CONTEXT)*ppCertContext)->pbCertEncoded,
                                                ((PCCERT_CONTEXT)*ppCertContext)->cbCertEncoded);
    cout<<certificateName.c_str()<<endl;
  }

  int certListIndex = -1;
  if (certCertStoreRefList.size() == 1)
  {
    certListIndex = 0; //First certificate in vector.
    cout<<"   Certificate #"<<certListIndex<<" was selected."<<endl<<endl;
    return certListIndex;
  }
  cout<<"Please type index: ";
  cin>>certListIndex;
  cout<<endl;

  if ((certListIndex < 0) || (certListIndex > certCertStoreRefList.size()-1))
  {
    leave("Wrong index was selected...");
  }
  return certListIndex;
}

//
bool prepareReceiverSealHandles(HCRYPTPROV* hReceiverProv, HCRYPTKEY* hReceiverPubKey , SEALED_DATA* output)
{
  //Enumerate certificate store certificates for receiver certificate.
  vector<PCCERT_CONTEXT> certCertStoreRefList;  
  enumCertStoreCertificates(certCertStoreRefList); 
  if (certCertStoreRefList.size() == 0)
  {
    cout<<"Receiver certificate was not found in Cert Store ..."<<endl;  
    return false;
  }
  //Select receiver certificate with public key to encrypt 3Des secret key.
  cout<<"\nSelect Receiver certificate from eToken Cert Store Certificates List: "<<endl;
  int certStoreRefListIndex = selectCertStoreCertificates(certCertStoreRefList);

  //Save receiver selected certificate value. 
  std::copy(certCertStoreRefList[certStoreRefListIndex]->pbCertEncoded,
            certCertStoreRefList[certStoreRefListIndex]->pbCertEncoded + 
            certCertStoreRefList[certStoreRefListIndex]->cbCertEncoded,
            inserter(output->ReceiverCertValue,output->ReceiverCertValue.begin()));
  cout<<"Successfully got receiver certificates from the certificate store."<<endl;

  //Create receiver's temporary key container (any provider can be chosen).
  if(! CryptAcquireContext(hReceiverProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
  {
    releaseCertStoreRefList(certCertStoreRefList);
    cout<<"CryptAcquireContext failed ..."<<endl;
    return false;
  }

  if (!CryptImportPublicKeyInfo(*hReceiverProv,
																X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
																&certCertStoreRefList[certStoreRefListIndex]->pCertInfo->SubjectPublicKeyInfo,
																hReceiverPubKey))
  {
    ::CryptReleaseContext(*hReceiverProv,NULL);
    releaseCertStoreRefList(certCertStoreRefList);
    cout<<"CryptImportPublicKeyInfo failed ..."<<endl;
    return false;
  }
  releaseCertStoreRefList(certCertStoreRefList);
  cout<<"Import receiver public key information succeeded."<<endl;
  return true;
}

//
bool prepareSignerSealHandles(HCRYPTPROV* hSignerKeyContainer, HCRYPTHASH* hHash , DWORD* signKeyType, SEALED_DATA* output)
{
  //Enumerate token certificates to get the sender certificate.
  vector<TOKEN_CERT_DETAILS> certTokenRefList;  
  enumTokenCertificates(certTokenRefList); 
  if (certTokenRefList.size() == 0)
  {
    cout<<"Sender certificates were not found on the token ..."<<endl;  
    return false;
  }
  ::CryptReleaseContext(g_hCryptProvider, 0);

  //Select sender certificate including private key to sign hash data.
  cout<<"\nSelect sender certificate from certificate list: "<<endl;
  int certTokenRefListIndex = selectTokenCertificates(certTokenRefList);

  //Save sender selected certificate value. 
  output->SenderCertValue = certTokenRefList[certTokenRefListIndex].certValue;
  cout<<"Get sender certificates from token succeeded."<<endl;

  //Create signer key container and use it in hash object handle.
  //Using this key container causes the sign operation to use the sender private key.
  if (! ::CryptAcquireContext(hSignerKeyContainer,(char*)certTokenRefList[certTokenRefListIndex].keyContainerName, ET_PROVIDER, PROV_RSA_FULL, 0))
  {
    cout<<"selectToken - CryptAcquireContext failed ..."<<endl;
    return false;
  }
  
  if(! CryptCreateHash(*hSignerKeyContainer,CALG_SHA1, 0, 0, hHash)) 
  {
    cout<<"CryptCreateHash failed..."<<endl;
    return false;
  }
  
  *signKeyType = certTokenRefList[certTokenRefListIndex].keyType;
  return true;
}

//
bool prepareReceiverUnSealHandles(HCRYPTPROV* hReceiverProv, HCRYPTKEY* hReceiverPrvKey, SEALED_DATA* input)
{
  //Enumerate key containers(KCs) on selected token to find receiver certificate. 
	DWORD dwFlags = CRYPT_FIRST;
  BYTE keyContainerName[MAX_PATH + 1]; // Long enough for a KC name.

  selectToken();
  for(DWORD len = sizeof(keyContainerName); ::CryptGetProvParam(g_hCryptProvider, PP_ENUMCONTAINERS, keyContainerName, &len, dwFlags); len = sizeof(keyContainerName))
	{
		dwFlags = 0;
		if (::CryptAcquireContext(hReceiverProv, (char*)keyContainerName, ET_PROVIDER, PROV_RSA_FULL, 0))
		{
      //Get a handle to an exchange key pair.
			if (::CryptGetUserKey(*hReceiverProv, AT_KEYEXCHANGE, hReceiverPrvKey))
			{
        // Get a certificate value.
				DWORD certValueLen;
				if (::CryptGetKeyParam(*hReceiverPrvKey, KP_CERTIFICATE, NULL, &certValueLen, 0))
        {  
          vector<BYTE> certValue(certValueLen);
          if (::CryptGetKeyParam(*hReceiverPrvKey, KP_CERTIFICATE, &certValue[0], &certValueLen, 0))
					{
						if(memcmp(&certValue[0], &input->ReceiverCertValue[0], certValue.size()) == 0)
						{
							break;
						}
					}
				}
			  ::CryptDestroyKey(*hReceiverPrvKey); //Destroy the handle to the key pair.
        *hReceiverPrvKey = NULL;
			}
			::CryptReleaseContext(*hReceiverProv, 0); //Destroy the handle to the key container.
      *hReceiverProv = NULL;
		}
	}
  ::CryptReleaseContext(g_hCryptProvider, 0);

  if(!*hReceiverProv) 
  {
    cout<<"Receiver certificate was not found on the token..."<<endl; 
    return false; 
  }
  if(!*hReceiverPrvKey) 
  {
    cout<<"Receiver AT_KEYEXCHANGE was not found on the token..."<<endl; 
    return false; 
  }

  cout<<"Get receiver certificate private Key succeeded."<<endl;
  return true;
}

//
bool prepareSenderUnSealHandles(HCRYPTPROV* hSenderProv, HCRYPTKEY* hSenderPubKey, DWORD* pubKeyLen, HCRYPTHASH* hHash, SEALED_DATA* input)
{
  //Create temporary key container (any provider can be chosen).
  if(! CryptAcquireContext(hSenderProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
  {
    cout<<"CryptAcquireContext sender provider failed ..."<<endl;
    return false;
  }

  //Create hash object handle.
  if(! CryptCreateHash(*hSenderProv, CALG_SHA1, 0, 0, hHash)) 
  {
    ::CryptReleaseContext(*hSenderProv,NULL);
    cout<<"CryptCreateHash failed..."<<endl;
    return false; 
  }

  // Create a new certificate using the sender certificate value.
   PCCERT_CONTEXT pSenderCertContext = NULL; 
  if(!(pSenderCertContext = CertCreateCertificateContext((PKCS_7_ASN_ENCODING | X509_ASN_ENCODING),
                                                   &input->SenderCertValue[0],
                                                   input->SenderCertValue.size())))
  {
    ::CryptDestroyHash(*hHash);
    ::CryptReleaseContext(*hSenderProv,NULL);
    cout<<"CertCreateCertificateContext failed ..."<<endl;
    return false; 
  }
  
  //Import sender public key.
  if (!CryptImportPublicKeyInfo(*hSenderProv,
																X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
																&pSenderCertContext->pCertInfo->SubjectPublicKeyInfo,
																hSenderPubKey))
  {
    ::CryptReleaseContext(*hSenderProv,NULL);
    ::CertFreeCertificateContext(pSenderCertContext);
    cout<<"CryptImportPublicKeyInfo failed ..."<<endl;
    return false; 
  }
  
  if(! (*pubKeyLen = CertGetPublicKeyLength((PKCS_7_ASN_ENCODING | X509_ASN_ENCODING),
                                            &pSenderCertContext->pCertInfo->SubjectPublicKeyInfo)))
  {
    ::CryptReleaseContext(*hSenderProv,NULL);
    ::CertFreeCertificateContext(pSenderCertContext);
    cout<<"CertCreateCertificateContext failed ..."<<endl;
    return false; 
  }
  ::CertFreeCertificateContext(pSenderCertContext);
  return true;
}

bool wrapSecretKey(HCRYPTPROV hReceiverProv, HCRYPTKEY hReceiverPubKey, HCRYPTKEY* hSecretKey, SEALED_DATA* output)
{
  //Generate a 3Des secret key.
  if(!CryptGenKey(hReceiverProv, CALG_3DES, CRYPT_EXPORTABLE, hSecretKey))
  {
    cout<<"CryptGenKey failed ..."<<endl;
    return false;
  }
  cout<<"Generate 3Des secret key succeeded."<<endl;

  //Generate a random initialization vector.
  if(!CryptGenRandom(hReceiverProv, sizeof(output->secret_key_iv), output->secret_key_iv)) 
  {
    cout<<"CryptGenRandom initialization vector failed ..."<<endl;
    return false;
  }

  //Set the initialization vector.
  if(!CryptSetKeyParam(*hSecretKey, KP_IV, output->secret_key_iv, 0)) 
  {
    cout<<"CryptSetKeyParam initialization vector failed ..."<<endl;
    return false;
  }
  cout<<"Set IV to 3Des secret key succeeded."<<endl;

  //Export secret key with receiver public key.
  DWORD dwBlobLen;
  vector<BYTE> wrappedKey;
  if(! CryptExportKey(*hSecretKey, hReceiverPubKey, SIMPLEBLOB, 0, NULL, &dwBlobLen)) 
  {
    cout<<"CryptExportKey failed to get BLOB size..."<<endl;
    return false;
  }
  
  // Export secret key into the key BLOB.
  wrappedKey.resize(dwBlobLen); 
  if(! CryptExportKey(*hSecretKey,hReceiverPubKey,SIMPLEBLOB,0,&wrappedKey[0],&dwBlobLen)) 
  {
    cout<<"CryptExportKey failed ..."<<endl;
    return false;
  }
  cout<<"Export of 3Des secret key with receiver public key succeeded."<<endl;

  //3Des secret key was exported as SIMPLEBLOB.
  // SIMPLEBLOB format is:
  //    PUBLICKEYSTRUC  publickeystruc,
  //    ALG_ID algid,
  //    BYTE encryptedkey[rsapubkey.bitlen/8];
  const BYTE * pEnckey = reinterpret_cast<const BYTE*>(&wrappedKey[0] + sizeof(PUBLICKEYSTRUC) + sizeof(ALG_ID));
  int wrapedSecretKeyLen = wrappedKey.size() - sizeof(PUBLICKEYSTRUC) - sizeof(ALG_ID);
  std::copy(pEnckey,pEnckey+wrapedSecretKeyLen,inserter(output->wrappedKey,output->wrappedKey.begin()));
  
  //For compatibility with Pkcs#11 big-endian, Microsoft works in little-endian mode.
  std::reverse(output->wrappedKey.begin(),output->wrappedKey.end());

  return true;
}

bool unwrapSecretKey(HCRYPTPROV hReceiverProv, HCRYPTKEY hReceiverPrvKey, HCRYPTKEY* hSecretKey, SEALED_DATA* input)
{
  //3Des secret key was exported as SIMPLEBLOB.
  // SIMPLEBLOB format is:
  //    PUBLICKEYSTRUC  publickeystruc,
  //    ALG_ID algid,
  //    BYTE encryptedkey[rsapubkey.bitlen/8];
  vector <BYTE> wrappedKey;
  int wrapedSecretKeyLen = sizeof(PUBLICKEYSTRUC) + sizeof(ALG_ID) + input->wrappedKey.size();

  //For compatibility with Pkcs#11 big-endian, Microsoft works in little-endian mode.
  std::reverse(input->wrappedKey.begin(),input->wrappedKey.end());

  //Create a SIMPLEBLOB header and add it to a saved wrapped secret key.
  PUBLICKEYSTRUC pubKeyStruct = {SIMPLEBLOB,CUR_BLOB_VERSION,0,CALG_3DES};
  ALG_ID algid = CALG_RSA_KEYX;
  std::copy((BYTE*)&pubKeyStruct,(BYTE*)&pubKeyStruct+sizeof(PUBLICKEYSTRUC),inserter(wrappedKey,wrappedKey.begin()));
  std::copy((BYTE*)&algid,(BYTE*)&algid+sizeof(ALG_ID),inserter(wrappedKey,wrappedKey.end()));
  std::copy(input->wrappedKey.begin(),input->wrappedKey.end(),inserter(wrappedKey,wrappedKey.end()));

  //Import wrapped secret key with receiver private key and get simple secret key.
  if(! CryptImportKey(hReceiverProv, &wrappedKey[0], wrappedKey.size(), hReceiverPrvKey, SIMPLEBLOB, hSecretKey)) 
  {
    cout<<"CryptImportKey failed..."<<endl;
    return false;
  }
  cout<<"Import of wrapped secret key with receiver private key succeeded."<<endl;

  //Set the initialization vector.
  if(!CryptSetKeyParam(*hSecretKey, KP_IV, input->secret_key_iv, 0)) 
  {
    cout<<"CryptSetKeyParam initialization vector failed ..."<<endl;
    return false;
  }
  cout<<"Set IV to simple 3Des secret key succeeded."<<endl;
  return true;
}

//
void releaseCertStoreRefList(vector<PCCERT_CONTEXT>& certCertStoreRefList)
{
  for (vector<PCCERT_CONTEXT>::iterator ppCertContext = certCertStoreRefList.begin() ; ppCertContext != certCertStoreRefList.end() ; ++ppCertContext)
	{
    CertFreeCertificateContext(*ppCertContext);
  }
}

//
//Use Windows Crypt32 API to parse the certificate with ASN-1 format.
string getCertificateName(BYTE* certValue, int certValueLen)
{
	char pszNameString[256]; 
	PCCERT_CONTEXT pCertContext = NULL; 

  //Create certificate context.
  if(pCertContext = CertCreateCertificateContext( PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
																									certValue,
																									certValueLen))
	{
		//Get certificate friendly name.
    if (CertGetNameString(pCertContext, 
													CERT_NAME_SIMPLE_DISPLAY_TYPE, 
                          CERT_NAME_ISSUER_FLAG,
													NULL,   
													pszNameString,   
													sizeof(pszNameString)) == 0)
		{
      sprintf(pszNameString,"No Common Name", strlen("No Common Name"));
		}

		// When finished, free the certificate context.
		CertFreeCertificateContext(pCertContext);
	}
  return pszNameString;
}

//Use Windows Crypt32 API to parse the certificate with ASN-1 format.
void displayCertificateName(const BYTE* certValue, DWORD certValueLen)
{
	//Create certificate context.
	PCCERT_CONTEXT pCertContext = NULL; 
  if(pCertContext = CertCreateCertificateContext( PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
																									certValue,
																									certValueLen))
	{
		string certificateName = getCertificateName(pCertContext->pbCertEncoded,pCertContext->cbCertEncoded);
    cout<<certificateName.c_str();

  	// When finished, free the certificate context.
		CertFreeCertificateContext(pCertContext);
	}
}

/*
  Input/Output File Format:

  Header:
  4 Bytes-LE	Receiver Certificate length
	L Bytes-BE	Receiver Certificate value
	4 Bytes-LE	Sender Certificate length
	L Bytes-BE	Sender Certificate value
  4 Bytes-LE	Secret Key IV length
	L Bytes-BE	Secret Key IV value
	4 Bytes-LE	Wrap key length
	L Bytes-BE	Wrap key value

  EncryptedData:
  L Bytes-BE	Encrypt original message value (length will be calculated in the read operation).
  
  Signature:
  4 Bytes-LE	Signature length
	L Bytes-BE	Signature value
*/

//
//
void writeHeaderToFile(SEALED_DATA* output,ofstream& hFile)
{
  writeVectorToFile(&output->ReceiverCertValue[0],
                    output->ReceiverCertValue.size(),
                    hFile);
  writeVectorToFile(&output->SenderCertValue[0],
                    output->SenderCertValue.size(),
										hFile);
  writeVectorToFile(output->secret_key_iv, sizeof(output->secret_key_iv),hFile);
  writeVectorToFile(&output->wrappedKey[0],output->wrappedKey.size(),hFile);
}

//
//
void writeBlockToFile(BYTE* buf,DWORD bufLen, ofstream& hFile)
{
  if(!bufLen) return;

  DWORD len = bufLen;
  hFile.write((char*)buf,len);
  
  if (hFile.fail())
  {
    hFile.close();
    leave("writeBlockToFile failed ...");
  }
}

//
//
void writeVectorToFile(BYTE* buf, DWORD bufLen, ofstream& hFile)
{
  DWORD len = bufLen;
  hFile.write((char*)&len,sizeof(DWORD));
  hFile.write((char*)buf,len);
  
  if (hFile.fail())
  {
    hFile.close();
    leave("writeVectorToFile failed ...");
  }
}

//
//
void readHeaderFromFile(SEALED_DATA* input, ifstream& hFile)
{
  readVectorFromFile(input->ReceiverCertValue,hFile);  
  readVectorFromFile(input->SenderCertValue,hFile);
  
  vector<BYTE> iv;  
  readVectorFromFile(iv,hFile);
  copy(iv.begin(),iv.begin() + iv.size(),input->secret_key_iv);

  readVectorFromFile(input->wrappedKey,hFile);
}

//
//
void readBlockFromFile(BYTE* buf,DWORD bufLen, ifstream& hFile)
{
  DWORD len = bufLen;
  hFile.read((char*)buf,len);
  
  if (hFile.fail())
  {
    hFile.close();
    leave("readBlockFromFile failed ...");
  }
}

//
//
void readVectorFromFile(vector<BYTE>& buf, ifstream& hFile)
{
  //get length and resize vector
  DWORD len;
  hFile.read((char*)&len,sizeof(DWORD));
  buf.resize(len);

  //read data
  hFile.read((char*)&buf[0],len);
  
  if (hFile.fail())
  {
    hFile.close();
    leave("readVectorFromFile failed ...");
  }
}

//
//File size is the last offset, get it and return to the current offset. 
DWORD getFileSize(ifstream& hFile)
{
  DWORD fileSize = 0;
  long currentOffset = hFile.tellg();

  hFile.seekg (0, ios::end);
  long end = hFile.tellg();

  hFile.seekg(currentOffset);

  if(!hFile.fail())
  {
    fileSize = end;
  }
  else
  {
    hFile.close();
    leave("getFileSize failed ...");
  }

  if(fileSize <= 0)
  {
    leave ("Input file empty.\n");
  }
  return fileSize;
}