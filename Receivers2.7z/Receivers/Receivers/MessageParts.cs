﻿using System;
using System.Xml.Serialization;

namespace SMEVPaymentReceivers
{
    public static class SMEVMessageParts
    {
        public const string MessageHeader =
            "<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                "xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" " +
                "xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" +
            "<env:Header>" +
            "<wsse:Security env:actor=\"http://smev.gosuslugi.ru/actors/smev\">" +
                "<ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">" +
                    "<ds:KeyInfo>" +
                        "<wsse:SecurityTokenReference>" +
                            "<wsse:Reference URI=\"#SenderCertificate\" />" +
                        "</wsse:SecurityTokenReference>" +
                    "</ds:KeyInfo>" +
                "</ds:Signature>" +
                "<wsse:BinarySecurityToken EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\" " +
                       "ValueType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3\" " +
                       "wsu:Id=\"SenderCertificate\">" +
                "</wsse:BinarySecurityToken>" +
            "</wsse:Security>" +
        "</env:Header>" +
        "<env:Body xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" " +
            "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" wsu:Id=\"body\">";

        public const string PaymentReceiversRequest =
            "<rev:exportPaymentReceiverRequest xmlns:rev=\"http://smev.gosuslugi.ru/rev120315\">" +
                "<rev:Message>" +
                        "<rev:Sender>" +
                            "<rev:Code>RCPT00001</rev:Code>" +
                            "<rev:Name>Получатель</rev:Name>" +
                        "</rev:Sender>" +
                        "<rev:Recipient>" +
                            "<rev:Code>MNSV10001</rev:Code>" +
                            "<rev:Name>Минкомсвязь РФ</rev:Name>" +
                        "</rev:Recipient>" +
                        "<rev:ServiceName>MNSV10payGKH</rev:ServiceName>" +
                        "<rev:TypeCode>GFNC</rev:TypeCode>" +
                        "<rev:Status>REQUEST</rev:Status>" +
                        "<rev:Date>2018-06-28T10:00:00</rev:Date>" +
                        "<rev:ExchangeType>2</rev:ExchangeType>" +
                    "</rev:Message>" +
                    "<rev:MessageData>" +
                        "<rev:AppData>" +
                            "<rev:PaymentReceiversRequest>" +
                                "<rev:Full>true</rev:Full>" +
                            "</rev:PaymentReceiversRequest>" +
                        "</rev:AppData>" +
                    "</rev:MessageData>" +
                "</rev:exportPaymentReceiverRequest>" +
            "</env:Body>" +
        "</env:Envelope>";

        public const string PaymentReceiversStatus =
            "<rev:getStateRequest xmlns:rev=\"http://smev.gosuslugi.ru/rev120315\">" +
                "<rev:Message>" +
                    "<rev:Sender>" +
                        "<rev:Code>RCPT00001</rev:Code>" +
                        "<rev:Name>Получатель</rev:Name>" +
                    "</rev:Sender>" +
                    "<rev:Recipient>" +
                        "<rev:Code>MNSV10001</rev:Code>" +
                        "<rev:Name>Минкомсвязь РФ</rev:Name>" +
                    "</rev:Recipient>" +
                    "<rev:ServiceName>MNSV10payGKH</rev:ServiceName>" +
                    "<rev:TypeCode>GFNC</rev:TypeCode>" +
                    "<rev:Status>PING</rev:Status>" +
                    "<rev:Date>2018-06-28T00:00:00</rev:Date>" +
                    "<rev:ExchangeType>2</rev:ExchangeType>" +
                "</rev:Message>" +
                "<rev:MessageData>" +
                    "<rev:AppData>" +
                        "<rev:AcknowledgmentRequest>" +
                            "<rev:MessageGUID></rev:MessageGUID>" +
                        "</rev:AcknowledgmentRequest>" +
                    "</rev:AppData>" +
                "</rev:MessageData>" +
            "</rev:getStateRequest>" +
        "</env:Body>" +
    "</env:Envelope>";

    }

    [XmlRoot("Envelope", Namespace="http://schemas.xmlsoap.org/soap/envelope/")]
    public class Envelope<T>
    {
        public HeaderType Header;
        public BodyType Body;

        public Envelope()
        {
            this.Header = new HeaderType();
            this.Body = new BodyType();
        }
    }

    public class HeaderType
    {
        [XmlElement("Security", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
        public SecurityType Security;

        public HeaderType()
        {
            this.Security = new SecurityType();
        }
    }

    public class SecurityType
    {
        [XmlAttribute("actor", Namespace = "http://smev.gosuslugi.ru/rev120315")]
        public string actor = "http://smev.gosuslugi.ru/actors/smev";
        [XmlElement("BinarySecurityToken", Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")]
        public BinarySecurityTokenType BinarySecurityToken;
        [XmlElement("Signature", Namespace = "http://www.w3.org/2000/09/xmldsig#")]
        public SignatureType Signature;

        public SecurityType()
        {
            this.BinarySecurityToken = new BinarySecurityTokenType();
            this.Signature = new SignatureType();
        }
    }

    public class BinarySecurityTokenType
    {
        [XmlAttribute(Namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd")]
        public string Id = "SenderCertificate";
        [XmlAttribute]
        public string ValueType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3";
        [XmlAttribute]
        public string EncodingType = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary";

        public BinarySecurityTokenType() { }
    }

    public class SignatureType
    {
        KeyInfoType KeyInfo;
        public SignatureType()
        {
            this.KeyInfo = new KeyInfoType();
        }
    }

    public class KeyInfoType
    {
        public SecurityTokenReferenceType SecurityTokenReference;
        public KeyInfoType()
        {
            this.SecurityTokenReference = new SecurityTokenReferenceType();
        }
    }
        
    public class SecurityTokenReferenceType
    {
        public ReferenceType Reference;  
        public SecurityTokenReferenceType()
        {
            this.Reference = new ReferenceType();
        }
    }

    public class ReferenceType
    {
        [XmlAttribute]
        public string URI = "#SenderCertificate";
        public ReferenceType() { }
    }

    public class BodyType
    {
        [XmlElement("exportPaymentReceiverRequest", Namespace = "http://smev.gosuslugi.ru/rev120315")]
        public exportPaymentReceiverRequest exportPaymentReceiverRequest;

        public BodyType() { }
    }

    public abstract class SoapRequest { }

    public class exportPaymentReceiverRequest: SoapRequest
    {
        public MessageType Message;
        public MessageDataType MessageData;

        public exportPaymentReceiverRequest()
        {

        }

    }

    public class OrgExternalType
    {
        public string Code;
        public string Name;

        public OrgExternalType() { }

        public OrgExternalType(string Code, string Name)
        {
            this.Code = Code;
            this.Name = Name;
        }
    }

    public class MessageType
    {
        public OrgExternalType Sender;
        public OrgExternalType Recipient;
        public string ServiceName;
        public string TypeCode;
        public string Status;
        public string Date;
        public string ExchangeType;

        public MessageType() { }

        public MessageType(string ServiceName, string TypeCode, string Status, string ExchangeType)
        {
            Date = DateTime.Now.ToString("s");
            this.ServiceName = ServiceName;
            this.TypeCode = TypeCode;
            this.Status = Status;
            this.ExchangeType = ExchangeType;
        }

    }

    public class MessageDataType
    {
        public AppDataType AppData;

        public MessageDataType()
        {
            AppData = new AppDataType();
        }
    }

    public class AppDataType
    {
        [XmlAnyElement("PaymentReceiversRequest")]
        public PaymentReceiversRequestType PaymentReceiversRequest;

        public AppDataType()
        {
//            PaymentReceiversRequest = new PaymentReceiversRequestFull();
        }
        public AppDataType(PaymentReceiversRequestType PaymentReceiversRequest)
        {
            this.PaymentReceiversRequest = PaymentReceiversRequest;
        }
    }

    public class PaymentReceiversRequestType
    {
        public PaymentReceiversRequestType() { }
    }
 
    public class PaymentReceiversRequestFull: PaymentReceiversRequestType
    {
        public bool Full = true;

        public PaymentReceiversRequestFull() { }
    }
  
    public class PaymentReceiversRequestCurrentDate: PaymentReceiversRequestType
    {
        public bool CurentDate = true;

        public PaymentReceiversRequestCurrentDate() { }
    }
  
    public class PaymentReceiversRequestByDate: PaymentReceiversRequestType
    {
        public static DateTime ByDate;

        public PaymentReceiversRequestByDate()
        {
//            ByDate = new DateTime();
        }

        public PaymentReceiversRequestByDate(int Year, int Month, int Day)
        {
            ByDate = new DateTime(Year, Month, Day);
        }
    }
}
