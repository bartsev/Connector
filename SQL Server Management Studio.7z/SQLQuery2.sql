USE [CurrRates]
GO

/****** Object:  Table [dbo].[SBP_audit]    Script Date: 20.02.2021 11:27:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SBP_audit](
	[f_audit] [int] IDENTITY(1,1) NOT NULL,
	[date_time] [datetime] NOT NULL,
	[c_proc] [int] NOT NULL,
	[id_client] [int] NOT NULL,
	[note] [varchar](2048) NOT NULL,
 CONSTRAINT [PK_SBP_Agree_Log] PRIMARY KEY CLUSTERED 
(
	[f_audit] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SBP_audit] ADD  CONSTRAINT [DF_SBP_Agree_Log_date_time]  DEFAULT (getdate()) FOR [date_time]
GO


