﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.IO.Compression;
using System.Data.OleDb;
using System.Xml.Serialization;

namespace SMEVPaymentReceivers
{
    class Program
    {
        static string guid;

        static void Main(string[] args)
        {

            OrgExternalType Sender = new OrgExternalType("RCPT00001", "Получатель");
            OrgExternalType Recipient = new OrgExternalType("MNSV10001", "Минкомсвязь РФ");
            MessageType message = new MessageType("MNSV10payGKH", "GFNC", "REQUEST", "2");
            message.Sender = Sender;
            message.Recipient = Recipient;
            PaymentReceiversRequestFull request = new PaymentReceiversRequestFull();
            AppDataType data = new AppDataType(new PaymentReceiversRequestFull());
//            data.PaymentReceiversRequest = request;
//            PaymentReceiversRequestCurrentDate request = new PaymentReceiversRequestCurrentDate();
/*
            AppDataType<PaymentReceiversRequestFull> AppData = new AppDataType<PaymentReceiversRequestFull>();
            AppData.PaymentReceiversRequest = request;
            MessageDataType<PaymentReceiversRequestFull> MessageData = new MessageDataType<PaymentReceiversRequestFull>();
            MessageData.AppData = AppData;
            exportPaymentReceiverRequest< PaymentReceiversRequestFull> ReceiverRequest = new exportPaymentReceiverRequest<PaymentReceiversRequestFull>();
            ReceiverRequest.Message = message;
            ReceiverRequest.MessageData = MessageData;
            BodyType<PaymentReceiversRequestFull> body = new BodyType<PaymentReceiversRequestFull>();
            body.exportPaymentReceiverRequest = ReceiverRequest;
            HeaderType header = new HeaderType();
            Envelope<PaymentReceiversRequestFull> envelope = new Envelope<PaymentReceiversRequestFull>();
            envelope.Header = header;
            envelope.Body = body;
*/
            XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
            xmlNamespaces.Add("rev", "http://smev.gosuslugi.ru/rev120315");
            xmlNamespaces.Add("env", "http://schemas.xmlsoap.org/soap/envelope/");
            xmlNamespaces.Add("wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
            xmlNamespaces.Add("wsu", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");
            xmlNamespaces.Add("ws", "http://www.w3.org/2000/09/xmldsig#");

            XmlTypeMapping myTypeMapping = new SoapReflectionImporter().ImportTypeMapping(typeof(AppDataType));
            XmlSerializer formatter = new XmlSerializer(myTypeMapping);
//            XmlSerializer formatter = new XmlSerializer(typeof(AppDataType), "http://smev.gosuslugi.ru/rev120315");

            // получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream("message.xml", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, data, xmlNamespaces);

                Console.WriteLine("Объект сериализован");
                Console.ReadKey();
            }
            return;

            X509Certificate2 cert = LoadCertificate("bartsev@mail.ru");

            if (cert == null)
            {
                Console.WriteLine("Certificate not found");
                Console.ReadKey();
                return;
            }

            if (!SendRequest(cert))
            {
                Console.WriteLine("SendRequest fails");
                Console.ReadKey();
                return;
            }

            if (!SendStatus(cert))
            {
                Console.WriteLine("SendStatus fails");
                Console.ReadKey();
                return;
            }

            Console.ReadKey();

        }

        static bool SendRequest(X509Certificate2 Certificate) 
        {

            const string action = "urn:async_exportPaymentReceiver";

            XmlDocument xmlRequest = new XmlDocument();
            xmlRequest.LoadXml(SMEVMessageParts.MessageHeader + SMEVMessageParts.PaymentReceiversRequest);

            XmlNamespaceManager nsmgr1 = new XmlNamespaceManager(xmlRequest.NameTable);
            nsmgr1.AddNamespace("rev", "http://smev.gosuslugi.ru/rev120315");

            XmlNode nodeDate = xmlRequest.SelectSingleNode("//rev:Date", nsmgr1);
            nodeDate.InnerXml = DateTime.Now.ToString("s");
            xmlRequest.Save("request.xml");

                // Подписываем запрос
            SignXmlFile(xmlRequest, Certificate);
            xmlRequest.Save("request_signed.xml");

            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.PreserveWhitespace = true;

            Console.WriteLine("{0:T} Отправляем запрос exportPaymentReceiver...", DateTime.Now);
            if (!SendSoapRequest(xmlRequest, xmlResponse, action, "request_resp.xml"))
            {
                Console.WriteLine("SendSoapRequest fails");
                return false;
            }
            Console.WriteLine("{0:T} Получен ответ.", DateTime.Now);

            XmlNamespaceManager nsmgr2 = new XmlNamespaceManager(xmlResponse.NameTable);
            nsmgr2.AddNamespace("ns3", "http://smev.gosuslugi.ru/rev120315");

            XmlNode nodeGUID = xmlResponse.SelectSingleNode("//ns3:MessageGUID", nsmgr2);
            if (nodeGUID == null)
            {
                Console.WriteLine("MessageGUID not found");
                Console.ReadKey();
                return false;
            }
            else
            {
                guid = nodeGUID.InnerXml;
                return true;
            }
        }

        static bool SendStatus(X509Certificate2 Certificate) 
        {

            string action = "urn:async_getResult";

            XmlDocument xmlRequest = new XmlDocument();
            xmlRequest.LoadXml(SMEVMessageParts.MessageHeader + SMEVMessageParts.PaymentReceiversStatus);

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlRequest.NameTable);
            nsmgr.AddNamespace("rev", "http://smev.gosuslugi.ru/rev120315");
            XmlNode nodeDate = xmlRequest.SelectSingleNode("//rev:Date", nsmgr);
            nodeDate.InnerXml = DateTime.Now.ToString("s");
            XmlNode nodeGUID = xmlRequest.SelectSingleNode("//rev:MessageGUID", nsmgr);
            nodeGUID.InnerXml = guid;
            xmlRequest.Save("status.xml");

            // Подписываем запрос
            SignXmlFile(xmlRequest, Certificate);
            xmlRequest.Save("status_signed.xml");

            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.PreserveWhitespace = true;

            Console.WriteLine("{0:T} Отправляем запрос getResult...", DateTime.Now);
            if (!SendSoapRequest(xmlRequest, xmlResponse, action, "status_resp.xml"))
            {
                return false;
            }
            Console.WriteLine("{0:T} Получен ответ.", DateTime.Now);
            LoadReceiversList(xmlResponse);
            return true;
        }

        static void LoadReceiversList(XmlDocument xmlResponse) 
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlResponse.NameTable);
            nsmgr.AddNamespace("ns3", "http://smev.gosuslugi.ru/rev120315");
            XmlNode data = xmlResponse.SelectSingleNode("//ns3:BinaryData", nsmgr);
            if (data == null)
            {
                Console.WriteLine("BinaryData not found");
                Console.ReadKey();
                return;
            }
            MemoryStream stream = new MemoryStream(Convert.FromBase64String(data.InnerXml));
            ZipArchive zip = new ZipArchive(stream, ZipArchiveMode.Read);
            ZipArchiveEntry entry = zip.GetEntry("Получатели платежа.xml");
            if (entry != null)
            {
                String buffer;
                using (StreamReader reader = new StreamReader(entry.Open()))
                {
                    buffer = reader.ReadToEnd();
                }
                XmlDocument xmlData = new XmlDocument();
                xmlData.LoadXml(buffer);
                WriteReceivers(xmlData);

//                using (StreamWriter writer = new StreamWriter("data.xml"))
//                {
//                    writer.Write(buffer);
//                }
            }
        }

        static void WriteReceivers(XmlDocument xmlDoc)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("smev", "http://smev.gosuslugi.ru/rev120315");
            XmlNodeList nodes = xmlDoc.SelectNodes("//smev:SP", nsmgr);
            XmlNode node;
            Console.WriteLine(nodes.Count);
            OleDbConnection conn = new OleDbConnection("Provider=VFPOLEDB.1; Data Source=H:\\TEMP");
            conn.Open();

            String query = "INSERT INTO Provider (ID,OGRN,INN,KPP,ORG_NAME) VALUES(?,?,?,?,?)";
            OleDbCommand cmd = new OleDbCommand(query, conn);

            for (int i = 0; i < nodes.Count; i++)
            {
                node = nodes.Item(i);
                if (node["smev:OGRN"] != null && node["smev:INN"] != null && node["smev:KPP"] != null && node["smev:N"] != null)
                {
                    Console.WriteLine(i);
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@ID", Guid.NewGuid().ToString());
                    cmd.Parameters.AddWithValue("@OGRN", node["smev:OGRN"].InnerXml);
                    cmd.Parameters.AddWithValue("@INN", node["smev:INN"].InnerXml);
                    cmd.Parameters.AddWithValue("@KPP", node["smev:KPP"].InnerXml);
                    cmd.Parameters.AddWithValue("@ORG_NAME", node["smev:N"].InnerXml);
                    cmd.ExecuteNonQuery();
                }
            }
            conn.Close();
        }

        static bool SendSoapRequest(XmlDocument docRequest, XmlDocument docResponse, string SoapAction, string FileName)
        {
            string uri = "http://smev-mvf.test.gosuslugi.ru:7777/gateway/services/SID0004768";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.Credentials = CredentialCache.DefaultCredentials;
            request.Headers.Add("SOAPAction", SoapAction);
            request.ContentType = "text/xml;charset=\"utf-8\"";
            request.Method = "POST";
            StreamWriter writer = new StreamWriter(request.GetRequestStream());
            writer.Write(docRequest.OuterXml);
            writer.Close();
            request.GetRequestStream().Flush();
            int err = 0;
            string errDescription = string.Empty;
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException wex)
            {
                err = 10001;
                errDescription = wex.Message;
                response = (HttpWebResponse)wex.Response;
            }

            StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.GetEncoding("utf-8"));
            docResponse.LoadXml(reader.ReadToEnd());
            docResponse.Save(FileName);

            if (err > 0)
            {
                Console.WriteLine("Ошибка при передаче сообщения: " + errDescription);
                return false;
            }
            else
            {
                // Проверяете подпись (я испеользую КриптоПро .NET, пример есть у них на сайте)
                //                VerifyXmlData(respDoc);
                //Обрабатываете результат respDoc.OuterXml
                //можете отправить его, как результат работы вашего wcf сервиса
            }
            response.Close();
            return true;
        }

        static X509Certificate2 LoadCertificate(string subject)
        {
            X509Store store = new X509Store(StoreLocation.CurrentUser);
            store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);
            X509Certificate2Collection certs =
                store.Certificates.Find(X509FindType.FindBySubjectName, subject, false);

            // Проверяем, что нашли ровно один сертификат.
            if (certs.Count == 0)
            {
                Console.WriteLine("Сертификат не найден.");
                Console.ReadKey();
                return null;
            }
            if (certs.Count > 1)
            {
                Console.WriteLine("Найдено более одного сертификата.");
                Console.ReadKey();
                return null;
            }

            return certs[0];
        }

        static void SignXmlFile(XmlDocument XmlDoc, X509Certificate2 Certificate)
        {

            // Создаём объект SmevSignedXml - наследник класса SignedXml с перегруженным GetIdElement
            // для корректной обработки атрибута wsu:Id. 
            SmevSignedXml signedXml = new SmevSignedXml(XmlDoc);

            // Задаём ключ подписи для документа SmevSignedXml.
            signedXml.SigningKey = Certificate.PrivateKey;

            // Создаем ссылку на подписываемый узел XML. В данном примере и в методических
            // рекомендациях СМЭВ подписываемый узел soapenv:Body помечен идентификатором "body".
            Reference reference = new Reference();
            reference.Uri = "#body";

            // Задаём алгоритм хэширования подписываемого узла - ГОСТ Р 34.11-94. Необходимо
            // использовать устаревший идентификатор данного алгоритма, т.к. именно такой
            // идентификатор используется в СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            reference.DigestMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete;
#pragma warning restore 612

            // Добавляем преобразование для приведения подписываемого узла к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            XmlDsigExcC14NTransform c14 = new XmlDsigExcC14NTransform();
            reference.AddTransform(c14);

            // Добавляем ссылку на подписываемый узел.
            signedXml.AddReference(reference);

            // Задаём преобразование для приведения узла ds:SignedInfo к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            signedXml.SignedInfo.CanonicalizationMethod = SignedXml.XmlDsigExcC14NTransformUrl;

            // Задаём алгоритм подписи - ГОСТ Р 34.10-2001. Необходимо использовать устаревший
            // идентификатор данного алгоритма, т.к. именно такой идентификатор используется в
            // СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            signedXml.SignedInfo.SignatureMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3410UrlObsolete;
#pragma warning restore 612

            // Вычисляем подпись.
            signedXml.ComputeSignature();

            // Получаем представление подписи в виде XML.
            XmlElement xmlDigitalSignature = signedXml.GetXml();

            // Добавляем необходимые узлы подписи в исходный документ в заготовленное место.
            XmlDoc.GetElementsByTagName("ds:Signature")[0].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignatureValue")[0], true));
            XmlDoc.GetElementsByTagName("ds:Signature")[0].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignedInfo")[0], true));

            // Добавляем сертификат в исходный документ в заготовленный узел
            // wsse:BinarySecurityToken.
            XmlDoc.GetElementsByTagName("wsse:BinarySecurityToken")[0].InnerText =
                Convert.ToBase64String(Certificate.RawData);

        }

        // Класс SmevSignedXml - наследник класса SignedXml с перегруженным
        // GetIdElement для корректной обработки атрибута wsu:Id. 
        class SmevSignedXml : SignedXml
        {
            public SmevSignedXml(XmlDocument document): base(document)
            {
            }

            public override XmlElement GetIdElement(XmlDocument document, string idValue)
            {
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(document.NameTable);
                nsmgr.AddNamespace("wsu", WSSecurityWSUNamespaceUrl);
                return document.SelectSingleNode("//*[@wsu:Id='" + idValue + "']", nsmgr) as XmlElement;
            }
        }

        public const string WSSecurityWSSENamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
        public const string WSSecurityWSUNamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

    }
}
