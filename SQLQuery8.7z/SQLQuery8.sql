USE [CurrRates]
GO

/****** Object:  StoredProcedure [dbo].[IUD_audit]    Script Date: 20.02.2021 11:35:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[IUD_audit]
	@iud		int,
	@f_audit	int			  =	NULL,
	@c_proc		int			  =	NULL,
	@id_client	int			  =	NULL,
	@note		varchar(2048) =	NULL
AS
BEGIN
	DECLARE	@ret	int
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET @ret = 0

	IF @iud = 1
	BEGIN
		INSERT INTO SBP_audit
		(
			c_proc,
			id_client,
			note
		)
		VALUES
		(
			@c_proc,
			@id_client,
			@note
		)

		SET @ret = -1

		IF (@@ERROR = 0) AND (@@ROWCOUNT = 1)
		BEGIN
			SET @ret = @@IDENTITY
		END
	END
	ELSE IF @iud = 2
	BEGIN
		UPDATE 
				SBP_audit
		   SET
				c_proc		= @c_proc,
				id_client	= @id_client,
				note		= @note
		 WHERE
				f_audit = @f_audit

		SET @ret = -2

		IF (@@ERROR = 0) AND (@@ROWCOUNT = 1)
		BEGIN
			SET @ret = @f_audit
		END
	END

	RETURN @ret

END
GO


