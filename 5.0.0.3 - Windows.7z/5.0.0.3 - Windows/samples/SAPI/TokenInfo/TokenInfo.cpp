/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#endif

#include "eTPkcs11.h"
#include "eTSAPI.h"

#ifdef _WIN32
#define PKCS11_DLL_NAME		"etpkcs11.dll"
#define ETSAPI_DLL_NAME		"etsapi.dll"
#else
#define PKCS11_DLL_NAME		"libeTPkcs11.so"
#define ETSAPI_DLL_NAME		"libeTSapi.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

// Print message and stop execution.
static void leave(const char * message)
{
  if (message) printf("%s\n", message);
  printf("Press Enter to exit");
  getchar();
  exit(message ? -1 : 0);
}

CK_FUNCTION_LIST_PTR fl = NULL; // PKCS#11 functions list.

// Load eTPKCS11 and initialize PKCS#11.
void LoadPKCS11()
{
  HINSTANCE hLib = LoadLibrary(PKCS11_DLL_NAME); 
  if (!hLib) leave("Cannot load eTPkcs11");
  
  CK_C_GetFunctionList f_C_GetFunctionList = NULL;
#ifdef _WIN32
	(FARPROC&)f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#endif	
  if (!f_C_GetFunctionList) leave("C_GetFunctionList not found");

  if (CKR_OK != f_C_GetFunctionList(&fl)) leave("C_GetFunctionList failed");
  if (CKR_OK != fl->C_Initialize(0)) leave("C_Initialize failed");
}

// SAPI functions declaration.
typedef CK_RV (*t_SAPI_GetTokenInfo)(CK_SLOT_ID, CK_ATTRIBUTE_PTR, CK_ULONG);
t_SAPI_GetTokenInfo _SAPI_GetTokenInfo = NULL;

// Load eTSAPI and acquire its usable functions.
void LoadETSAPI()
{
  HINSTANCE hLib = LoadLibrary(ETSAPI_DLL_NAME); 
  if (!hLib) leave("Cannot load eTSapi");

	#ifdef _WIN32
  (FARPROC&)_SAPI_GetTokenInfo = GetProcAddress(hLib, "SAPI_GetTokenInfo");
	#else
	*(void**)&_SAPI_GetTokenInfo = GetProcAddress(hLib, "SAPI_GetTokenInfo");
	#endif
  if (!_SAPI_GetTokenInfo) leave("SAPI_GetTokenInfo not found");
}

// Get PKCS#11 slot list.
void GetSlotList(CK_SLOT_ID_PTR& pSlotList, CK_ULONG& nSlotCount)
{
  if (CKR_OK != fl->C_GetSlotList(TRUE, NULL, &nSlotCount)) leave("C_GetSlotList failed");
  if (nSlotCount<1) leave("No eToken inserted");
  pSlotList = new CK_SLOT_ID[nSlotCount];
  if (CKR_OK != fl->C_GetSlotList(TRUE, pSlotList, &nSlotCount)) leave("C_GetSlotList failed");
}

//-------------------- Print helper functions ---------------

void OutName(const char* name) // Print attribute name.
{
  printf("%-30s", name);
}

BOOL CheckEmpty(CK_ATTRIBUTE* attr) // Detect if attribute value is empty.
{
  if (attr->ulValueLen>0) return FALSE;
  printf("<EMPTY>\n");
  return TRUE;
}

void OutString(CK_ATTRIBUTE* attr, const char* name) // Print attribute value as a string.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  printf("%s\n", (const char*)attr->pValue); 
}

void OutVersion(CK_ATTRIBUTE* attr, const char* name) // Print attribute value as CK_VERSION.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  CK_VERSION* v = (CK_VERSION*)attr->pValue;
  printf("%d.%d\n", v->major, v->minor); 
}

void OutDecimal(CK_ATTRIBUTE* attr, const char* name) // Print attribute value as a decimal number.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  printf("%d\n", *((int*)attr->pValue)); 
}

void OutHex(CK_ATTRIBUTE* attr, const char* name)  // Print attribute value as a hexadecimal number.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  printf("0x%08x\n", *((unsigned int*)attr->pValue)); 
}

void OutDate(CK_ATTRIBUTE* attr, const char* name)  // Print attribute value as CK_DATE.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  CK_DATE* d = (CK_DATE*)attr->pValue; 
  printf("%c%c.%c%c.%c%c%c%c\n", 
    d->day[0], d->day[1], 
    d->month[0], d->month[1], 
    d->year[0], d->year[1], d->year[2], d->year[3] ); 
}

void OutArray(CK_ATTRIBUTE* attr, const char* name)  // Print attribute value as an array of bytes.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  for (CK_ULONG i=0; i<attr->ulValueLen; i++) printf("%02x ",((BYTE*)(attr->pValue))[i]); 
  printf("\n");
}

void OutBoolean(CK_ATTRIBUTE* attr, const char* name) // Print boolean attribute value.
{ 
  OutName(name);
  if (CheckEmpty(attr)) return;
  printf("%s\n", *((CK_BBOOL*)attr->pValue) ? "TRUE" : "FALSE"); 
}

// Find attribute in template based on its type.
CK_ATTRIBUTE* FindAttr(CK_ATTRIBUTE* Template, int nTemplate, CK_ATTRIBUTE_TYPE type)
{
  for (int i=0; i<nTemplate; i++, Template++)
  {
    if (Template->type==type) return Template;
  }
  return NULL;
}

// Show all eToken information provided by SAPI.
void ShowTokenInfo(CK_SLOT_ID SlotID)
{
  printf("%-30s%d\n", "Slot ID", SlotID);
  
  char product_name[256];
  char model[256];
  char hw_internal[256];
  char card_id[256];
  char serial[256];

  CK_ULONG fw_revision;
  CK_ULONG case_model;
  CK_ULONG token_id;
  CK_ULONG card_type;
  CK_ULONG color;

  CK_VERSION fw_version;
  CK_VERSION hw_version;
  CK_VERSION card_version;

  CK_DATE production_date;

  CK_BBOOL has_battery;
  CK_BBOOL has_lcd;
  CK_BBOOL has_user;
  CK_BBOOL has_so;
  CK_BBOOL fips;
  CK_BBOOL fips_supported;
  CK_BBOOL init_pin_req;
  CK_BBOOL rsa_2048;
  CK_BBOOL rsa_2048_supported;
  CK_BBOOL hmac_sha1;
  CK_BBOOL hmac_sha1_supported;
  CK_BBOOL real_color;
  CK_BBOOL may_init;

  // Template declaration.
  CK_ATTRIBUTE Template[] = 
  {
    {CKA_SAPI_PRODUCT_NAME,        product_name,         sizeof(product_name)},
    {CKA_SAPI_MODEL,               model,                sizeof(model)},
    {CKA_SAPI_FW_VERSION,          &fw_version,          sizeof(CK_VERSION)},
    {CKA_SAPI_FW_REVISION,         &fw_revision,         sizeof(CK_ULONG)},
    {CKA_SAPI_HW_VERSION,          &hw_version,          sizeof(CK_VERSION)},
    {CKA_SAPI_HW_INTERNAL,         hw_internal,          sizeof(hw_internal)},
    {CKA_SAPI_PRODUCTION_DATE,     &production_date,     sizeof(CK_DATE)},
    {CKA_SAPI_CASE_MODEL,          &case_model,          sizeof(CK_ULONG)},
    {CKA_SAPI_TOKEN_ID,            &token_id,            sizeof(CK_ULONG)},
    {CKA_SAPI_CARD_ID,             card_id,              sizeof(card_id)},
    {CKA_SAPI_CARD_TYPE,           &card_type,           sizeof(CK_ULONG)},
    {CKA_SAPI_CARD_VERSION,        &card_version,        sizeof(CK_VERSION)},
    {CKA_SAPI_SERIAL,              serial,               sizeof(serial)},
    {CKA_SAPI_COLOR,               &color,               sizeof(CK_ULONG)},
    {CKA_SAPI_HAS_BATTERY,         &has_battery,         sizeof(CK_BBOOL)},
    {CKA_SAPI_HAS_LCD,             &has_lcd,             sizeof(CK_BBOOL)},
    {CKA_SAPI_HAS_USER,            &has_user,            sizeof(CK_BBOOL)},
    {CKA_SAPI_HAS_SO,              &has_so,              sizeof(CK_BBOOL)},
    {CKA_SAPI_FIPS,                &fips,                sizeof(CK_BBOOL)},
    {CKA_SAPI_FIPS_SUPPORTED,      &fips_supported,      sizeof(CK_BBOOL)},
    {CKA_SAPI_INIT_PIN_REQ,        &init_pin_req,        sizeof(CK_BBOOL)},
    {CKA_SAPI_RSA_2048,            &rsa_2048,            sizeof(CK_BBOOL)},
    {CKA_SAPI_RSA_2048_SUPPORTED,  &rsa_2048_supported,  sizeof(CK_BBOOL)},
    {CKA_SAPI_HMAC_SHA1,           &hmac_sha1,           sizeof(CK_BBOOL)},
    {CKA_SAPI_HMAC_SHA1_SUPPORTED, &hmac_sha1_supported, sizeof(CK_BBOOL)},
    {CKA_SAPI_REAL_COLOR,          &real_color,          sizeof(CK_BBOOL)},
    {CKA_SAPI_MAY_INIT,            &may_init,            sizeof(CK_BBOOL)},
  };

  // Size of template.
  int nTemplate = sizeof(Template)/sizeof(CK_ATTRIBUTE);

  // Acquire all attributes.
  if (CKR_OK != _SAPI_GetTokenInfo(SlotID, Template, nTemplate)) leave("SAPI_GetTokenInfo fail");
  
  CK_ATTRIBUTE* attr;

  // Printing.
  attr = FindAttr(Template, nTemplate, CKA_SAPI_PRODUCT_NAME);         OutString (attr, "CKA_SAPI_PRODUCT_NAME");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_MODEL);                OutString (attr, "CKA_SAPI_MODEL");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_FW_VERSION);           OutVersion(attr, "CKA_SAPI_FW_VERSION");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_FW_REVISION);          OutDecimal(attr, "CKA_SAPI_FW_REVISION");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HW_VERSION);           OutVersion(attr, "CKA_SAPI_HW_VERSION");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HW_INTERNAL);          OutArray  (attr, "CKA_SAPI_HW_INTERNAL");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_PRODUCTION_DATE);      OutDate   (attr, "CKA_SAPI_PRODUCTION_DATE");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_CASE_MODEL);           OutDecimal(attr, "CKA_SAPI_CASE_MODEL");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_TOKEN_ID);             OutHex    (attr, "CKA_SAPI_TOKEN_ID");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_CARD_ID);              OutArray  (attr, "CKA_SAPI_CARD_ID");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_CARD_TYPE);            OutDecimal(attr, "CKA_SAPI_CARD_TYPE");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_CARD_VERSION);         OutVersion(attr, "CKA_SAPI_CARD_VERSION");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_SERIAL);               OutArray  (attr, "CKA_SAPI_SERIAL");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_COLOR);                OutDecimal(attr, "CKA_SAPI_COLOR");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HAS_BATTERY);          OutBoolean(attr, "CKA_SAPI_HAS_BATTERY");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HAS_LCD);              OutBoolean(attr, "CKA_SAPI_HAS_LCD");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HAS_USER);             OutBoolean(attr, "CKA_SAPI_HAS_USER");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HAS_SO);               OutBoolean(attr, "CKA_SAPI_HAS_SO");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_FIPS);                 OutBoolean(attr, "CKA_SAPI_FIPS");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_FIPS_SUPPORTED);       OutBoolean(attr, "CKA_SAPI_FIPS_SUPPORTED");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_INIT_PIN_REQ);         OutBoolean(attr, "CKA_SAPI_INIT_PIN_REQ");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_RSA_2048);             OutBoolean(attr, "CKA_SAPI_RSA_2048");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_RSA_2048_SUPPORTED);   OutBoolean(attr, "CKA_SAPI_RSA_2048_SUPPORTED");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HMAC_SHA1);            OutBoolean(attr, "CKA_SAPI_HMAC_SHA1");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_HMAC_SHA1_SUPPORTED);  OutBoolean(attr, "CKA_SAPI_HMAC_SHA1_SUPPORTED");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_REAL_COLOR);           OutBoolean(attr, "CKA_SAPI_REAL_COLOR");
  attr = FindAttr(Template, nTemplate, CKA_SAPI_MAY_INIT);             OutBoolean(attr, "CKA_SAPI_MAY_INIT");

  printf("\n");
}


int main(int argc, char* argv[])
{
  LoadPKCS11();
  LoadETSAPI();

  // Get slot list.
  CK_SLOT_ID_PTR pSlots=NULL; 
  CK_ULONG nSlotCount;
  GetSlotList(pSlots, nSlotCount);
  printf("Number of inserted tokens is %d\n\n", nSlotCount);

  // Print eToken information about all found eTokens.
  for (CK_ULONG i=0; i<nSlotCount; i++)
  {
    CK_ULONG SlotID = pSlots[i];
    ShowTokenInfo(SlotID);
  }

  delete[] pSlots;
	
  fl->C_Finalize(0);
  leave(NULL);
  return 0;
}


