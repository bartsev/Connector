﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMEV
{
    public static class SmevMessageParts
    {
        public const string SEND_REQUEST_REQUEST =
//            "<?xml version = \"1.0\" encoding=\"UTF-8\"?>" +
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/1.1\">" +
            "<soap:Body>" +
                "<ns2:SendRequestRequest " +
                        "xmlns:ns3=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/faults/1.1\" " +
                        "xmlns:ns2=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/1.1\" " +
                        "xmlns=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/basic/1.1\">" +
                    "<ns:SenderProvidedRequestData " +
                            "Id = \"SIGNED_BY_CONSUMER\" " +
                            "xmlns=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/1.1\" " +
                            "xmlns:ns=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/1.1\" " + 
                            "xmlns:ns2=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/basic/1.1\">" +
                        "<ns:MessageID>72db683d-c7e4-11e4-b8aa-d4c9eff07b77</ns:MessageID>" +
                        "<ns2:MessagePrimaryContent>{0}</ns2:MessagePrimaryContent>" +
                        "<ns:PersonalSignature></ns:PersonalSignature>" +
                        "<ns:TestMessage/>" +
                    "</ns:SenderProvidedRequestData>" +
                    "<ns2:CallerInformationSystemSignature></ns2:CallerInformationSystemSignature>" +
                "</ns2:SendRequestRequest>" +
            "</soap:Body>" +
        "</soap:Envelope>";

        public const string IMPORT_PAYMENT_REQUEST =
            "<req:ImportPaymentsRequest " +
                    "xmlns:com=\"http://roskazna.ru/gisgmp/xsd/Common/2.0.1\" " +
                    "xmlns:req=\"urn://roskazna.ru/gisgmp/xsd/services/import-payments/2.0.1\" " +
                    "xmlns:pkg=\"http://roskazna.ru/gisgmp/xsd/Package/2.0.1\" " +
                    "xmlns:bdi=\"http://roskazna.ru/gisgmp/xsd/BudgetIndex/2.0.1\" " +
                    "xmlns:org=\"http://roskazna.ru/gisgmp/xsd/Organization/2.0.1\" " +
                    "xmlns:chg=\"http://roskazna.ru/gisgmp/xsd/Charge/2.0.1\" " +
                    "xmlns:rfd=\"http://roskazna.ru/gisgmp/xsd/Refund/2.0.1\" " +
                    "xmlns:pmnt=\"http://roskazna.ru/gisgmp/xsd/Payment/2.0.1\" " +
                    "Id=\"I_13032ed0-4a7a-49ed-ad46-2a7206d3bca7\" timestamp=\"2017-07-24T18:13:51.0\" senderIdentifier=\"3eb646\" senderRole=\"9\">" +
                "<pkg:PaymentsPackage>" +
                    "<pkg:ImportedPayment Id = \"I_09bcf2c6-a08a-4ea2-959d-8e198ba689d9\" paymentId=\"10471020010005232407201700000001\" purpose=\"Штраф\" " +
                                "kbk=\"18811630020016000140\" oktmo=\"45348000\" supplierBillID=\"18817072416285972102\" amount=\"50000\" paymentDate=\"2017-11-24\" transKind=\"01\">" +
                        "<pmnt:PaymentOrg>" +
                            "<org:Bank bik = \"047252006\"/>" +
                        "</pmnt:PaymentOrg>" +
                        "<pmnt:Payer payerName = \"Антонов Борис Константинович\" payerIdentifier=\"1010000000003751379232\"/>" +
                        "<org:Payee name = \"УВД по ЦАО ГУ МВД России по г. Москве\" inn=\"7706012716\" kpp=\"770901011\">" +
                            "<com:OrgAccount accountNumber = \"40101810800000010041\">" +
                                "<com:Bank bik = \"044583001\"/>" +
                            "</com:OrgAccount>" +
                        "</org:Payee>" +
                        "<pmnt:BudgetIndex status = \"01\" paytReason=\"0\" taxPeriod=\"0\" taxDocNumber=\"01\" taxDocDate=\"0\"/>" +
                        "<pmnt:AccDoc accDocDate = \"2017-11-24\"/>" +
                        "<com:ChangeStatus meaning = \"1\"/>" +
                    "</pkg:ImportedPayment>" +
                "</pkg:PaymentsPackage>" +
            "</req:ImportPaymentsRequest>";

        public const string SIGNATURE =
            "<ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">" +
                "<SignedInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\">" +
                    "<CanonicalizationMethod Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/>" +
                    "<SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#gostr34102001-gostr3411\"/>" +
                    "<Reference URI=\"#I_13032ed0-4a7a-49ed-ad46-2a7206d3bca7\">" +
                        "<Transforms>" +
                            "<Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/>" +
                            "<Transform Algorithm=\"urn://smev-gov-ru/xmldsig/transform\"/>" +
                        "</Transforms>" +
                        "<DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#gostr3411\"/>" +
                        "<DigestValue></DigestValue>" +
                    "</Reference>" +
                "</SignedInfo>" +
                "<SignatureValue xmlns=\"http://www.w3.org/2000/09/xmldsig#\"></SignatureValue>" +
                "<ds:KeyInfo>" +
                    "<ds:X509Data>" + 
                        "<ds:X509Certificate></ds:X509Certificate>" +
                    "</ds:X509Data>" +
                "</ds:KeyInfo>" +
            "</ds:Signature>";
    }
}
