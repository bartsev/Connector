USE [CurrRates]
GO

/****** Object:  Table [dbo].[SBP_clients]    Script Date: 20.02.2021 11:27:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SBP_clients](
	[CLIENT_REF] [int] NOT NULL,
	[BranchCode] [int] NULL,
	[CLIENT_NAME] [varchar](255) NULL,
	[CLIENT_PHONE] [varchar](50) NULL,
	[CLIENT_ACC] [varchar](34) NULL,
	[CLIENT_CARD] [varchar](16) NULL,
	[ConnectAgree] [tinyint] NULL,
 CONSTRAINT [PK_SBP_Clients_1] PRIMARY KEY CLUSTERED 
(
	[CLIENT_REF] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


