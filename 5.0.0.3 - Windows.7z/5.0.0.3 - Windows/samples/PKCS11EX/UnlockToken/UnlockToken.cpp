/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#endif

#include "eTPkcs11.h"
#include "eTSAPI.h"
#include "pkcs11.h"

#ifdef _WIN32
#define PKCS11_DLL_NAME		"etpkcs11.DLL"
#define ETSAPI_DLL_NAME		"etsapi.dll"
#else
#define PKCS11_DLL_NAME		"libeTPkcs11.so"
#define ETSAPI_DLL_NAME		"libeTSapi.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

#define RC_ERROR 1
#define SAPI_SERVER_UNBLOCK          "SAPI_Server_Unblock"

// PKCS#11 functions list.
CK_FUNCTION_LIST_PTR pFunc = NULL; 
// PKCS#11 eToken extended functions list.
ETCK_FUNCTION_LIST_EX_PTR pFuncEx = NULL; 

bool wasInit = false;

// Print message and stop execution.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	if(wasInit)
	{
		// Close PKCS#11 library.
		if (CKR_OK != pFunc->C_Finalize(0))
		{
			printf ("C_Finalize failed...\n");
		}
	}
	printf("\n\n");
  printf("Press the Enter key to exit");
  getchar();
  exit(rv);
}

// Locate an inserted eToken.
CK_SLOT_ID LocateToken()
{
  CK_ULONG nSlots = 1;
  CK_SLOT_ID nSlotID;
  if (CKR_OK != pFunc->C_GetSlotList(TRUE, &nSlotID, &nSlots)) leave("C_GetSlotList failed");
  if (nSlots<1) leave("No eToken inserted");
  return nSlotID;
}

// Load eTPKCS11 and initialize PKCS#11.
void LoadPKCS11()
{
	//Dynamic load PKCS#11 library
  HINSTANCE hLib = LoadLibrary(PKCS11_DLL_NAME); 
  if (!hLib) leave("Cannot load etpkcs11");
  
	//Get PKCS#11 function list.
  CK_C_GetFunctionList f_C_GetFunctionList = NULL;
#ifdef _WIN32
  (FARPROC&)f_C_GetFunctionList = GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&f_C_GetFunctionList = GetProcAddress(hLib, "C_GetFunctionList");
#endif
  if (!f_C_GetFunctionList) leave("C_GetFunctionList not found");

	if (CKR_OK != f_C_GetFunctionList(&pFunc)) leave("C_GetFunctionList failed");

	//Get PKCS#11 eToken extended function list.
	CK_ETC_GetFunctionListEx f_CK_ETC_GetFunctionListEx = NULL;
#ifdef _WIN32
  (FARPROC&)f_CK_ETC_GetFunctionListEx = GetProcAddress(hLib, "ETC_GetFunctionListEx");
#else
	*(void**)&f_CK_ETC_GetFunctionListEx = GetProcAddress(hLib, "ETC_GetFunctionListEx");
#endif
  if (!f_CK_ETC_GetFunctionListEx) leave("ETC_GetFunctionListEx not found");

	if (CKR_OK != f_CK_ETC_GetFunctionListEx(&pFuncEx)) leave("ETC_GetFunctionListEx failed");

  if (CKR_OK != pFunc->C_Initialize(0)) leave("C_Initialize failed");
	wasInit = true;
}

int main(const unsigned int argc, const char** argv)
{
	CK_RV rv = 0;

	LoadPKCS11();

	if(argc < 3)
	{
	   leave("Usage:\n"
         "  UnlockToken <administrator-password> <new-user-password>\n"
         "  Example: UnlockToken 1111 1234567890\n");
	}

	const char* adminPass = argv[1];
	const char* newPass = argv[2];

	printf("Unlock the token:\n administrator password = %s\n new user password = %s\n", adminPass, newPass);


  HINSTANCE sapiDll = LoadLibrary(ETSAPI_DLL_NAME);
  f_SAPI_Server_Unblock sapiServerUnblock = NULL;

#ifdef _WIN32
  (FARPROC&)sapiServerUnblock = GetProcAddress(sapiDll, SAPI_SERVER_UNBLOCK);
#else
	*(void**)&sapiServerUnblock = GetProcAddress(sapiDll, SAPI_SERVER_UNBLOCK);
#endif

  if (sapiServerUnblock == NULL) 
		leave("Cannot load " ETSAPI_DLL_NAME ,RC_ERROR);

	// Locate the token
	CK_SLOT_ID	nSlotID = LocateToken();

  // Open the session to the token
  CK_SESSION_HANDLE hSession = 0;
  if(rv=pFunc->C_OpenSession(nSlotID, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL_PTR,NULL_PTR, &hSession))
      leave("Cannot open session", rv);

	// Print PKCS#11 version and function pointers.
  printf("eTPkcs11 Version: %d.%d\n", pFuncEx->version.major, pFuncEx->version.minor);

  printf("ETC_GetFunctionListEx     %08X\n", pFuncEx->ETC_GetFunctionListEx);
  printf("ETC_DeviceIOCTL           %08X\n", pFuncEx->ETC_DeviceIOCTL);
  printf("ETC_TokenIOCTL            %08X\n", pFuncEx->ETC_TokenIOCTL);
  printf("ETC_CreateTracker         %08X\n", pFuncEx->ETC_CreateTracker);
  printf("ETC_DestroyTracker        %08X\n", pFuncEx->ETC_DestroyTracker);
  printf("ETC_BeginTransaction      %08X\n", pFuncEx->ETC_BeginTransaction);
  printf("ETC_EndTransaction        %08X\n", pFuncEx->ETC_EndTransaction);
  printf("ETC_GetProperty           %08X\n", pFuncEx->ETC_GetProperty);
  printf("ETC_SetProperty           %08X\n", pFuncEx->ETC_SetProperty);
  printf("ETC_CreateVirtualSession  %08X\n", pFuncEx->ETC_CreateVirtualSession);
  printf("ETC_SingleLogonGetPin     %08X\n", pFuncEx->ETC_SingleLogonGetPin);
  printf("ETC_InitTokenInit         %08X\n", pFuncEx->ETC_InitTokenInit);
  printf("ETC_InitTokenFinal        %08X\n", pFuncEx->ETC_InitTokenFinal);
  printf("ETC_InitPIN               %08X\n", pFuncEx->ETC_InitPIN);
  printf("ETC_UnlockGetChallenge    %08X\n", pFuncEx->ETC_UnlockGetChallenge);
  printf("ETC_UnlockComplete        %08X\n", pFuncEx->ETC_UnlockComplete);

  // Test the UnlockGetChallenge function
  CK_ULONG size = 0;
  if(rv=pFuncEx->ETC_UnlockGetChallenge(hSession, NULL, &size))
	{
		char msg[256];
		sprintf(msg, "Challenge length: %d", size);
		leave(msg, rv);
	}

  if ((size != 8))
		leave("Invalid admin challenge size...", rv);
  
  {
		CK_ULONG ulRetryCounter = 0xFF;

    // Print old retry counter
    // Find token feature object
    CK_OBJECT_CLASS objClass = CKO_HW_FEATURE;
	  CK_ULONG ulHWFeatureType = ETCKH_TOKEN_OBJECT;
	  CK_ATTRIBUTE tmpl[] = {CKA_CLASS,	           &objClass,         sizeof(objClass),
				 CKA_HW_FEATURE_TYPE,  &ulHWFeatureType,  sizeof(ulHWFeatureType)};
    if(rv=pFunc->C_FindObjectsInit(hSession, tmpl, sizeof(tmpl)/sizeof(tmpl[0])))
      leave("C_FindObjectsInit failed", rv);

    CK_OBJECT_HANDLE hObj = 0;
    CK_ULONG ulFound = 0;
    if(rv=pFunc->C_FindObjects(hSession, &hObj, 1, &ulFound))
			leave("C_FindObjects failed", rv);

    if(rv=pFunc->C_FindObjectsFinal(hSession))
			leave("C_FindObjectsFinal failed", rv);
  
    // Get retry counter
    CK_ATTRIBUTE retryCounter = {ETCKA_RETRY_USER_MAX, &ulRetryCounter, sizeof(ulRetryCounter)};
    if(rv=pFunc->C_GetAttributeValue(hSession, hObj, &retryCounter, 1))
			leave("Failed to get retry counter from the token", rv);

   	printf("Retry counter: %d\n", *(int*)retryCounter.pValue);

    // Get challenge
    BYTE challenge[8];
    BYTE response[8];
    if(rv=pFuncEx->ETC_UnlockGetChallenge(hSession, &challenge, &size))
			leave("ETC_UnlockGetChallenge failed", rv);
    
		// Print the challenge
		printf("Challenge: %02X %02X %02X %02X %02X %02X %02X %02X\n", 
			challenge[0], challenge[1], challenge[2], challenge[3],
      challenge[4], challenge[5], challenge[6], challenge[7]);
    
		// Calculate the response according to the SAPI algorithm and given administrator password
    size_t adminPasswordLength = strlen(adminPass);
    if(rv=sapiServerUnblock((CK_CHAR_PTR)adminPass, adminPasswordLength, challenge, response))
			leave("SAPI Server: Cannot calculate unblock password", rv);
       
    printf("Response: %02X %02X %02X %02X %02X %02X %02X %02X\n", 
			response[0], response[1], response[2], response[3],
      response[4], response[5], response[6], response[7]);

    // Unlock the token
    size_t newPasswordLength = strlen(newPass);                
    if(rv=pFuncEx->ETC_UnlockComplete(hSession, &response, sizeof(response),
                                                  (CK_CHAR_PTR)newPass, newPasswordLength, ulRetryCounter, FALSE))
			leave("ETC_UnlockComplete failed", rv);
  
		printf("Unlock Completed Successfully:)\n");
  }

	pFunc->C_CloseSession(hSession);
	pFunc->C_Finalize(NULL);

  return 0;
}

