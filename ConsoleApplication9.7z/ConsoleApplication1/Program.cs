﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using ConsoleApplication1.ServiceReference1;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.MyServiceClient client = new ServiceReference1.MyServiceClient();
            double sum = client.GetSum(3, 4);
            Console.WriteLine(sum);
            double mlt= client.GetMult(3, 4);
            Console.WriteLine(mlt);
            Console.ReadKey();
        }
    }
}
