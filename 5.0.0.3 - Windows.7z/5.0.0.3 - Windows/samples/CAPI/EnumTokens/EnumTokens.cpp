/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used content from Windows headers.



// Win32
#define _WIN32_WINNT  0x0400
#include <windows.h>
#include <winscard.h>
#include <wincrypt.h>


// STL
#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	printf("\n\n");
  printf("Press Enter to exit");
  getchar();
	exit(message ? -1 : 0 );
}

//
// Explanation and command line syntax.
void explanation()
{
  cout<<"ENUM TOKENS SAMPLE"<<endl
      <<"------------------"<<endl
      <<"Shows how to enumerate inserted token and get a certificate, if it exists."<<endl
			<<"SCardEstablishContext - establish context to RM."<<endl 
      <<"Use SCardListReaders - obtain readers list."<<endl
      <<"SCardGetStatusChange - get reader with status of SCARD_STATE_PRESENT."<<endl 
      <<"SCardGetCardTypeProviderName - display CSP name of present smart card."<<endl 
      <<"Call CryptAcquireContext with reader container name format(\\\\.\\ & szReader & \\)."//<<endl
		  <<"Use CryptGetProvParam to enumerate key containers(KCs) on selected token."<<endl 
      <<"Get handle to key pair keys(depends on key spec - Signature or Exchange keys)."<<endl 
      <<"Get Certificate Value form key handle."<<endl       
      <<"Free provider, card and reader list memory."<<endl<<endl<<endl;        
}

//
//Use Windows Crypt32 API to parse certificate with ASN-1 format.
string getCertificateName(BYTE* certValue, int certValueLen)
{
	char pszNameString[256]; 
	PCCERT_CONTEXT pCertContext = NULL; 

  //Create certificate context.
  if(pCertContext = CertCreateCertificateContext( PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
																									certValue,
																									certValueLen))
	{
		//Get certificate friendly name.
    if (CertGetNameString(pCertContext, 
													CERT_NAME_ATTR_TYPE, //CERT_NAME_SIMPLE_DISPLAY_TYPE, 
                          0,                   //CERT_NAME_ISSUER_FLAG,
													szOID_COMMON_NAME,   //NULL,   
													pszNameString,   
													sizeof(pszNameString)) == 0)
		{
      sprintf(pszNameString,"No Common Name", strlen("No Common Name"));
		}

		// When finished, free the certificate context.
		CertFreeCertificateContext(pCertContext);
	}
  return pszNameString;
}


//

int main()
{
  int rv = 0;
 
  explanation();

  SCARDCONTEXT hContext;
	if (SCardEstablishContext(SCARD_SCOPE_SYSTEM, 0, 0, &hContext)) 
	{
		leave("SCardEstablishContext failed...");
	}

	DWORD len = SCARD_AUTOALLOCATE;
	char* pReaderList = NULL;
  if (SCardListReaders(hContext, 0, (LPTSTR)&pReaderList, &len))
	{
		leave("SCardListReaders failed...");
	}

	char* reader = pReaderList;
 	for (int i=0; *reader;  reader+= (strlen(reader) + 1), ++i)
	{
		SCARD_READERSTATEA state;
		memset(&state,0,sizeof(state));
		state.szReader = reader;

		if (SCardGetStatusChange(hContext,0,&state,1)) continue;
		if (state.dwEventState & SCARD_STATE_PRESENT)
		{
			char* pCardNames = NULL;
			len = SCARD_AUTOALLOCATE;
      rv = SCardListCards(hContext, state.rgbAtr, NULL, 0, (LPTSTR)&pCardNames, &len);
			if (rv!=SCARD_S_SUCCESS)
			{
				leave("SCardListCards failed...");
			}
			char* pProvider = NULL;
			len = SCARD_AUTOALLOCATE;
			rv = SCardGetCardTypeProviderName(hContext, pCardNames, SCARD_PROVIDER_CSP, (LPTSTR)&pProvider, &len);
			if (rv==SCARD_S_SUCCESS)
			{
				if (!strcmp(pProvider,"eToken Base Cryptographic Provider"))
				{
					cout<<"Reader Name              : "<<reader<<endl;
          cout<<"Card/Token Name          : "<<pCardNames<<endl;
                                   
          //MS format for passing reader name as container name. 
          //If more then one token is inserted, this is the way to select a specific token.
          string szContainer = "\\\\.\\";
          szContainer += reader;
          szContainer +="\\"; 

          //Open handle to selected reader.
          HCRYPTPROV hProv; //Handle to eToken cryptographic service provider(CSP).
          if (::CryptAcquireContext(&hProv,szContainer.c_str(),pProvider,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT))
					{
  					DWORD dwFlags = CRYPT_FIRST;

            //Get information on extended algorithms supported by a CSP.
						DWORD dwSize;
						string szName;
						PROV_ENUMALGS_EX en_Algs_ex;
            dwSize = sizeof(en_Algs_ex);
						
						while(CryptGetProvParam(hProv, PP_ENUMALGS_EX, (PBYTE)&en_Algs_ex, &dwSize, dwFlags))
						{
							dwFlags = 0;
              if (en_Algs_ex.aiAlgid == CALG_RSA_KEYX) 
                 cout<<"Max RSA Exchange Key Len : "<<en_Algs_ex.dwMaxLen<<endl;
              if (en_Algs_ex.aiAlgid == CALG_RSA_SIGN)
                cout<<"Max RSA Signature Key Len: "<<en_Algs_ex.dwMaxLen<<endl;
						}
						cout<<endl;
						
            //Enumerate key containers(KCs) on selected token. 
						BYTE name[MAX_PATH + 1]; // Long enough for a KC name.
            dwFlags = CRYPT_FIRST;
						bool kcWithKeyExist = false;   

            for(DWORD dwDataLen = sizeof(name); ::CryptGetProvParam(hProv, PP_ENUMCONTAINERS, name, &dwDataLen, dwFlags); dwDataLen = sizeof(name))
						{
							//remove the CRYPT_FIRST flag, as only the first call to CryptGetProvParam should use it.
							dwFlags = 0;
							
							HCRYPTPROV hKeyProv = 0;
							HCRYPTKEY hKey      = 0;
							//Handle to the key container found.
							if (::CryptAcquireContext(&hKeyProv, (char*)name,pProvider, PROV_RSA_FULL, 0))
							{
                //Display the KC name.
								cout<<"Key Container Name       : "<<name<<endl;

                //Get a handle to the key pair.
				        char* keyType = "AT_KEYEXCHANGE";
                if (! ::CryptGetUserKey(hKeyProv, AT_KEYEXCHANGE, &hKey))
				        {
				           keyType = "AT_SIGNATURE";
                   if (! ::CryptGetUserKey(hKeyProv, AT_SIGNATURE, &hKey))
				           {
					           cout<<"No Key was found ..."<<endl;
					         }
				        }

								if (hKey)
								{
									kcWithKeyExist = true;
                  
                  //Display Key type.
								  cout<<"Key Type                 : "<<keyType<<endl;

                  DWORD dwKeyLen;
                  dwSize = sizeof(DWORD);
                  if(::CryptGetKeyParam(hKey, KP_KEYLEN, (BYTE*)&dwKeyLen, &dwSize, 0))
									{
										cout<<"Key Len                  : "<<dwKeyLen<<endl;
									}

                  // Get Certificate Value.
									vector<BYTE> certValue;
									DWORD certValueLen;
									if (::CryptGetKeyParam(hKey, KP_CERTIFICATE, NULL, &certValueLen, 0))
                  {  
                    certValue.resize(certValueLen);
                    if (::CryptGetKeyParam(hKey, KP_CERTIFICATE, &certValue[0], &certValueLen, 0))
										{
                      //Display certificate common name.
                      cout<<"Certificate Common Name  : "<<getCertificateName(&certValue[0],certValue.size()).c_str()<<endl;
										}
									}
									//Destroy the handle to the key pair.
									::CryptDestroyKey(hKey);
								}
								
								//Destroy the handle to the key container.
								::CryptReleaseContext(hKeyProv, 0);
							}
              cout<<endl;
						}
            //After CryptEnumProviders returns false, the error code should be ERROR_NO_MORE_ITEMS - indicating that the enumeration succeeded, finding all key containers(otherwise an error has occurred).
						DWORD e = GetLastError();
						if (e != ERROR_NO_MORE_ITEMS)
						{
							cout<<"::CryptGetProvParam failed, error code = "<<hex<<e<<dec<<endl;
							rv = 2;
						}
            if(!kcWithKeyExist) cout<<"No key(s) / certificate(s) was found for this token."<<endl;
             
						//Release the "VERIFYCONTEXT"
						::CryptReleaseContext(hProv, 0);
					}
				}
				SCardFreeMemory(hContext,pProvider);
			}
      SCardFreeMemory(hContext,pCardNames);  
		}
    cout<<endl;
	}
  SCardFreeMemory(hContext,pReaderList);
  SCardReleaseContext(hContext);

  cout<<"Press the Enter key to exit..."<<endl;
  getchar ();
  return rv;
}
