/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

// Standard includes.

#include "stdlib.h"
#include "stdio.h"
#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#include <fcntl.h>
#endif

#include <vector>
using namespace std;

#include "eTPkcs11.h"

#ifdef _WIN32
#define pkcs11_path 			"etpkcs11.DLL"
#else
#define pkcs11_path				"libeTPkcs11.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

void init();
void displaysLibraryInfo();
void displaysTokenInfo(DWORD slotId);
#ifdef _WIN32
void displaysCertificate(BYTE* certValue, int certValueLen);
#endif

#ifdef _WIN32
#define THREAD HANDLE
#define CREATE_THREAD(a,p) a=CreateThread(NULL,0,p,NULL,0,NULL)
#define WAIT_THREAD(a,t) WaitForSingleObject(a,t)
#define CLOSE_THREAD(a) CloseHandle(a)
#else
#define THREAD pthread_t
#define CREATE_THREAD(a,p) pthread_create(&a, NULL, p, NULL)
#define WAIT_THREAD(a,t) pthread_join(a,NULL)
#define CLOSE_THREAD(a)
#endif

//Global variables. 
CK_FUNCTION_LIST_PTR   pFunctionList=NULL;
CK_C_GetFunctionList   pGFL    = 0;
bool                   wasInit = false; 
static THREAD 				 hThread = 0;

//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);

	if(wasInit)
  {
		// Close PKCS#11 library.
		if (CKR_OK != pFunctionList->C_Finalize(0))
		{
			printf ("C_Finalize failed...\n");
		}

		WAIT_THREAD(hThread, 5000);
//		if (hThread) { TerminateThread(hThread,0); CloseHandle(hThread); }

    hThread = 0;
    wasInit = false;
  }

	exit(message ? -1 : 0 );
}

//
//
#ifdef _WIN32
static DWORD __stdcall TokenNotifyThread(void*)
#else
void* TokenNotifyThread(void*)
#endif
{
	while (true) 
	{
		DWORD slotId;
		int res = pFunctionList->C_WaitForSlotEvent(0, &slotId, 0);
    
		if (res==CKR_OK) displaysTokenInfo(slotId);
    else break;
	}
	return 0;
}

//
//
int main()
{
  //Load and initialize PKCS#11 library.
  init();

  printf ("Wait for insertion/removal of the token or press any key to exit...\n");
  CREATE_THREAD(hThread, TokenNotifyThread);
	
	getchar();
  // Close PKCS#11 library.
  leave(NULL);
  return 0;
}

//
//
void init()
{
  // Load the library.
  HINSTANCE hLib = LoadLibrary(pkcs11_path);
  if (hLib == NULL)
  {
    leave ("Cannot load DLL.");
  }
  
  // Find the entry point of C_GetFunctionList.
#ifdef _WIN32
  (FARPROC&)pGFL= GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&pGFL= GetProcAddress(hLib, "C_GetFunctionList");
#endif
  if (pGFL == NULL) 
  {
    leave ("Cannot find GetFunctionList().");
  }

	//Get the function list.
  if (CKR_OK != pGFL(&pFunctionList))
  {
    leave ("Can't get function list. \n");
  }

  // Initialize the PKCS#11 library.
  //
  if (CKR_OK != pFunctionList->C_Initialize (0))
  {
    leave ("C_Initialize failed...\n");
  }                 
  wasInit = true;      
}

//
//
void displaysLibraryInfo()
{
  // Get information about the PKCS#11 library (See the definition of CK_INFO for more information).
  CK_INFO info;
  if (CKR_OK != pFunctionList->C_GetInfo (&info))
  {
    leave ("C_GetInfo failed...\n");
  }                       
  printf ("<Common Library information> \n\n");

  printf ("  PKCS #11 Version %d.%d\n", info.cryptokiVersion.major, info.cryptokiVersion.minor);
  printf ("         Manufacturer %.32s.\n", info.manufacturerID);
  printf ("         Description %.32s.\n", info.libraryDescription);
  printf ("         Library version %d.%d\n", info.libraryVersion.major, info.libraryVersion.minor);
}

//
//
void displaysTokenInfo(DWORD slotId)
{
  // Get the slot information. 
  //
  CK_SLOT_INFO slot_info;
  if (CKR_OK != pFunctionList->C_GetSlotInfo (slotId, &slot_info))
  {
    leave("C_GetSlotInfo failed...\n");
  }
	
	//Check if token exists in the slot and display its information. 
	printf ("\n\n     Slot#%d - %.32s: ",slotId,slot_info.slotDescription);
	
  if ( ! (slot_info.flags & CKF_TOKEN_PRESENT))
  {
    printf ("Token was removed\n",slotId);
    return;
  }

  // Get the token information.
  CK_TOKEN_INFO token_info;
  if (CKR_OK != pFunctionList->C_GetTokenInfo (slotId, &token_info))
  {
    leave ("C_GetTokenInfo failed...\n");
  }

  printf ("\n           <Common Token Information>\n", slot_info.slotDescription);

  //Display token information(see definition of CK_TOKEN_INFO for more information).
  printf ("                Label: %.32s\n", token_info.label);
  printf ("                Manufacturer: %.32s\n", token_info.manufacturerID);
  printf ("                Model: %.16s\n", token_info.model);
  printf ("                Serial number: %.16s\n", token_info.serialNumber);
  
  printf ("                Version hardware/firmware: %d.%d, %d.%d\n", token_info.hardwareVersion.major, token_info.hardwareVersion.minor,
                                                                      token_info.firmwareVersion.major, token_info.firmwareVersion.minor);
  printf ("                Current session count: %d\n", token_info.ulSessionCount);
  printf ("                Maximum session count: %d\n", token_info.ulMaxSessionCount);
  printf ("                Maximum RW session count: %d\n", token_info.ulMaxRwSessionCount);
  printf ("                PIN length: [%d..%d]\n", token_info.ulMinPinLen,
                                                   token_info.ulMaxPinLen);
  printf ("                Public memory: %d/%d bytes\n", token_info.ulFreePublicMemory,
                                                         token_info.ulTotalPublicMemory);
  printf ("                Private memory: %d/%d bytes\n", token_info.ulFreePrivateMemory,
                                                          token_info.ulTotalPrivateMemory);

  printf ("                Random number generator: ");
  if (token_info.flags & CKF_RNG)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Is write protected: ");
  if (token_info.flags & CKF_WRITE_PROTECTED)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Login required: ");
  if (token_info.flags & CKF_LOGIN_REQUIRED)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                User's PIN is set: ");
  if (token_info.flags & CKF_USER_PIN_INITIALIZED)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Restore key is not needed: ");
  if (token_info.flags & CKF_RESTORE_KEY_NOT_NEEDED)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Clock on token: ");
  if (token_info.flags & CKF_CLOCK_ON_TOKEN)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Has protected authentication path: ");
  if (token_info.flags & CKF_PROTECTED_AUTHENTICATION_PATH)
    printf ("Yes\n");
  else
    printf ("No\n");

  printf ("                Dual crypto operations: ");
  if (token_info.flags & CKF_DUAL_CRYPTO_OPERATIONS)
    printf ("Yes\n");
  else
    printf ("No\n");

  //Check RSA maximum key size.
	CK_MECHANISM_INFO mecInfo;
	if (CKR_OK == pFunctionList->C_GetMechanismInfo(slotId, CKM_RSA_PKCS, &mecInfo))			
	{
		printf ("                RSA Mechanism MaxKeySize: %d\n",mecInfo.ulMaxKeySize);
	}

	//Open a session and get the certifcates on the token.
  CK_SESSION_HANDLE session;
	if (CKR_OK != pFunctionList->C_OpenSession (slotId,(CKF_SERIAL_SESSION | CKF_RW_SESSION), 0, 0, &session))
	{
		leave ("C_OpenSession failed.\n");
	}                       

	//Find certificate handles.
	CK_BBOOL bFalse    = 0;
	CK_BBOOL bTrue     = 1;
	CK_ULONG classType = CKO_CERTIFICATE;
	CK_ULONG certType  = CKC_X_509;

	CK_ATTRIBUTE cert_template[]  = 
	{ 
		{CKA_CLASS,            &classType , sizeof(classType)},
		{CKA_CERTIFICATE_TYPE, &certType,   sizeof(certType)},
		{CKA_TOKEN,            &bTrue,      sizeof (bTrue)  },
	};

	CK_OBJECT_HANDLE hObject;
	CK_ULONG foundObjects = 0;

	if (CKR_OK == pFunctionList->C_FindObjectsInit(session, cert_template,sizeof(cert_template)/sizeof(cert_template[0])))
	{
		bool firstTime = true;
    while ((pFunctionList->C_FindObjects(session, &hObject, 1, &foundObjects) == CKR_OK)
				    && foundObjects > 0)
		{
			if (firstTime)
      {
        printf ("           <List of certificate information>\n");
        firstTime = false;
      }

      //Get certificate issuer, subject, and value attributes.
			CK_ATTRIBUTE cert_template[] = 
			{
				{ CKA_LABEL,   NULL, 0 },
				{ CKA_VALUE,   NULL, 0 },
			};

			if(CKR_OK == pFunctionList->C_GetAttributeValue(session,hObject,cert_template,sizeof(cert_template)/sizeof(cert_template[0])))
			{
				int certLabelLen = cert_template[0].ulValueLen;
				BYTE* labelValue = new BYTE [certLabelLen];
				cert_template[0].pValue = labelValue;

				int certValueLen = cert_template[1].ulValueLen;
				BYTE* certValue = new BYTE [certValueLen];
				cert_template[1].pValue = certValue;

				if(CKR_OK == pFunctionList->C_GetAttributeValue(session,hObject,cert_template,sizeof(cert_template)/sizeof(cert_template[0])))    
				{
					printf ("                Label: %.*s\n", certLabelLen,labelValue);

					#ifdef _WIN32
					//Certificate is written in ASN-1 format; use Windows Crypt32 API to display it.
					displaysCertificate(certValue,certValueLen);
					#endif

				} 
        delete [] labelValue; 
        delete [] certValue;
			}
    }
    pFunctionList->C_FindObjectsFinal(session);
		// Close session.
		pFunctionList->C_CloseSession (session);
  }
}

//Relevant only for windows:
//Use Windows Crypt32 API to display a certificate in ASN-1 format.
//See MSDN for other display options.
//
#ifdef _WIN32
void displaysCertificate(BYTE* certValue, int certValueLen)
{
	char pszNameString[256]; 
	PCCERT_CONTEXT pCertContext = NULL; 

  //Create certificate context.
  if(pCertContext = CertCreateCertificateContext( PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
																									certValue,
																									certValueLen))
	{
		//Get certificate friendly name.
    if (CertGetNameString(pCertContext, 
													CERT_NAME_SIMPLE_DISPLAY_TYPE, 
                          0,
													NULL,   
													pszNameString,   
													sizeof(pszNameString)) != 0)
		{
      printf ("                Subject Name: %s\n",pszNameString);
		}

		// When finished, free the certificate context.
		CertFreeCertificateContext(pCertContext);
	}
}
#endif

