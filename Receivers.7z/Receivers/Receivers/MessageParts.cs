﻿using System;

namespace SMEVPaymentReceivers
{
    public static class SMEVMessageParts
    {
        public const string MessageHeader =
            "<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                "xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" " +
                "xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" +
            "<env:Header>" +
            "<wsse:Security env:actor=\"http://smev.gosuslugi.ru/actors/smev\">" +
                "<ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">" +
                    "<ds:KeyInfo>" +
                        "<wsse:SecurityTokenReference>" +
                            "<wsse:Reference URI=\"#SenderCertificate\" />" +
                        "</wsse:SecurityTokenReference>" +
                    "</ds:KeyInfo>" +
                "</ds:Signature>" +
                "<wsse:BinarySecurityToken EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\" " +
                       "ValueType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3\" " +
                       "wsu:Id=\"SenderCertificate\">" +
                "</wsse:BinarySecurityToken>" +
            "</wsse:Security>" +
        "</env:Header>" +
        "<env:Body xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" " +
            "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" wsu:Id=\"body\">";

        public const string PaymentReceiversRequest =
            "<rev:exportPaymentReceiverRequest xmlns:rev=\"http://smev.gosuslugi.ru/rev120315\">" +
                "<rev:Message>" +
                        "<rev:Sender>" +
                            "<rev:Code>RCPT00001</rev:Code>" +
                            "<rev:Name>Получатель</rev:Name>" +
                        "</rev:Sender>" +
                        "<rev:Recipient>" +
                            "<rev:Code>MNSV10001</rev:Code>" +
                            "<rev:Name>Минкомсвязь РФ</rev:Name>" +
                        "</rev:Recipient>" +
                        "<rev:ServiceName>MNSV10payGKH</rev:ServiceName>" +
                        "<rev:TypeCode>GFNC</rev:TypeCode>" +
                        "<rev:Status>REQUEST</rev:Status>" +
                        "<rev:Date>2018-06-28T10:00:00</rev:Date>" +
                        "<rev:ExchangeType>2</rev:ExchangeType>" +
                    "</rev:Message>" +
                    "<rev:MessageData>" +
                        "<rev:AppData>" +
                            "<rev:PaymentReceiversRequest>" +
                                "<rev:Full>true</rev:Full>" +
                            "</rev:PaymentReceiversRequest>" +
                        "</rev:AppData>" +
                    "</rev:MessageData>" +
                "</rev:exportPaymentReceiverRequest>" +
            "</env:Body>" +
        "</env:Envelope>";

        public const string PaymentReceiversStatus =
            "<rev:getStateRequest xmlns:rev=\"http://smev.gosuslugi.ru/rev120315\">" +
                "<rev:Message>" +
                    "<rev:Sender>" +
                        "<rev:Code>RCPT00001</rev:Code>" +
                        "<rev:Name>Получатель</rev:Name>" +
                    "</rev:Sender>" +
                    "<rev:Recipient>" +
                        "<rev:Code>MNSV10001</rev:Code>" +
                        "<rev:Name>Минкомсвязь РФ</rev:Name>" +
                    "</rev:Recipient>" +
                    "<rev:ServiceName>MNSV10payGKH</rev:ServiceName>" +
                    "<rev:TypeCode>GFNC</rev:TypeCode>" +
                    "<rev:Status>PING</rev:Status>" +
                    "<rev:Date>2018-06-28T00:00:00</rev:Date>" +
                    "<rev:ExchangeType>2</rev:ExchangeType>" +
                "</rev:Message>" +
                "<rev:MessageData>" +
                    "<rev:AppData>" +
                        "<rev:AcknowledgmentRequest>" +
                            "<rev:MessageGUID></rev:MessageGUID>" +
                        "</rev:AcknowledgmentRequest>" +
                    "</rev:AppData>" +
                "</rev:MessageData>" +
            "</rev:getStateRequest>" +
        "</env:Body>" +
    "</env:Envelope>";

    }

}
