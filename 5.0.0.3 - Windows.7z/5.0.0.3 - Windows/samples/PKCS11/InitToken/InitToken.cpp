/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#include <fcntl.h>
#endif

#include "eTPkcs11.h"

#ifdef _WIN32
#define pkcs11_path 			"etpkcs11.DLL"
#else
#define pkcs11_path				"libeTPkcs11.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

#include <algorithm>
using namespace std;

//Global variables. 
CK_FUNCTION_LIST_PTR   pFunctionList;
CK_C_GetFunctionList   pGFL  = 0;
CK_SESSION_HANDLE      session;
CK_SLOT_ID*            slots;
unsigned long          slot_count;

void genKeyPair();
CK_OBJECT_HANDLE find_object (CK_SESSION_HANDLE hSess,CK_ATTRIBUTE * t,CK_ULONG size);

bool wasInit = false;

//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave (char * c)
{
  delete slots;
  
  if(wasInit)
  {
		// Close PKCS#11 library.
		if (CKR_OK != pFunctionList->C_Finalize(0))
		{
			printf ("C_Finalize failed...\n");
		}
    wasInit = false;
  }

  printf ("%s\n", (c == NULL? "OPERATION SUCCESS" : c));
  printf ("Press the Enter key to exit...");
  getchar ();
  exit (c == NULL? 0 : -1);
}

void init()
{
  // Load the library.
  HINSTANCE hLib = LoadLibrary(pkcs11_path);
  if (hLib == NULL)
  {
    leave ("Cannot load DLL.");
  }
  
  // Find the entry point of C_GetFunctionList.
#ifdef _WIN32
  (FARPROC&)pGFL= GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&pGFL= GetProcAddress(hLib, "C_GetFunctionList");
#endif
  if (pGFL == NULL) 
  {
    leave ("Cannot find GetFunctionList().");
  }

	//Get the function list.
  if (CKR_OK != pGFL(&pFunctionList))
  {
    leave ("Cannot get function list. \n");
  }

  // Initialize the PKCS #11 library.
  //
  if (CKR_OK != pFunctionList->C_Initialize (0))
  {
    leave ("C_Initialize failed...\n");
  }              
  wasInit = true;

  printf ("Load Pkcs#11 Dll and get function list.\n");
}

unsigned long selectSlot(char* readerName)
{
	// Get all the occupied slots.
	//
	unsigned long slot_index = 0;

  printf ("Get all the occupied slots\n");
	if (CKR_OK == pFunctionList->C_GetSlotList(true, NULL, &slot_count))
	{
		if (slot_count < 1)
		{
			leave ("No eToken is available.\n");
		}

		slots = new CK_SLOT_ID [slot_count];
		if (CKR_OK != pFunctionList->C_GetSlotList (true, slots, &slot_count))
		{
			leave ("C_GetSlotList failed...\n");
		}
	}
	else
	{
		leave ("C_GetSlotList failed...\n");
	}
  
	// Get the selected slot information.
	//
	bool found = false;
  std::transform(readerName,readerName + strlen(readerName),readerName,tolower);
  for (slot_index; slot_index < slot_count; slot_index++)
	{
		CK_SLOT_INFO slot_info;
		if (CKR_OK != pFunctionList->C_GetSlotInfo (slots[slot_index], &slot_info))
		{
			leave ("C_GetSlotInfo failed.\n");
		}
   	std::transform(slot_info.slotDescription,slot_info.slotDescription + sizeof(slot_info.slotDescription),slot_info.slotDescription,tolower);
    if(memcmp((void*)slot_info.slotDescription,readerName,min(strlen(readerName),sizeof(slot_info.slotDescription))) == 0)
    {    
			found = true;
      break;  
    }
	}
  return found? slot_index : 0; //If not found, work with slot 0.
}

//
//
int main(int argc, char* argv[])
{
  if(argc < 4)
  {
    leave("Usage:\n"
          "   InitToken <reader-name> <format-password> <user-password>\n"
          "     Example: InitToken \"AKS ifdh 0\" 1234567890 password\n");
  }
  
  char* readerName = argv[1];
  char* formatPassword = argv[2];
  char* userPassword = argv[3];

  printf("Command line params: \n");
  printf(" reader name(%s)\n",readerName);
  printf(" format password(%s)\n",formatPassword);
  printf(" user password(%s)\n",userPassword);
  
  //Load and initialize the PKCS#11 library.
  init();

  //Insert command line argument for reader name ("AKS ifdh n").
  int slot_index = selectSlot(readerName);

  printf ("Initialize token with format password\n");
  CK_CHAR token_label[] = { "eToken" };
  if (CKR_OK != pFunctionList->C_InitToken(slots[slot_index], CK_CHAR_PTR(formatPassword), strlen(formatPassword), token_label))
  {
    leave ("C_InitToken failed.\n");
  }    

  // Open a read/write session on the eToken.
  //
  printf ("Open session\n");
  if (CKR_OK != pFunctionList->C_OpenSession (slots[slot_index],(CKF_SERIAL_SESSION | CKF_RW_SESSION), 0, 0, &session))
  {
    leave ("C_OpenSession failed.\n");
  }                       

  // Login as SO.
  //
  printf ("Logging in to eToken as SO with password - %s\n",formatPassword);
  if (CKR_OK != pFunctionList->C_Login (session, CKU_SO, CK_CHAR_PTR(formatPassword), strlen(formatPassword)))
  {
    leave ("C_Login failed.\n");
  }

  // Initialize USER PIN.
  //
  printf ("Initialize USER PIN to %s\n",userPassword);
  if (CKR_OK != pFunctionList->C_InitPIN (session, CK_CHAR_PTR(userPassword), strlen(userPassword)))
  {
    leave ("C_InitPIN failed.\n");
  }

  // Logout.
  //
  printf ("Logout\n");
  if (CKR_OK != pFunctionList->C_Logout (session))
  {
    leave ("C_Logout failed.\n");
  }

  // Check new USER PIN.
  //
  printf ("Logging in to eToken as USER with - %s \n",userPassword);
  if (CKR_OK != pFunctionList->C_Login (session, CKU_USER, CK_CHAR_PTR(userPassword), strlen(userPassword)))
  {
    leave ("C_Login failed.\n");
  }
  
  //Show how to generate RSA key pair.
  //
  genKeyPair();

  // Logout.
  //
  printf ("Logout\n");
  if (CKR_OK != pFunctionList->C_Logout (session))
  {
    leave ("C_Logout failed.\n");
  }

  printf ("Close session\n");
  if (CKR_OK != pFunctionList->C_CloseSession (session))
  {
    leave ("C_CloseSession failed.\n");
  }                       

  // Close PKCS#11 library.
  leave(NULL);
  return 0;
}

//This function shows how to generate an RSA key pair.
void genKeyPair()
{
  CK_BBOOL         bFalse = 0;
  CK_BBOOL         bTrue = 1;
  CK_KEY_TYPE      key_type  = CKK_RSA;

  CK_CHAR label_public[] = { "My public key" };  //Label of public key.
  CK_CHAR label_private[] = { "My private key" }; //Label of private key.
  
  // Setup public key attributes.
  //
  CK_OBJECT_CLASS  class_public_key = CKO_PUBLIC_KEY;
  CK_ULONG         vecModulusBits[] = {1024};
  CK_BYTE          public_exponent[] = { 0x01, 0x00, 0x01 };

  CK_ATTRIBUTE public_key_template[] = 
  {
    { CKA_CLASS,    &class_public_key,  sizeof (class_public_key) },
    { CKA_LABEL,    label_public,       sizeof (label_public) },
    { CKA_KEY_TYPE, &key_type,          sizeof (key_type) },
    { CKA_TOKEN,    &bTrue,             sizeof (bTrue) },
    { CKA_PRIVATE,  &bFalse,            sizeof (bFalse) },
    { CKA_MODULUS_BITS, &vecModulusBits[0],  sizeof (vecModulusBits[0]) },
    { CKA_PUBLIC_EXPONENT, &public_exponent, sizeof (public_exponent) },
  };

  // Setup private key attributes.
  //
  CK_OBJECT_CLASS  class_private_key = CKO_PRIVATE_KEY;
  CK_ATTRIBUTE private_key_template[] = 
  {
    { CKA_CLASS,    &class_private_key, sizeof (class_private_key) },
    { CKA_LABEL,    label_private,      sizeof (label_private) },
    { CKA_KEY_TYPE, &key_type,          sizeof (key_type) },
    { CKA_TOKEN,    &bTrue,             sizeof (bTrue) },
    { CKA_PRIVATE,  &bTrue,             sizeof (bTrue) },
  };

  // Setup mechanism to generate RSA key pair.
  //
	CK_MECHANISM mechanism;
	memset (&mechanism, 0, sizeof (mechanism));
	mechanism.mechanism = CKM_RSA_PKCS_KEY_PAIR_GEN;

  CK_OBJECT_HANDLE public_key;
  CK_OBJECT_HANDLE private_key;

	// Setup a PKCS#11 attribute list for constructing the
	// public user information that will be put on the eToken
	//
	CK_OBJECT_CLASS  class_data    = CKO_DATA;
	CK_CHAR          app_name[]    = { "eToken" };
	static CK_CHAR   user_object[] = { "ISP User Information" };
	CK_CHAR          user_name[]   = { "John_Smith" };

	CK_ATTRIBUTE user[] = 
	{
	  { CKA_CLASS,        &class_data,    sizeof (class_data) },
	  { CKA_TOKEN,        &bTrue,         sizeof (bTrue) },
	  { CKA_APPLICATION,  app_name,       sizeof (app_name) },
	  { CKA_LABEL,        user_object,    sizeof (user_object) },
	  { CKA_VALUE,        user_name,      sizeof (user_name) },
	};
  
  //Try to find the two keys using the find_object utility function if it exists,
  //or generate a new key pair.
  private_key = find_object (session, private_key_template, 1);
  public_key = find_object (session,  public_key_template,  1);
  
  if ( ! (public_key && private_key))
  {
		printf ("Wait for RSA PKCS#11 key pair generation ... \n");
  
    if( CKR_OK != pFunctionList->C_GenerateKeyPair (session,&mechanism, public_key_template, 7,
                                                      private_key_template,5,
                                                      &public_key,
                                                      &private_key))
    { 
      pFunctionList->C_Logout (session);
      pFunctionList->C_CloseSession (session);
      leave ("C_GenerateKeyPair failed.  Please run InitToken first.");
    }
  }
}

//
// Small utility function to search for a particular object containing the attribute 't'
CK_OBJECT_HANDLE find_object (CK_SESSION_HANDLE hSess, CK_ATTRIBUTE * t, CK_ULONG size)
{
  // Initialize the search for any object with attribute 't'
  if (CKR_OK != pFunctionList->C_FindObjectsInit (hSess, t, size))
  {
    leave ("C_FindObjectsInit failed.\n");
  }
  
  CK_OBJECT_HANDLE list[1];
	CK_ULONG found = 0;

  // Find matching objects. There should be only a single match
  // as there is only one on the eToken.
  if (CKR_OK != pFunctionList->C_FindObjects (hSess, list, 1, &found))
  {
    leave ("C_FindObjects failed.\n");
  }
  	
  // Clean up the search.
  //
	if (CKR_OK != pFunctionList->C_FindObjectsFinal (hSess))
  {
    leave ("C_FindObjectsFinal failed.\n");
  }

  // Return NULL if no match is found, otherwise return the object handles
  // of the matching object.
  //
  if (found < 1)
    return (0);

	return (list[0]);
}










