﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.IO.Compression;

namespace SMEVPaymentReceivers
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTie
            Console.WriteLine(DateTime.Now.toString());
            Console.ReadKey();

            X509Certificate2 cert = LoadCertificate("bartsev@mail.ru");

            if (cert == null)
            {
                Console.WriteLine("Certificate not found");
                Console.ReadKey();
                return;
            }

            string guid = "";
            if (!SendRequest(cert, ref guid))
            {
                Console.WriteLine("SendRequest fails");
                Console.ReadKey();
                return;
            }

            if (!SendStatus(cert, guid))
            {
                Console.WriteLine("SendStatus fails");
                Console.ReadKey();
                return;
            }

            LoadReceiversList();

        }

        static void LoadReceiversList() 
        {
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load("status_resp.xml");
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmldoc.NameTable);
            nsmgr.AddNamespace("ns3", "http://smev.gosuslugi.ru/rev120315");
            XmlNode data = xmldoc.SelectSingleNode("//ns3:BinaryData", nsmgr);
            if (data == null)
            {
                Console.WriteLine("BinaryData not found");
                Console.ReadKey();
                return;
            }
            MemoryStream stream = new MemoryStream(Convert.FromBase64String(data.InnerXml));
            ZipArchive zip = new ZipArchive(stream, ZipArchiveMode.Read);
            ZipArchiveEntry entry = zip.GetEntry("Получатели платежа.xml");
            if (entry != null)
            {
                String buffer;
                using (StreamReader reader = new StreamReader(entry.Open()))
                {
                    buffer = reader.ReadToEnd();
                }
                using (StreamWriter writer = new StreamWriter("data.xml"))
                {
                    writer.Write(buffer);
                }
            }
        }
        
        static bool SendStatus(X509Certificate2 Certificate, string guid)
        {
            string action = "urn:async_getResult";

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.LoadXml(SMEVMessageParts.MessageHeader + SMEVMessageParts.PaymentReceiversStatus);

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmldoc.NameTable);
            nsmgr.AddNamespace("ns3", "http://smev.gosuslugi.ru/rev120315");
            XmlNode node = xmldoc.SelectSingleNode("//ns3:MessageGUID", nsmgr);
            node.InnerXml = guid;

            // Подписываем запрос
            SignXmlFile(xmldoc, Certificate);

            return SendRequest(xmldoc, action);
//            respDoc.Save("status_resp.xml");  ?????????????

        }

        static bool SendRequest(X509Certificate2 Certificate, ref string guid)
        {
            
            string action = "urn:async_exportPaymentReceiver";

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.LoadXml(SMEVMessageParts.MessageHeader + SMEVMessageParts.PaymentReceiversRequest);

            // Подписываем запрос
            SignXmlFile(xmldoc, Certificate);

            return SendRequest(xmldoc, action);

        }

        static bool SendRequest(XmlDocument xmldoc, string SoapAction)
        {
            string uri = "http://smev-mvf.test.gosuslugi.ru:7777/gateway/services/SID0004768";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.Credentials = CredentialCache.DefaultCredentials;
            request.Headers.Add("SOAPAction", SoapAction);
            request.ContentType = "text/xml;charset=\"utf-8\"";
            request.Method = "POST";
            StreamWriter writer = new StreamWriter(request.GetRequestStream());
            writer.Write(xmldoc.OuterXml);
            writer.Close();
            request.GetRequestStream().Flush();
            int err = 0;
            string errDescription = string.Empty;
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException wex)
            {
                err = 10001;
                errDescription = wex.Message;
                response = (HttpWebResponse)wex.Response;
                return false;
            }
            XmlDocument respDoc = new XmlDocument();
            respDoc.PreserveWhitespace = true;
            StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.GetEncoding("utf-8"));
            respDoc.LoadXml(reader.ReadToEnd());

            if (err > 0)
            {
                Console.WriteLine("Найдены ошибки при передаче сообщения: " + errDescription);
                return false;
            }
            else
            {
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(respDoc.NameTable);
                nsmgr.AddNamespace("ns3", "http://smev.gosuslugi.ru/rev120315");
                XmlNode node = respDoc.SelectSingleNode("//ns3:MessageGUID", nsmgr);
                if (node == null)
                {
                    return false;
                }
                else
                {
                    guid = node.InnerXml;
                }
                // Проверяете подпись (я испеользую КриптоПро .NET, пример есть у них на сайте)
                //                VerifyXmlData(respDoc);
                //Обрабатываете результат respDoc.OuterXml
                //можете отправить его, как результат работы вашего wcf сервиса
            }
            response.Close();
            return true;

        }

        static X509Certificate2 LoadCertificate(string subject)
        {
            X509Store store = new X509Store(StoreLocation.CurrentUser);
            store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);
            X509Certificate2Collection certs =
                store.Certificates.Find(X509FindType.FindBySubjectName, subject, false);

            // Проверяем, что нашли ровно один сертификат.
            if (certs.Count == 0)
            {
                Console.WriteLine("Сертификат не найден.");
                Console.ReadKey();
                return null;
            }
            if (certs.Count > 1)
            {
                Console.WriteLine("Найдено более одного сертификата.");
                Console.ReadKey();
                return null;
            }

            return certs[0];
        }

//        static void SignXmlFile(string FileName, string SignedFileName, X509Certificate2 Certificate)
        static void SignXmlFile(XmlDocument XmlDoc, X509Certificate2 Certificate)
        {

            // Создаём объект SmevSignedXml - наследник класса SignedXml с перегруженным GetIdElement
            // для корректной обработки атрибута wsu:Id. 
            SmevSignedXml signedXml = new SmevSignedXml(XmlDoc);

            // Задаём ключ подписи для документа SmevSignedXml.
            signedXml.SigningKey = Certificate.PrivateKey;

            // Создаем ссылку на подписываемый узел XML. В данном примере и в методических
            // рекомендациях СМЭВ подписываемый узел soapenv:Body помечен идентификатором "body".
            Reference reference = new Reference();
            reference.Uri = "#body";

            // Задаём алгоритм хэширования подписываемого узла - ГОСТ Р 34.11-94. Необходимо
            // использовать устаревший идентификатор данного алгоритма, т.к. именно такой
            // идентификатор используется в СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            reference.DigestMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete;
#pragma warning restore 612

            // Добавляем преобразование для приведения подписываемого узла к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            XmlDsigExcC14NTransform c14 = new XmlDsigExcC14NTransform();
            reference.AddTransform(c14);

            // Добавляем ссылку на подписываемый узел.
            signedXml.AddReference(reference);

            // Задаём преобразование для приведения узла ds:SignedInfo к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            signedXml.SignedInfo.CanonicalizationMethod = SignedXml.XmlDsigExcC14NTransformUrl;

            // Задаём алгоритм подписи - ГОСТ Р 34.10-2001. Необходимо использовать устаревший
            // идентификатор данного алгоритма, т.к. именно такой идентификатор используется в
            // СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            signedXml.SignedInfo.SignatureMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3410UrlObsolete;
#pragma warning restore 612

            // Вычисляем подпись.
            signedXml.ComputeSignature();

            // Получаем представление подписи в виде XML.
            XmlElement xmlDigitalSignature = signedXml.GetXml();

            // Добавляем необходимые узлы подписи в исходный документ в заготовленное место.
            XmlDoc.GetElementsByTagName("ds:Signature")[0].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignatureValue")[0], true));
            XmlDoc.GetElementsByTagName("ds:Signature")[0].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignedInfo")[0], true));

            // Добавляем сертификат в исходный документ в заготовленный узел
            // wsse:BinarySecurityToken.
            XmlDoc.GetElementsByTagName("wsse:BinarySecurityToken")[0].InnerText =
                Convert.ToBase64String(Certificate.RawData);

        }

        // Класс SmevSignedXml - наследник класса SignedXml с перегруженным
        // GetIdElement для корректной обработки атрибута wsu:Id. 
        class SmevSignedXml : SignedXml
        {
            public SmevSignedXml(XmlDocument document): base(document)
            {
            }

            public override XmlElement GetIdElement(XmlDocument document, string idValue)
            {
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(document.NameTable);
                nsmgr.AddNamespace("wsu", WSSecurityWSUNamespaceUrl);
                return document.SelectSingleNode("//*[@wsu:Id='" + idValue + "']", nsmgr) as XmlElement;
            }
        }

        public const string WSSecurityWSSENamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
        public const string WSSecurityWSUNamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

    }
}
