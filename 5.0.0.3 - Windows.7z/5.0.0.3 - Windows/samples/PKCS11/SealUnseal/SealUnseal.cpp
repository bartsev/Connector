/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rigc_lhts, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

#include "eTPkcs11.h"

CK_BYTE                ck_True          = TRUE;
CK_BYTE                ck_False         = FALSE;
CK_OBJECT_CLASS        cko_Data         = CKO_DATA;
CK_OBJECT_CLASS        cko_Cert         = CKO_CERTIFICATE;
CK_OBJECT_CLASS        cko_PubKey       = CKO_PUBLIC_KEY;
CK_OBJECT_CLASS        cko_PrvKey       = CKO_PRIVATE_KEY;
CK_OBJECT_CLASS        cko_SecretKey    = CKO_SECRET_KEY;
CK_KEY_TYPE            ckk_RSA          = CKK_RSA;
CK_KEY_TYPE            ckk_DES          = CKK_DES;
CK_KEY_TYPE            ckk_DES3         = CKK_DES3;
CK_CERTIFICATE_TYPE    ckc_X_509        = CKC_X_509;
CK_MECHANISM           ckm_DES3_KEY_GEN = {CKM_DES3_KEY_GEN, NULL, 0};
CK_MECHANISM           ckm_RSA_PKCS     = {CKM_RSA_PKCS,     NULL, 0};
CK_MECHANISM           ckm_SHA_1        = {CKM_SHA_1,        NULL, 0};

#define sizeofarray(a) (sizeof(a)/sizeof(a[0]))

// Helper class for a generic buffer.
struct Blob : DATA_BLOB // {BYTE* pbData, DWORD cbData}
{
  Blob()                           { init(); }
  ~Blob()                          { clear(); }
  
  void init()                      { cbData=0; pbData=NULL; }
  void clear()                     { zero(); free(pbData); init(); }

  Blob(DWORD cb)                   { init(); resize(cb); zero(); }
  Blob(LPCBYTE p, DWORD cb)        { init(); assign(p, cb); }
  Blob(const Blob& b)              { init(); assign(b); }
  Blob(LPCSTR s)                   { init(); assign(s); }

  void zero()                      { memset(pbData,0,cbData); }
  void resize(DWORD cb)            { pbData=(LPBYTE)realloc(pbData, cbData=cb); }
  void assign(LPCBYTE p, DWORD cb) { resize(cb); memmove(pbData, p, cb); }
  void assign(const Blob& b)       { assign(b.pbData, b.cbData); }
  void assign(LPCSTR s)            { assign((LPCBYTE)s, strlen(s)+1); }
  BOOL read(FILE* file);
  BOOL write(FILE* file);
};

// Read BLOB data from a file.
BOOL Blob::read(FILE* file) 
{ 
  DWORD cb; 
  if (!fread(&cb, 1, sizeof(DWORD), file)) return FALSE;
  if (cb>65536) return FALSE; 
  resize(cb); 
  return fread(pbData, 1, cbData, file); 
}

// Write BLOB data to the file.
BOOL Blob::write(FILE* file)
{ 
  if (!fwrite(&cbData, 1, sizeof(DWORD), file)) return FALSE;
  return fwrite(pbData, 1, cbData, file); 
}

// Displays an error string and terminates the application.
void Abort(int rv, LPCSTR text)
{
  if (rv==0)       printf("%s\n",text);
  else if (rv==-1) printf("[WIN32 error 0x%08lx] %s\n", rv=GetLastError(), text);
  else             printf("[PKI error 0x%08lx] %s\n", rv, text);

	printf("\n\n");
  printf("Press the Enter Key to exit");
  
	getchar();
  exit(rv);
}

void Syntax()
{
  Abort(0, "Usage:\n"
           "   SealUnseal <seal/unseal operation> <password> <source-file> <destination-file>\n"
           "   Example: SealUnseal seal 1234567890 source.txt dest.bin\n"); 
}

//Path to PKCS#11 dll.
#define pkcs11_path "ETPKCS11.DLL" 

//Global variables.
HINSTANCE              hPkcs11Lib = NULL;  // Library handle
CK_FUNCTION_LIST_PTR   fl         = NULL;  // Function list

// Load and initialize the eToken PKCS#11 library.
void PkiInitialize()
{
  // Load the library.
  hPkcs11Lib = LoadLibrary(pkcs11_path);
  if (!hPkcs11Lib) Abort(-1, "Cannot load eToken PKCS#11 library");
  
  // Find the entry point of C_GetFunctionList.
  CK_C_GetFunctionList pGFL  = 0;
  (FARPROC&)pGFL= GetProcAddress(hPkcs11Lib, "C_GetFunctionList");
  if (!pGFL) Abort(-1, "Cannot find C_GetFunctionList()");

	//Get the function list.
  int rv = pGFL(&fl);
  if (rv != CKR_OK) Abort(rv, "C_GetFunctionList() failed");

  // Initialize the PKCS#11 library.
  rv = fl->C_Initialize(0);
  if (rv != CKR_OK) Abort(rv, "C_Initialize() failed");
}

// Close the PKCS#11 library.
void PkiFinalize()
{ 
  fl->C_Finalize(0);
  FreeLibrary(hPkcs11Lib);
}

// Select the first inseted token.
CK_SLOT_ID SelectToken()
{
  // Get a slot list with eTokens.
  ULONG nSlotCount;
  int rv = fl->C_GetSlotList(TRUE, NULL, &nSlotCount);
  if (rv!=CKR_OK) Abort(rv, "C_GetSlotList failed");

  if (nSlotCount<1) Abort(0, "No eToken inserted was found");

  CK_SLOT_ID* pSlots = new CK_SLOT_ID [nSlotCount];
  rv = fl->C_GetSlotList(TRUE, pSlots, &nSlotCount);
  if (rv!=CKR_OK) Abort(rv, "C_GetSlotList failed");

  // Select the first available slot
  CK_SLOT_ID SlotID = pSlots[0];

  delete pSlots;
  return SlotID;
}

// Open a PKCS#11 session.
CK_SESSION_HANDLE OpenSession(CK_SLOT_ID SlotID)
{
  CK_SESSION_HANDLE hSession = NULL;
  int rv = fl->C_OpenSession (
    SlotID, 
    CKF_SERIAL_SESSION | CKF_RW_SESSION, 
    0, 
    0, 
    &hSession);
  if (rv!=CKR_OK) Abort(rv, "C_OpenSession failed");

  return hSession;
}

// Read the certificate from the eToken.
void ReadCertificateValue(CK_SESSION_HANDLE hSession, CK_OBJECT_HANDLE hCertificate, Blob& Certificate)
{
  // Get the attribute's size.
  CK_ATTRIBUTE ValueTemplate  = {CKA_VALUE, NULL, 0};
  int rv = fl->C_GetAttributeValue(hSession, hCertificate, &ValueTemplate, 1);
  if (rv) Abort(rv, "Cannot read a certificate from the eToken");

  // Read it.
  Certificate.resize(ValueTemplate.ulValueLen);
  ValueTemplate.pValue = Certificate.pbData;
  rv = fl->C_GetAttributeValue(hSession, hCertificate, &ValueTemplate, 1);
  if (rv) Abort(rv, "Cannot read a certificate from the eToken");
}

// Decode a certificate's display name.
void GetCertificateName(Blob& Certificate, Blob& Name)
{
  // Create a temporary certificate context.
	PCCERT_CONTEXT pCertContext = CertCreateCertificateContext(PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
		Certificate.pbData, 
    Certificate.cbData);
  if (!pCertContext) Abort(-1, "CertCreateCertificateContext failed");

  // Extract the display name.
  DWORD cbName = CertGetNameString(   
       pCertContext,   
       CERT_NAME_SIMPLE_DISPLAY_TYPE,
       0,   
       NULL, 
       NULL,   
       0);
  if (cbName==0) Abort(-1, "CertGetNameString failed");
  Name.resize(cbName);
  CertGetNameString(   
       pCertContext,   
       CERT_NAME_SIMPLE_DISPLAY_TYPE,
       0,   
       NULL, 
       (LPSTR)Name.pbData,   
       cbName);

	// When finished, free the certificate context.
  CertFreeCertificateContext(pCertContext);
}

// List a certificate's names and select a certificate.
void SelectCertificate(CK_SESSION_HANDLE hSession, Blob& Certificate)
{
  // List all of certificates on the eToken.
  CK_ATTRIBUTE EnumCertTemplate[]  = 
  { 
    {CKA_CLASS,            &cko_Cert,  sizeof(cko_Cert)},
    {CKA_CERTIFICATE_TYPE, &ckc_X_509, sizeof(ckc_X_509)},
    {CKA_TOKEN,            &ck_True,   sizeof(ck_True)},
  };
  int rv = fl->C_FindObjectsInit(hSession, EnumCertTemplate, sizeofarray(EnumCertTemplate));
  if (rv) Abort(rv, "Cannot enumerate certificates");

  const ULONG nCertMax = 100;
  CK_OBJECT_HANDLE CertList[nCertMax];
  ULONG nCertCount;
  rv = fl->C_FindObjects(hSession, CertList, nCertMax, &nCertCount);
  if (rv) Abort(rv, "Cannot enumerate certificates");
  if (nCertCount==0) Abort(0, "No certificate found on the eToken");

  fl->C_FindObjectsFinal(hSession);

  // Display the certificate's names.
  for (ULONG i=0; i<nCertCount; i++)
  {
    ReadCertificateValue(hSession, CertList[i], Certificate);
    Blob Name;
    GetCertificateName(Certificate, Name);
    printf ("  #%d: %s\n",i, Name.pbData);
  }

  // Input an index in the list.
  printf("Please type index: ");
  ULONG nIndex = 0;
  if (1!=scanf("%d", &nIndex)) Abort(0,"Input error");
  if (nIndex>=nCertCount) Abort(0,"Invalid certificate index");
  printf("\n");
 
  // Read the value of the selected certificate.
  ReadCertificateValue(hSession, CertList[nIndex], Certificate);
}

// Extract the certificate's public key components.
void ExtractCertPubKey(Blob& Certificate, Blob& Modulus, Blob& PubExp)
{
  // Create a temparary certificate context.
  PCCERT_CONTEXT pCertContext = CertCreateCertificateContext( PKCS_7_ASN_ENCODING | X509_ASN_ENCODING,
    Certificate.pbData, 
    Certificate.cbData);
  if (!pCertContext) Abort(-1, "CertCreateCertificateContext failed");

  // Extract the public key BLOB from the certificate context.
  CERT_PUBLIC_KEY_INFO& PubKeyInfo = pCertContext->pCertInfo->SubjectPublicKeyInfo;
  CRYPT_BIT_BLOB& BitBlob = PubKeyInfo.PublicKey;
  DWORD cbPubKeyBlob = 0;
  if (!CryptDecodeObject(X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 
	  RSA_CSP_PUBLICKEYBLOB,
		BitBlob.pbData,
		BitBlob.cbData,
		0,
		NULL,
		&cbPubKeyBlob)) Abort(-1, "CryptDecodeObject failed");
  Blob PubKeyBlob(cbPubKeyBlob);
  if (!CryptDecodeObject(X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 
	  RSA_CSP_PUBLICKEYBLOB,
		BitBlob.pbData,
		BitBlob.cbData,
		0,
		PubKeyBlob.pbData,
		&cbPubKeyBlob)) Abort(-1, "CryptDecodeObject failed");

  // Deal with the Microsoft public key BLOB structure.
	BLOBHEADER* pHeader    = (BLOBHEADER*)PubKeyBlob.pbData;
  RSAPUBKEY*  pRsaPubKey = (RSAPUBKEY*)(pHeader + 1);            
  LPBYTE      pPubExp    = (LPBYTE)&pRsaPubKey->pubexp;
  LPBYTE      pModulus   = (LPBYTE)(pRsaPubKey + 1);
  int         cbKey      = pRsaPubKey->bitlen / 8;

  // Unpad and reverse a copy of the public exponent.
  BYTE PubExpBuf[sizeof(DWORD)];
  int cbPubExp = 0;
  BYTE Pad = TRUE;
  for (int i=sizeof(DWORD)-1; i>=0; i--)
  {
    BYTE x = pPubExp[i];
    if (x) Pad = FALSE;
    if (!Pad) PubExpBuf[cbPubExp++] = x;
  }
  PubExp.assign(PubExpBuf,cbPubExp);

  // Reverse copy of modulus.
  Modulus.resize(cbKey);
  for (int i=0; i<cbKey; i++) Modulus.pbData[i] = pModulus[cbKey-i-1];

  // When finished, free the certificate context.
  CertFreeCertificateContext(pCertContext);
}

// Find a certificate's private key.
CK_OBJECT_HANDLE FindCertPrvKey(CK_SESSION_HANDLE hSession, Blob& Certificate)
{
  // Extract the public key components from the certificate.
  Blob Modulus, PubExp;
  ExtractCertPubKey(Certificate, Modulus, PubExp);

  // Find the private key according to its modulus and public exponent.
	CK_ATTRIBUTE PrvKeyTemplate[]  = 
	{ 
		{ CKA_CLASS,           &cko_PrvKey,      sizeof(cko_PrvKey)},
		{ CKA_KEY_TYPE,        &ckk_RSA,         sizeof(ckk_RSA)}, 
    { CKA_PRIVATE,         &ck_True,		     sizeof(ck_True)},
		{ CKA_TOKEN,           &ck_True,         sizeof(ck_True)},
		{ CKA_MODULUS,         Modulus.pbData,   Modulus.cbData},
    { CKA_PUBLIC_EXPONENT, PubExp.pbData,    PubExp.cbData},
	};

  int rv = fl->C_FindObjectsInit(hSession, PrvKeyTemplate, sizeofarray(PrvKeyTemplate));
  if (rv!=CKR_OK) Abort(rv, "A certificate's private key was not found");

	CK_ULONG nObjects = 0;
  CK_OBJECT_HANDLE hPrvKey = NULL;
	rv = fl->C_FindObjects(hSession, &hPrvKey, 1, &nObjects);
  if (rv!=CKR_OK) Abort(rv, "A certificate's private key was not found");
  fl->C_FindObjectsFinal(hSession);

  if (nObjects<1) Abort(0, "A certificate's private key was not found");
  return hPrvKey;
}

// Create a certificate's public key.
CK_OBJECT_HANDLE CreateCertPubKey(CK_SESSION_HANDLE hSession, Blob& Certificate, int* pcbKey)
{
  // Extract the public key components from the certificate.
  Blob Modulus, PubExp;
  ExtractCertPubKey(Certificate, Modulus, PubExp);
  if (pcbKey) *pcbKey = Modulus.cbData;

  // Create the session object.
  CK_ATTRIBUTE PubKeyTemplate[] = 
	{
		{ CKA_CLASS,           &cko_PubKey,    sizeof(cko_PubKey)},
		{ CKA_KEY_TYPE,        &ckk_RSA,       sizeof(ckk_RSA)},
		{ CKA_TOKEN,           &ck_False,      sizeof(ck_False)},
		{ CKA_PRIVATE,         &ck_False,      sizeof(ck_False)},
		{ CKA_MODULUS,         Modulus.pbData, Modulus.cbData},
    { CKA_PUBLIC_EXPONENT, PubExp.pbData,  PubExp.cbData},
	};
  
  CK_OBJECT_HANDLE hPubKey = NULL;
  int rv = fl->C_CreateObject(hSession, PubKeyTemplate, sizeofarray(PubKeyTemplate), &hPubKey);
	if (rv!=CKR_OK) Abort(rv,"Failed to create temporary public key");

  return hPubKey;
}


// Create a session DES-3 key.
CK_OBJECT_HANDLE CreateSessionKey(CK_SESSION_HANDLE hSession)
{
  CK_ATTRIBUTE SessionKeyTemplate[] = 
	{
		{ CKA_CLASS,      &cko_SecretKey, sizeof(cko_SecretKey)},
		{ CKA_KEY_TYPE,   &ckk_DES3,      sizeof(ckk_DES3)},
		{ CKA_TOKEN,      &ck_False,      sizeof(ck_False)},
	};
  
  CK_OBJECT_HANDLE hSessionKey = NULL;
  int rv = fl->C_GenerateKey(
    hSession, 
    &ckm_DES3_KEY_GEN, 
    SessionKeyTemplate, 
    sizeofarray(SessionKeyTemplate), 
    &hSessionKey);
	if (rv!=CKR_OK) Abort(rv,"Failed to create session key");

  return hSessionKey;
}

// Wrap the session key using the RSA public key.
void WrapSessionKey(CK_SESSION_HANDLE hSession, CK_OBJECT_HANDLE hSessionKey, CK_OBJECT_HANDLE hReceiverPubKey, Blob& WrappedKey)
{
  ULONG cbWrappedKey = 0;
  int rv = fl->C_WrapKey(
    hSession, 
    &ckm_RSA_PKCS, 
    hReceiverPubKey, 
    hSessionKey, 
    NULL, 
    &cbWrappedKey);
  if (rv!=CKR_OK) Abort(rv, "C_WrapKey failed");

  WrappedKey.resize(cbWrappedKey);
  rv = fl->C_WrapKey(
    hSession, 
    &ckm_RSA_PKCS, 
    hReceiverPubKey, 
    hSessionKey, 
    WrappedKey.pbData, 
    &cbWrappedKey);
  if (rv!=CKR_OK) Abort(rv, "C_WrapKey failed");
}

// Pad the hash.
void PadHash(Blob& Hash)
{
  static const  BYTE SHA_PADDING[] = 
  {
    0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 
    0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
  };

  int cbOld = Hash.cbData;
  Hash.resize(sizeof(SHA_PADDING)+cbOld);
  memmove(Hash.pbData + sizeof(SHA_PADDING), Hash.pbData, cbOld);
  memmove(Hash.pbData, SHA_PADDING, sizeof(SHA_PADDING));
}

// Perform seal.
void Seal(CK_SESSION_HANDLE hSession, FILE* SrcFile, FILE* DstFile)
{
  // List certificates and select a receiver's certificate.
  printf("Select a receiver's certificate for wrapping\n");
  Blob ReceiverCert;
  SelectCertificate(hSession, ReceiverCert);

  // Create a certificate's public key for wrapping.
  CK_OBJECT_HANDLE hReceiverPubKey = CreateCertPubKey(hSession, ReceiverCert, NULL);

  // List certificates and select a sender's certificate.
  printf("Select a sender's certificate for signing\n");
  Blob SenderCert;
  SelectCertificate(hSession, SenderCert);

  // Find a certificate's private key for signing.
  CK_OBJECT_HANDLE hSenderPrvKey = FindCertPrvKey(hSession, SenderCert);

  // Generate a session key.
  CK_OBJECT_HANDLE hSessionKey = CreateSessionKey(hSession);

  // Wrap the session key using the receiver's public key.
  Blob WrappedKey;
  WrapSessionKey(hSession, hSessionKey, hReceiverPubKey, WrappedKey);

  // Generate a random initial vector.
  Blob iv(8);
  int rv = fl->C_GenerateRandom(hSession,iv.pbData, iv.cbData);
  if (rv!=CKR_OK) Abort(rv, "Cannot generate the random initial vector");
 
  // Store header.
  if (!ReceiverCert.write(DstFile)) Abort(-1, "Cannot save the receiver's certificate key");
  if (!SenderCert.write(DstFile))   Abort(-1, "Cannot save the sender's certificate key");
  if (!iv.write(DstFile))           Abort(-1, "Cannot save the initial vector");
  if (!WrappedKey.write(DstFile))   Abort(-1, "Cannot save the wrapped key");
  
  // Get source file size.
  fseek(SrcFile, 0, SEEK_END);
  int cbSource = ftell(SrcFile);
  fseek(SrcFile, 0, SEEK_SET);

  // Start encryption.
	CK_MECHANISM EncMech = {CKM_DES3_CBC_PAD, iv.pbData, iv.cbData};
  rv = fl->C_EncryptInit(hSession, &EncMech, hSessionKey);
  if (rv) Abort(rv, "C_EncryptInit failed");

  // Start hashing.
  rv = fl->C_DigestInit(hSession, &ckm_SHA_1);
  if (rv) Abort(rv, "C_DigestInit failed");

  while (cbSource>0)
  {
    // Read the next block of the plain data.
    const int BLOCK_SIZE = 1024;
    static BYTE Plain[BLOCK_SIZE];
    int cbBlock = min(cbSource, BLOCK_SIZE);
    if (!fread(Plain, 1, cbBlock, SrcFile)) Abort(-1, "Error reading from source file");
    cbSource-=cbBlock;
    
    // Update the hash.
    rv = fl->C_DigestUpdate(hSession, Plain, cbBlock);
    if (rv!=CKR_OK) Abort(rv, "C_DigestUpdate failed");

    // Encryption.
    ULONG cbEncrypted = 0;
    rv = fl->C_EncryptUpdate(hSession, Plain, cbBlock, NULL, &cbEncrypted);
    if (rv!=CKR_OK) Abort(rv, "C_EncryptUpdate failed");
    Blob Encrypted(cbEncrypted);
    rv = fl->C_EncryptUpdate(hSession, Plain, cbBlock, Encrypted.pbData, &cbEncrypted);
    if (rv!=CKR_OK) Abort(rv, "C_EncryptUpdate failed");
    
    //Save the encrypted data to the destination file.
    fwrite(Encrypted.pbData, 1, Encrypted.cbData, DstFile);
  }

  // End hashing.
  ULONG cbHash = 0;
  rv = fl->C_DigestFinal(hSession, NULL, &cbHash);
  if (rv!=CKR_OK) Abort(rv, "C_DigestFinal failed");
  Blob Hash(cbHash);
  rv = fl->C_DigestFinal(hSession, Hash.pbData, &cbHash);
  if (rv!=CKR_OK) Abort(rv, "C_DigestFinal failed");

  // End encryption.
  ULONG cbEncrypted = 0;
  rv = fl->C_EncryptFinal(hSession, NULL, &cbEncrypted);
  if (rv!=CKR_OK) Abort(rv, "C_EncryptFinal failed");
  Blob Encrypted(cbEncrypted);
  rv = fl->C_EncryptFinal(hSession, Encrypted.pbData, &cbEncrypted);
  if (rv!=CKR_OK) Abort(rv, "C_EncryptFinal failed");

  // Save the last encrypted block to the destination file.
  fwrite(Encrypted.pbData, 1, Encrypted.cbData, DstFile);

  // Prepare the hash for signing.
  PadHash(Hash);

  // Sign the hash with sender's private key.
  rv = fl->C_SignInit(hSession, &ckm_RSA_PKCS, hSenderPrvKey);
  if (rv!=CKR_OK) Abort(rv, "C_SignInit failed");
  ULONG cbSignature = 0;
  rv = fl->C_Sign(hSession, Hash.pbData, Hash.cbData, NULL, &cbSignature);
  if (rv!=CKR_OK) Abort(rv, "C_Sign failed");
  Blob Signature(cbSignature);
  rv = fl->C_Sign(hSession, Hash.pbData, Hash.cbData, Signature.pbData, &cbSignature);
  if (rv!=CKR_OK) Abort(rv, "C_Sign failed");

  // Store the signature in the destination file.
  if (!Signature.write(DstFile)) Abort(-1, "Cannot save the signature");
  
  printf("Seal operation success\n");
}

// Unwrap the session key using the receiver's private key.
CK_OBJECT_HANDLE UnwrapSessionKey(CK_SESSION_HANDLE hSession, CK_OBJECT_HANDLE hPrivateKey, Blob& WrappedKey)
{ 
  CK_ATTRIBUTE SessionKeyTemplate[] = 
  {
    {CKA_CLASS,    &cko_SecretKey, sizeof(cko_SecretKey)},
    {CKA_KEY_TYPE, &ckk_DES3,      sizeof(ckk_DES3)},
    {CKA_TOKEN,    &ck_False,      sizeof(ck_False)},
  };

  CK_OBJECT_HANDLE hSessionKey;
  int rv = fl->C_UnwrapKey(
    hSession, 
    &ckm_RSA_PKCS, 
    hPrivateKey, 
    WrappedKey.pbData, 
    WrappedKey.cbData, 
    SessionKeyTemplate, 
    sizeofarray(SessionKeyTemplate), &hSessionKey);
  if (rv!=CKR_OK) Abort(rv, "C_UnwrapKey failed");

  return hSessionKey;
}

// Perform unseal.
void Unseal(CK_SESSION_HANDLE hSession, FILE* SrcFile, FILE* DstFile)
{
  // Read a receivers's certificate from the source file.
  Blob ReceiverCert;
  if (!ReceiverCert.read(SrcFile)) Abort(-1, "Error reading a receiver's certificate");

  // Read a sender's certificate from the source file.
  Blob SenderCert;
  if (!SenderCert.read(SrcFile)) Abort(-1, "Error reading a sender's certificate");

  // Read an initial vector.
  Blob iv;
  if (!iv.read(SrcFile)) Abort(-1, "Error reading an initial vector");

  // Read a wrapped session key.
  Blob WrappedKey;
  if (!WrappedKey.read(SrcFile)) Abort(-1, "Error reading a wrapped session key");

  // Create a certificate's public key of the sender.
  int cbSenderKey = 0;
  CK_OBJECT_HANDLE hSenderPubKey = CreateCertPubKey(hSession, SenderCert, &cbSenderKey);

  // Find a certificate's private key of the receiver.
  CK_OBJECT_HANDLE hReceiverPrvKey = FindCertPrvKey(hSession, ReceiverCert);
  if (!hReceiverPrvKey) Abort(0, "A receiver's private key was not found");

  // Unwrap a session key using the receiver's private key.
  CK_OBJECT_HANDLE hSessionKey = UnwrapSessionKey(hSession, hReceiverPrvKey, WrappedKey);

  // Calculate the encrypted data size in the source file.
  int nCurrent = ftell(SrcFile);
  fseek(SrcFile, 0, SEEK_END);
  int cbSource = ftell(SrcFile) - nCurrent;
  fseek(SrcFile, nCurrent, SEEK_SET);
  cbSource -= sizeof(DWORD)+cbSenderKey; // Signature length must be equal to the sender's RSA key size.

  // Start decryption.
	CK_MECHANISM DecMech = {CKM_DES3_CBC_PAD, iv.pbData, iv.cbData};
  int rv = fl->C_DecryptInit(hSession, &DecMech, hSessionKey);
  if (rv) Abort(rv, "C_DecryptInit failed");

  // Start hashing.
  rv = fl->C_DigestInit(hSession, &ckm_SHA_1);
  if (rv) Abort(rv, "C_DigestInit failed");

  const int BLOCK_SIZE = 1024;
  while (cbSource>0)
  {
    // Read next block of the plain data.
    static BYTE Encrypted[BLOCK_SIZE];
    int cbBlock = min(cbSource, BLOCK_SIZE);
    if (!fread(Encrypted, 1, cbBlock, SrcFile)) Abort(-1, "Error reading from source file");
    cbSource-=cbBlock;
    
    // Decryption
    static BYTE Plain[BLOCK_SIZE]; // Plain length cannot be more than the encrypted one.
    ULONG cbPlain = BLOCK_SIZE;
    rv = fl->C_DecryptUpdate(hSession, Encrypted, cbBlock, Plain, &cbPlain);
    if (rv!=CKR_OK) Abort(rv, "C_DecryptUpdate failed");
    
    //Save decrypted data to the destination file.
    fwrite(Plain, 1, cbPlain, DstFile);

    // Update the hash.
    rv = fl->C_DigestUpdate(hSession, Plain, cbPlain);
    if (rv!=CKR_OK) Abort(rv, "C_DigestUpdate failed");
  }

  // End decryption.
  ULONG cbPlain = 0;
  rv = fl->C_DecryptFinal(hSession, NULL, &cbPlain);
  if (rv!=CKR_OK) Abort(rv, "C_DecryptFinal failed");
  static BYTE Plain[BLOCK_SIZE]; // Plain length cannot be more than the encrypted.
  rv = fl->C_DecryptFinal(hSession, Plain, &cbPlain);
  if (rv!=CKR_OK) Abort(rv, "C_DecryptFinal failed");

  // Save decrypted data to the destination file.
  fwrite(Plain, 1, cbPlain, DstFile);

  // Update the hash.
  rv = fl->C_DigestUpdate(hSession, Plain, cbPlain);
  if (rv!=CKR_OK) Abort(rv, "C_DigestUpdate failed");

  // End hashing.
  ULONG cbHash = 0;
  rv = fl->C_DigestFinal(hSession, NULL, &cbHash);
  if (rv!=CKR_OK) Abort(rv, "C_DigestFinal failed");
  Blob Hash(cbHash);
  rv = fl->C_DigestFinal(hSession, Hash.pbData, &cbHash);
  if (rv!=CKR_OK) Abort(rv, "C_DigestFinal failed");

  // Prepare the hash for verification.
  PadHash(Hash);

  // Read the signature from the source file.
  Blob Signature;
  if (!Signature.read(SrcFile)) Abort(-1, "Cannot read the signature");

  // Verify the signature with the sender's public key.
  rv = fl->C_VerifyInit(hSession, &ckm_RSA_PKCS, hSenderPubKey);
  if (rv!=CKR_OK) Abort(rv, "C_VerifyInit failed");
  rv = fl->C_Verify(hSession, Hash.pbData, Hash.cbData, Signature.pbData, Signature.cbData);
  if (rv!=CKR_OK) Abort(rv, "C_Verify failed");

  printf("Unseal operation succeeded\n");
}

// Main program
void Execute(LPCSTR Action, LPCSTR Password, LPCSTR SrcFileName, LPCSTR DstFileName)
{
  BOOL bSeal = !stricmp(Action, "seal");
  if (!bSeal && stricmp(Action, "unseal")) Syntax();

  FILE* SrcFile = fopen(SrcFileName, "rb");
  if (!SrcFile) Abort(-1, "Cannot open the source file");

  FILE* DstFile = fopen(DstFileName, "wb");
  if (!DstFile) Abort(-1, "Cannot create the destination file");

  // Load and initialize the eToken PKCS#11 library.
  PkiInitialize();

  // Select a working eToken.
  CK_SLOT_ID SlotID = SelectToken();

  // Open a PKCS#11 session.
  CK_SESSION_HANDLE hSession = OpenSession(SlotID);

  // Perform login.
  int rv = fl->C_Login (hSession, CKU_USER, (CK_CHAR_PTR)Password, strlen(Password));
  if (rv!=CKR_OK) Abort(rv, "C_Login failed");

  // Execute the action.
  if (bSeal) Seal(hSession, SrcFile, DstFile);
  else Unseal(hSession, SrcFile, DstFile);

  // Close PKCS#11 session.
  fl->C_CloseSession(hSession);

  // Close PKCS#11 library.
  PkiFinalize();

  // Close files.
  fclose(DstFile);
  fclose(SrcFile);
}

/*
  Encrypted file format:

  DWORD receiver's certificate length
	...   receiver's certificate
  DWORD sender's certificate length
	...   sender's certificate

  DWORD initial vector length
  ...   initial vector data
  DWORD wrapped session key length
  ...   wrapped session key

  ...   encrypted data

  DWORD signature length
  ...   signature
*/

// Program entry point.
int main(int argc, char* argv[])
{
  if (argc != 5) Syntax();

  LPCSTR Action       = argv[1];
  LPCSTR Password     = argv[2];
  LPCSTR SrcFileName  = argv[3];
  LPCSTR DstFileName  = argv[4];

  Execute(Action, Password, SrcFileName, DstFileName);

  return 0;
}

