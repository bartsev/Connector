/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

// CACertSample.cpp : Contains a sample code for importing a CA certificate to an eToken
//

#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#endif

#include "eTPkcs11.h"

/* The name of the function list retrieval entry */
#define PKCS11_GFL		"C_GetFunctionList"

#ifdef _WIN32
#define ET_PKCS						"etpkcs11.dll"
#else
#define ET_PKCS						"libeTPkcs11.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

/* Global module and PKCS#11 function pointers */
HINSTANCE								hPKCS11				= NULL;
CK_C_GetFunctionList		pGFL					= NULL;
CK_FUNCTION_LIST_PTR		pFunctionList	= NULL;

/* Functions declaration */
static bool LoadPKCSContext();
static void DestroyPKCSContext();
static CK_ULONG GetFirstSlotId();
static bool ReadCertFromFile(const char* fileName, CK_BYTE_PTR* cert, DWORD* certSize);
static void GetX509Subject(CK_BYTE_PTR cert, int certSize, CK_BYTE_PTR* subject, int* subjectSize);
static bool CreateCertFromBlob(CK_SESSION_HANDLE hSession, CK_BYTE_PTR cert, int certSize, CK_BYTE_PTR subject, 
							   int subjSize);
static void ErrorMessage(const char* message);


/* Extracts the subject name from a certificate blob */
static void GetX509Subject(CK_BYTE_PTR cert		// Certificate blob
						   , int certSize					// Certificate blob size
						   , CK_BYTE_PTR* subject			// A pointer to recieve the subject name
						   , int* subjectSize				// Subject name size
						   ) {
							   unsigned int i;
							   unsigned char* current = cert;
							   unsigned char* prev;
							   unsigned char* end = cert + certSize;
							   unsigned char tags[] = {0x30, 0,             // main sequence
								   0x30, 0,          // to be signed, sequence
								   0xa0, 1,       // version, application-defined
								   0x02, 1,       // serial number, integer
								   0x30, 1,       // signature, sequence
								   0x30, 1,       // issuer, sequence
								   0x30, 1,       // validity, sequence
								   0x30, 1,       // subject, sequence
							   };

							   *subject = NULL;               // output on failure
							   *subjectSize = 0;

							   for (i=0; i<sizeof(tags); i+=2)
							   {
								   unsigned char v;
								   unsigned int length = 0;
								   prev = current;

								   if (current+2>end) return;
								   if (*current++ != tags[i]) return;
								   v = *current++;

								   if ((v & 0x80) == 0) length = v;
								   else
								   {
									   unsigned char lenlen = v & 0x7f;
									   if (current + lenlen > end) return;
									   for (v=0; v<lenlen; v++) length = (length<<8) + *current++;
								   }

								   if (tags[i+1]) current+=length;
							   }

							   *subject = prev;
							   *subjectSize = (int)(current-prev);
}

/* Import the certificate to the token */
static bool CreateCertFromBlob(CK_SESSION_HANDLE hSession	// Opened session with the token
							   , CK_BYTE_PTR cert			// Certificate blob
							   , int certSize				// Certificate blob
							   , CK_BYTE_PTR subject		// Certificate subject
							   , int subjSize				// Subject size
							   )			
{
	CK_OBJECT_CLASS classAttr = CKO_CERTIFICATE;
	CK_CERTIFICATE_TYPE certType = CKC_X_509;
	unsigned long certCategory = 2;
	CK_BBOOL trueVal = CK_TRUE;
	CK_OBJECT_HANDLE hObject;

	CK_ATTRIBUTE templateArray [] = 
	{
		{CKA_CLASS, &classAttr, sizeof(classAttr)},
		{CKA_CERTIFICATE_TYPE, &certType, sizeof(certType)},
		{CKA_TOKEN, &trueVal, sizeof(trueVal)},
		{CKA_SUBJECT, subject, subjSize },
		{CKA_VALUE, (void *)cert, certSize },
		{CKA_CERTIFICATE_CATEGORY, (void *)&certCategory, sizeof (certCategory) },
	};

	int sizeOfTemplate = sizeof (templateArray) / sizeof(CK_ATTRIBUTE);

	CK_RV rv = pFunctionList->C_CreateObject ( hSession, templateArray, sizeOfTemplate, &hObject );
	if (rv) {
		return false;
	}

	return true;
}

/* Loads global PKCS#11 module and function pointer */
static bool LoadPKCSContext(){
	int dwErr	= 0;

	if ((hPKCS11 = LoadLibrary(ET_PKCS)) == NULL){
		return false;
	}

#ifdef WIN32
	if (((FARPROC&)pGFL = GetProcAddress(hPKCS11, PKCS11_GFL)) == NULL){
#else
	if ((*(void**)&pGFL = GetProcAddress(hPKCS11, PKCS11_GFL)) == NULL){
#endif
		return false;
	}

	dwErr = pGFL(&pFunctionList);

	if (dwErr == 0){
		dwErr = pGFL(&pFunctionList);
	}

	if (dwErr == 0){
		if ((dwErr = pFunctionList->C_Initialize(0)) != CKR_OK ){
			if (dwErr == CKR_CRYPTOKI_ALREADY_INITIALIZED) {
				dwErr = CKR_OK;
			}
		}
	}

	return (dwErr == 0);

}

/* Release global module and function pointer */
static void DestroyPKCSContext(){
	pFunctionList->C_Finalize(NULL);

	if (hPKCS11 != NULL){
		FreeLibrary(hPKCS11);
		hPKCS11 = NULL;
	}
}

/* Convinience method to retrieve the first PKCS#11 slot of a connected token */
static CK_ULONG GetFirstSlotId() {
	CK_ULONG slotID = -1;
	CK_ULONG ulCount = 0;
	CK_SLOT_ID_PTR pSlotIDs	= NULL_PTR;
	CK_ULONG i;

	if (pFunctionList->C_GetSlotList(TRUE,NULL_PTR,&ulCount) == CKR_OK) {
		if (ulCount > 0) {
			pSlotIDs = new CK_SLOT_ID[ulCount];			
			if ((pFunctionList->C_GetSlotList(TRUE,pSlotIDs,&ulCount)) == CKR_OK) {
				for (i=0;i < ulCount;i++){
					CK_SLOT_INFO info;    
					if ((pFunctionList->C_GetSlotInfo(pSlotIDs[i],&info)) == CKR_OK) {
						if (info.flags & (CKF_HW_SLOT | CKF_TOKEN_PRESENT)) {
							slotID = pSlotIDs[i];
							break;
						}
					}
				}
			}
		}
	}

	if (pSlotIDs) {
		delete[] pSlotIDs;
		pSlotIDs = NULL_PTR;
	}

	return slotID;
}

/* Read a certificate blob from CER file */
static bool ReadCertFromFile(const char* fileName, CK_BYTE_PTR* cert, DWORD* certSize) {
	bool ret = false;

#ifdef WIN32
	HANDLE file = CreateFile(fileName, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (file != INVALID_HANDLE_VALUE) {
		DWORD size = GetFileSize(file, NULL);
		if (size != INVALID_FILE_SIZE) {
			*cert = new BYTE[size];
			if (ReadFile(file, *cert, size, certSize, NULL)) {
				ret = true;
			}
		}
		CloseHandle(file);
	}
#else
	DWORD pos, size;
	
	int fh = open ( fileName, O_RDONLY);
	if( fh != -1 )
  {
    size = lseek( fh, 0L, SEEK_END );

		if( size != -1 )
		{
			pos = lseek( fh, 0L, SEEK_SET );
			if( pos != -1 )
			{
        *cert = new CK_BYTE[size];
				*certSize = read( fh, *cert, size );

				ret = true;
			}
		}

		close( fh );
	}
#endif
	return ret;
}

/* Prints error message and exit */
static void ErrorMessage(const char* message) {
	printf("%s\n", message);
	exit(-1);
}

// Main program
int main(int argc, char* argv[])
{
	CK_BYTE_PTR		cert = NULL;
	DWORD					certSize;
	CK_BYTE_PTR		subject = NULL;
	int						subjSize;

	if(argc < 2)
  {
    ErrorMessage("GetCACert:\n"
          "   GetCACert <valid path to cer file with CA certificate> <user-password>\n"
					"   Example: GetCACert c:\\CA.cer 1234567890\n");
  }

	// Load the context
	if (!LoadPKCSContext()) {
		ErrorMessage("Unable to load PKCS#11 modules.");
	}

	// Read the certifcate
	if (!ReadCertFromFile(argv[1], &cert, &certSize)) {
		ErrorMessage("Unable to read certificate from certificate file.");
	}

	// Extract the subject
	GetX509Subject((unsigned char*)cert, certSize, &subject, &subjSize);

	// Find connected token
	CK_ULONG slotID = GetFirstSlotId();
	if (slotID == -1) {
		ErrorMessage("No token is connected.");
	}

	// login to token
	CK_SESSION_HANDLE hSession;
	if (pFunctionList->C_OpenSession( slotID, CKF_SERIAL_SESSION | CKF_RW_SESSION, NULL, NULL, &hSession) != CKR_OK) {
		ErrorMessage("Unable to open session with the token.");
	}
	
	if (pFunctionList->C_Login(hSession, CKU_USER, (LPBYTE)argv[2], strlen(argv[2])) != CKR_OK) {
		ErrorMessage("Unable to login to token.");
	}

	// Import the certificate to the token
	if (!CreateCertFromBlob( hSession, (CK_BYTE_PTR)cert, certSize, subject, subjSize)) {
		ErrorMessage("Failed to import certificate to token.");
	}

	// Closure
	pFunctionList->C_Logout( hSession );
	pFunctionList->C_CloseSession( hSession );
	DestroyPKCSContext();
	if (cert) {
		delete[] cert;
	}

	return 0;
}

