/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used content from Windows headers.

// Win32
#include <windows.h>
#include <wincrypt.h>

// STL
#include <string>
#include <iostream>
using namespace std;


//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	printf("\n\n");
  printf("Press Enter to exit");
  getchar();
	exit(message ? -1 : 0 );
}

//
// Explanation and command line syntax.
void explanation()
{
  cout<<"ENUM TOKENS SAMPLE"<<endl
      <<"------------------"<<endl
      <<"Shows how to Create a Self Sign Certificate on first token with a default password."<<endl;
}

#define ET_PROVIDER "eToken Base Cryptographic Provider"
#define CONTAINER_NAME " (Self Sign Certificate Container)"

//
//
int main(int argc, char* argv[])
{
	if (argc != 3)
  {
    leave("Usage:\n"
          "   CreateSelfCertificate <reader name> <password> \n"
          "     Example: CreateSelfCertificate  \n"); 
  }
  char* readerName = argv[1];
  char* password    = argv[2];

  cout<<">>>Start to create Self Sign Certificate."<<endl<<endl;

 
	cout<<"Type Certifcate Subject: ";
  char Subject[MAX_PATH];
  cin.getline(Subject,MAX_PATH,'\n');
  cout<<"Type Certifcate Organization: ";
  char Organization[MAX_PATH];
  cin.getline(Organization,MAX_PATH,'\n');
  cout<<"Type Certifcate Country: ";
  char Country[MAX_PATH];
  cin.getline(Country,MAX_PATH,'\n');
  
  char X500Name[1024];
  sprintf(X500Name, "CN=\"%s\",O=\"%s\",C=\"%s\"", Subject,Organization,Country);

  //Pass user password, reader name and KC name to prevent select token and login dialog box.
  //Format: [reader-name{{password}}]=MyKeyContainer
  string certKCname;
  certKCname += Subject;
  certKCname += CONTAINER_NAME;

  string kcname = "[";
  kcname += readerName;
  kcname +="{{"; 
  kcname += password; 
  kcname +="}}]="; 
  kcname += certKCname; 

  char szProvider[260] = { ET_PROVIDER };

  cout<<"Get handle to eToken CSP."<<endl; 
  HCRYPTPROV hProv = NULL; 
  if (!::CryptAcquireContext(&hProv,kcname.c_str(),szProvider,PROV_RSA_FULL,0))
  {
    if(GetLastError() != NTE_EXISTS)
    {
      if (!::CryptAcquireContext(&hProv,kcname.c_str(),szProvider,PROV_RSA_FULL,CRYPT_NEWKEYSET))
      {
        leave("CryptAcquireContext failed to create new key set...");
      }
    } 
    else
      leave("CryptAcquireContext failed and key container exists...");
  }

  //Handle to RSA Gen key pair
  HCRYPTKEY  hKeyExchange = NULL; 
  cout<<"Generate RSA exchange key pair."<<endl; 
  if (!::CryptGenKey(hProv, AT_KEYEXCHANGE, 0,	&hKeyExchange))
	{
		leave("CryptGenKey failed to create AT_KEYEXCHANGE key...");
	}

  CERT_NAME_BLOB certName = {0};
	certName.cbData = 0;
	certName.pbData = NULL;
  //char* dn = "CN=\"John Smite\",O=\"Aladdin Company\"";

  cout<<"Prepair certificate name in X509 format."<<endl; 
  if (!::CertStrToName(X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
                       X500Name, //dn
                       CERT_OID_NAME_STR,
                       NULL,
                       NULL, &certName.cbData,
                       NULL))
	{
	  leave("CertStrToName with NULL failed...");
	}
  certName.pbData = (PBYTE) malloc(certName.cbData);
  if (!::CertStrToName(X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 
                       X500Name, //dn
                       CERT_OID_NAME_STR,
                       NULL,
                       certName.pbData, &certName.cbData,
                       NULL))
  {
    free(certName.pbData);
    leave("CertStrToName failed...");
  }

  WCHAR szwContainer[260];
	WCHAR szwProvider[260];

	// Convert container name and provider name to unicode.
	int i = MultiByteToWideChar(0, 0, certKCname.c_str(), -1, szwContainer, 260);
  if (i == 0)
	{
		leave("MultiByteToWideChar (container name) failed ...");
	}
  
  i = MultiByteToWideChar(0, 0, szProvider, -1, szwProvider, 260);
	if (i == 0)
	{
		leave("MultiByteToWideChar (provider name) failed ...");
	}

  CRYPT_KEY_PROV_INFO keyinfo;
  memset(&keyinfo,0x00,sizeof(CRYPT_KEY_PROV_INFO));
  keyinfo.pwszContainerName = szwContainer;
  keyinfo.pwszProvName = szwProvider;
  keyinfo.dwProvType = PROV_RSA_FULL;
  keyinfo.dwKeySpec = AT_KEYEXCHANGE;

 	SYSTEMTIME cs;
	GetSystemTime(&cs);
	cs.wYear += 1;
  
	CRYPT_ALGORITHM_IDENTIFIER  signatureAlgorithm;
  memset(&signatureAlgorithm, 0, sizeof(CRYPT_ALGORITHM_IDENTIFIER));
  signatureAlgorithm.pszObjId = szOID_RSA_SHA1RSA; 

  //Handle to certificate context.
  PCCERT_CONTEXT pCertCtx = NULL; 

  cout<<"Create Self Sign Certificate."<<endl; 
  pCertCtx = CertCreateSelfSignCertificate(hProv,
                                           &certName,
																					 0,
																					 &keyinfo,
																					 &signatureAlgorithm,
																					 NULL,
																					 &cs,
																					 NULL);
	free(certName.pbData);
	if(!pCertCtx)
	{
	  leave("CertCreateSelfSignCertificate failed...");
	}

  cout<<"Set Certificate context to key handle."<<endl; 
  if (!:: CryptSetKeyParam(hKeyExchange,KP_CERTIFICATE,pCertCtx->pbCertEncoded,0))
  {
    leave("CryptSetKeyParam  failed...");
  }

 	cout<<"Free Certificate, Key and CSP handles."<<endl; 
  if (pCertCtx)	CertFreeCertificateContext(pCertCtx);
	if (hKeyExchange)	CryptDestroyKey(hKeyExchange);
	if (hProv) CryptReleaseContext(hProv, 0);

  cout<<endl<<"Creation of Self Sign Certificate successful."<<endl;

  cout<<"Press Enter key to exit..."<<endl;
  getchar ();
	return 0;
}
