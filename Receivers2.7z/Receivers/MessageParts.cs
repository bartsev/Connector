﻿using System;

namespace SMEVPaymentReceivers
{
    public static class SMEVMessageParts
    {
        public const string header = "123";
    }

}
