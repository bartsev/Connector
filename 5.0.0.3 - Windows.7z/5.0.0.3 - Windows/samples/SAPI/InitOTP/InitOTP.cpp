/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <string.h>
#include <dlfcn.h>
#include <unistd.h>
#endif

#include "eTPkcs11.h"
#include "eTSAPI.h"

#ifdef _WIN32
#define PKCS11_DLL_NAME		"etpkcs11.dll"
#define ETSAPI_DLL_NAME		"etsapi.dll"
#else
#define PKCS11_DLL_NAME		"libeTPkcs11.so"
#define ETSAPI_DLL_NAME		"libeTSapi.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

// Print message and stop execution.
static void leave(const char * message)
{
  if (message) printf("%s\n", message);
  printf("Press the Enter key to exit");
  getchar();
  exit(message ? -1 : 0);
}

CK_FUNCTION_LIST_PTR fl = NULL; // PKCS#11 functions list.

// Load eTPKCS11.dll and initialize PKCS#11.
void LoadPKCS11()
{
  HINSTANCE hLib = LoadLibrary(PKCS11_DLL_NAME); 
  if (!hLib) leave("Cannot load PKCS11");
  
  CK_C_GetFunctionList f_C_GetFunctionList = NULL;
#ifdef _WIN32
	(FARPROC&)f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#endif	
  if (!f_C_GetFunctionList) leave("C_GetFunctionList not found");

  if (CKR_OK != f_C_GetFunctionList(&fl)) leave("C_GetFunctionList failed");
  if (CKR_OK != fl->C_Initialize(0)) leave("C_Initialize failed");
}

// SAPI functions declaration.

typedef CK_RV (*t_SAPI_OTP_Create)(
  CK_SESSION_HANDLE hSession, 
  CK_ATTRIBUTE_PTR pTemplate, 
  CK_ULONG ulCount);

typedef CK_RV (*t_SAPI_OTP_Destroy)(
  CK_SESSION_HANDLE hSession);

typedef CK_RV (*t_SAPI_OTP_Execute)(
  CK_SESSION_HANDLE hSession, 
  CK_ULONG mode, 
  CK_CHAR_PTR pResult, 
  CK_ULONG_PTR pSize);

typedef CK_RV (*t_SAPI_OTP_GetMechanismInfo)(
  CK_SLOT_ID slotId, 
  CK_ULONG mechanism, 
  CK_SAPI_OTP_MECHANISM_INFO_PTR pMechanismInfo);

typedef CK_RV (*t_SAPI_Server_OTP_Calculate)(
  CK_ATTRIBUTE_PTR pTemplate, 
  CK_ULONG ulCount, 
  CK_CHAR_PTR pResult, 
  CK_ULONG_PTR pSize);

t_SAPI_OTP_Create _SAPI_OTP_Create = NULL;
t_SAPI_OTP_Destroy _SAPI_OTP_Destroy = NULL;
t_SAPI_OTP_Execute _SAPI_OTP_Execute = NULL;
t_SAPI_OTP_GetMechanismInfo _SAPI_OTP_GetMechanismInfo = NULL;
t_SAPI_Server_OTP_Calculate _SAPI_Server_OTP_Calculate = NULL;

// Load eTSAPI.dll and acquire its usable functions.
void LoadETSAPI()
{
  HINSTANCE hLib = LoadLibrary(ETSAPI_DLL_NAME); 
  if (!hLib) leave("Cannot load etsapi");

#ifdef _WIN32
  (FARPROC&)_SAPI_OTP_Create = GetProcAddress(hLib, "SAPI_OTP_Create");
#else
	*(void**)&_SAPI_OTP_Create = GetProcAddress(hLib, "SAPI_OTP_Create");
#endif
  if (!_SAPI_OTP_Create) leave("SAPI_OTP_Create not found");

#ifdef _WIN32
  (FARPROC&)_SAPI_OTP_Destroy = GetProcAddress(hLib, "SAPI_OTP_Destroy");
#else
	*(void**)&_SAPI_OTP_Destroy = GetProcAddress(hLib, "SAPI_OTP_Destroy");
#endif
  if (!_SAPI_OTP_Destroy) leave("SAPI_OTP_Delete not found");

#ifdef _WIN32
	(FARPROC&)_SAPI_OTP_Execute = GetProcAddress(hLib, "SAPI_OTP_Execute");
#else
	*(void**)&_SAPI_OTP_Execute = GetProcAddress(hLib, "SAPI_OTP_Execute");
#endif
  if (!_SAPI_OTP_Execute) leave("SAPI_OTP_Execute not found");

#ifdef _WIN32
	(FARPROC&)_SAPI_OTP_GetMechanismInfo = GetProcAddress(hLib, "SAPI_OTP_GetMechanismInfo");
#else
	*(void**)&_SAPI_OTP_GetMechanismInfo = GetProcAddress(hLib, "SAPI_OTP_GetMechanismInfo");
#endif
  if (!_SAPI_OTP_GetMechanismInfo) leave("SAPI_OTP_GetMechanismInfo not found");

#ifdef _WIN32
  (FARPROC&)_SAPI_Server_OTP_Calculate = GetProcAddress(hLib, "SAPI_Server_OTP_Calculate");
#else
	*(void**)&_SAPI_Server_OTP_Calculate = GetProcAddress(hLib, "SAPI_Server_OTP_Calculate");
#endif
  if (!_SAPI_Server_OTP_Calculate) leave("SAPI_Server_OTP_Calculate not found");
}

// Locate an inserted eToken.
CK_SLOT_ID LocateToken()
{
  CK_ULONG nSlots = 1;
  CK_SLOT_ID nSlotID;
  if (CKR_OK != fl->C_GetSlotList(TRUE, &nSlotID, &nSlots)) leave("C_GetSlotList failed");
  if (nSlots<1) leave("No eToken inserted");
  return nSlotID;
}

int main(int argc, char* argv[])
{
  LoadPKCS11();
  LoadETSAPI();

  CK_SLOT_ID nSlotID = LocateToken();

  // Open PKCS#11 session.
  CK_SESSION_HANDLE hSession;
  CK_RV rv = fl->C_OpenSession(nSlotID, CKF_RW_SESSION|CKF_SERIAL_SESSION, NULL, NULL, &hSession);
  if (rv!=0) leave("C_OpenSession failed");

  // Perform PKCS#11 login.
  rv = fl->C_Login(hSession, CKU_USER, (CK_CHAR*)"1234567890", 10);
  if (rv!=0) leave("C_Login failed");

  printf("Clean OTP object\n");
  _SAPI_OTP_Destroy(hSession); // Clean up.

  printf("Create OTP object\n");

  // Generate random key value
  //JV Card OTP MinKeySize = 20, MaxKeySize = 24
  //CardOS OTP MinKeySize = 20, MaxKeySize = 32.
  BYTE key[24];
  rv = fl->C_GenerateRandom(hSession, key, sizeof(key));
  if (rv!=0) leave("C_GenerateRandom failed");

  // Create new OTP object.
  CK_ULONG mech = CK_SAPI_OTP_HMAC_SHA1_DEC6;
  CK_BBOOL ck_false = FALSE;
  CK_ATTRIBUTE tCreate[] = {
    {CKA_SAPI_OTP_MECHANISM,    &mech,        sizeof(CK_ULONG)}, 
    {CKA_SAPI_OTP_VALUE,        key,          sizeof(key)     },
    {CKA_SAPI_OTP_NEXT_ALLOWED, &ck_false,     sizeof(CK_BBOOL)},
  };
  rv = _SAPI_OTP_Create(hSession, tCreate, sizeof(tCreate)/sizeof(CK_ATTRIBUTE));
  if (rv) leave("SAPI_OTP_Create failed");

  // Check if eToken supports the OTP button in connected mode.
  CK_SAPI_OTP_MECHANISM_INFO mi;
  rv = _SAPI_OTP_GetMechanismInfo(nSlotID, CK_SAPI_OTP_HMAC_SHA1_DEC6, &mi);
  if (rv) leave("SAPI_OTP_GetMechanismInfo failed");
  if ((mi.flags & CK_SAPI_OTP_BUTTON_SUPPORTED)==0)
  {
    leave("This token does not support the OTP button in connected mode");
  }

  // Get current OTP value.
  printf("Acquire current OTP\n");
  CK_CHAR OTP_current[7];
  CK_ULONG OTPLen_current = sizeof(OTP_current);
  rv = _SAPI_OTP_Execute(hSession, CK_SAPI_OTP_CURRENT, OTP_current, &OTPLen_current);
  if (rv) leave("SAPI_OTP_Execute failed");

  printf("Acquire next OTP. Press eToken button to generate next OTP value.\n");
  CK_CHAR OTP[7];
  CK_ULONG OTPLen = sizeof(OTP);
  BOOL bChanged = FALSE;
  while (!bChanged)
  {
    // Get current OTP value.
#ifdef _WIN32
    Sleep(100);
#else
		usleep(100);
#endif
    rv = _SAPI_OTP_Execute(hSession, CK_SAPI_OTP_CURRENT, OTP, &OTPLen);
    if (rv) leave("SAPI_OTP_Execute failed");
    bChanged = (OTPLen_current!=OTPLen) || (memcmp(OTP_current, OTP, OTPLen)); 
  }

  rv = _SAPI_OTP_Execute(hSession, CK_SAPI_OTP_RELEASE, OTP, &OTPLen);

  printf("Calculate OTP on the server side\n");
  BOOL bSuccess = FALSE;

  for (CK_ULONG counter = 0; !bSuccess && counter<30; counter++) // Maximum of 30 tries on the server side.
  {
    CK_CHAR Result[7];
    CK_ULONG ResultLen = sizeof(Result);

    // OTP object template.
    CK_ATTRIBUTE tExecute[] = {
      {CKA_SAPI_OTP_MECHANISM,    &mech,        sizeof(CK_ULONG)}, 
      {CKA_SAPI_OTP_VALUE,        key,          sizeof(key)     },
      {CKA_SAPI_OTP_COUNTER,      &counter,     sizeof(CK_ULONG)},
    };

    // Server side calculation.
    rv = _SAPI_Server_OTP_Calculate(tExecute, sizeof(tExecute)/sizeof(CK_ATTRIBUTE), Result, &ResultLen);
    if (rv) leave("SAPI_Server_OTP_Calculate failed\n");

    bSuccess = (ResultLen==OTPLen) && (!memcmp(Result, OTP, OTPLen)); // Check result.
  }

  if (!bSuccess) printf("Client/Server OTP mismatch\n");
  else printf("OTP was successfully verified on the server side\n");

  //f_SAPI_OTP_Destroy(hSession);
  fl->C_Finalize(0);
  leave(NULL);
	return 0;
}
