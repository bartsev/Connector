/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#endif

#include "eTPkcs11.h"
#include "eTSAPI.h"

#ifdef _WIN32
#define PKCS11_DLL_NAME		"etpkcs11.dll"
#define ETSAPI_DLL_NAME		"etsapi.dll"
#else
#define PKCS11_DLL_NAME		"libeTPkcs11.so"
#define ETSAPI_DLL_NAME		"libeTSapi.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

// Print message and stop execution.
static void leave(const char * message)
{
  if (message) printf("%s\n", message);
  printf("Press Enter to exit");
  getchar();
  exit(message ? -1 : 0);
}

CK_FUNCTION_LIST_PTR fl = NULL; // PKCS#11 functions list

// Load eTPKCS11 and initialize PKCS#11.
void LoadPKCS11()
{
  HINSTANCE hLib = LoadLibrary(PKCS11_DLL_NAME); 
  if (!hLib) leave("Cannot load eTPkcs11");
  
  CK_C_GetFunctionList f_C_GetFunctionList = NULL;
#ifdef _WIN32
	(FARPROC&)f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&f_C_GetFunctionList= GetProcAddress(hLib, "C_GetFunctionList");
#endif	
  if (!f_C_GetFunctionList) leave("C_GetFunctionList not found");

  if (CKR_OK != f_C_GetFunctionList(&fl)) leave("C_GetFunctionList failed");
  if (CKR_OK != fl->C_Initialize(0)) leave("C_Initialize failed");
}

// SAPI functions declaration.
typedef CK_RV (*t_SAPI_InitToken)(CK_SLOT_ID, CK_ATTRIBUTE_PTR, CK_ULONG, CK_VOID_PTR, CK_INIT_CALLBACK);
t_SAPI_InitToken _SAPI_InitToken = NULL;

// Load eTSAPI and acquire its usable functions.
void LoadETSAPI()
{
  HINSTANCE hLib = LoadLibrary(ETSAPI_DLL_NAME); 
  if (!hLib) leave("Cannot load eTSapi");

	#ifdef _WIN32
  (FARPROC&)_SAPI_InitToken = GetProcAddress(hLib, "SAPI_InitToken");
	#else
	*(void**)&_SAPI_InitToken = GetProcAddress(hLib, "SAPI_InitToken");
	#endif
  if (!_SAPI_InitToken) leave("SAPI_InitToken not found");
}

// Locate an inserted eToken.
CK_SLOT_ID LocateToken()
{
  CK_ULONG nSlots = 1;
  CK_SLOT_ID nSlotID;
  if (CKR_OK != fl->C_GetSlotList(TRUE, &nSlotID, &nSlots)) leave("C_GetSlotList failed");
  if (nSlots<1) leave("No eToken inserted");
  return nSlotID;
}

// Print one dot during initialization process.
CK_RV Progress(CK_VOID_PTR pContext, CK_ULONG progress)
{
  printf(".");
  return 0;
}

int main(int argc, char* argv[])
{
  LoadPKCS11();
  LoadETSAPI();

  CK_SLOT_ID nSlotID = LocateToken();

  int nMaxRetry = 5; // Retry counter for user password.

  // Template for initialization.
  CK_ATTRIBUTE Template[] = {
    {CKA_SAPI_PIN_USER,       (CK_CHAR_PTR)"1234567890",    10   				      }, 
    {CKA_SAPI_RETRY_USER_MAX, &nMaxRetry,                   sizeof(nMaxRetry) },
    {CKA_LABEL,               (CK_CHAR_PTR)"Sample eToken", 13},
  };

  printf("Initialization in progress");
  // Do it!
  CK_RV rv = _SAPI_InitToken(nSlotID, Template, sizeof(Template)/sizeof(CK_ATTRIBUTE), NULL, Progress);
  printf("\n");
  if (rv!=0) leave("SAPI_InitToken failed");

  fl->C_Finalize(0);
  printf("eToken was successfully initialized\n");
  leave(NULL);
	return 0;
}
