/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used content from Windows headers


// Win32
#define _WIN32_WINNT  0x0400
#include <windows.h>
#include <winscard.h>
#include <wincrypt.h>


// STL
#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

// I/O buffer sizes.
#define ET_PROVIDER "eToken Base Cryptographic Provider"
#define ET_PROVIDER_W L"eToken Base Cryptographic Provider"

//Closes PKCS#11 library, displays a message, and terminates the application.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	printf("\n\n");
  printf("Press Enter to exit");
  getchar();
	exit(message ? -1 : 0 );
}

//
// Explanation and command line syntax.
void explanation()
{
  cout<<"Import PFX file certificate to token"<<endl
      <<"------------------"<<endl
      <<"..."<<endl
      <<"..."<<endl<<endl<<endl;        
}

//
//
BOOL OpenContextAndGetKey(CRYPT_KEY_PROV_INFO* pInfo, HCRYPTPROV* phProv, HCRYPTKEY* phRsaKey)
{
  if (!CryptAcquireContextW(phProv, (LPCWSTR)pInfo->pwszContainerName, (LPCWSTR)pInfo->pwszProvName, pInfo->dwProvType, 0)) return FALSE;

  if (!CryptGetUserKey(*phProv, pInfo->dwKeySpec, phRsaKey)) return FALSE;
  return TRUE;
}

//
//
BOOL CreateSessionKey(HCRYPTPROV hProv, HCRYPTKEY* hSessionKey)
{
  HCRYPTHASH hHash;
  char* message = "Password";
  size_t len = strlen(message);
  if(! CryptCreateHash(hProv,CALG_SHA1, 0, 0, &hHash)) return FALSE;
  if(! CryptHashData(hHash, (BYTE*)message, len, 0)) return FALSE;
  if(! CryptDeriveKey(hProv, CALG_RC4, hHash, CRYPT_NO_SALT | (40<<16), hSessionKey)) return FALSE;
  return TRUE;
}

//
//
BOOL ExportRsaKey(HCRYPTPROV hProv, HCRYPTKEY hSessionKey, HCRYPTKEY hRsaKey,vector<BYTE>& KeyBlob)
{
  DWORD BitLen=0; DWORD ParamSize=sizeof(DWORD);
  if (!CryptGetKeyParam(hRsaKey, KP_KEYLEN, (BYTE*)&BitLen, &ParamSize, 0)) return FALSE;
  if (BitLen==0 || (BitLen % 8)) return FALSE;
  DWORD cbKey = BitLen/8;
  if (cbKey>2048) return FALSE;

  DWORD cbBlob = sizeof(BLOBHEADER)+sizeof(RSAPUBKEY)+ cbKey + (cbKey/2)*5 + cbKey;
  KeyBlob.resize(cbBlob);
  if (!CryptExportKey(hRsaKey, hSessionKey, PRIVATEKEYBLOB, 0, &KeyBlob[0], &cbBlob)) return FALSE;
  return TRUE;
}

//
//
int main(int argc, char* argv[])
{
  if (argc < 2 || argc > 3)
  {
    leave("Usage:\n"
          "   ImportPFX  <PFX file name> <PFX password> \n"
          "     Example: ImportPFX 'eToken.pfx' 'password' \n"); 
  }
  cout<<"---------------- ImportPFX Sample -------------------"<<endl;
  

  char* pfx_file_name = argv[1];
  char* pfx_password = NULL;
  if (argc == 3) pfx_password  = argv[2];

  cout<<"Load Certificate from PFX file : "<<pfx_file_name<<endl;
	vector<BYTE> pbData;
	DWORD cbData;
	HANDLE hFile = CreateFile(pfx_file_name, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
  cbData = hFile ? GetFileSize(hFile, NULL) : INVALID_FILE_SIZE;

  if (cbData == INVALID_FILE_SIZE || cbData>0x7fff) 
  {
    leave("Failed to open PFX file ...");
  }
  pbData.resize(cbData);
  DWORD w;
  if(! ReadFile(hFile, &pbData[0], cbData, &w, NULL))
  {
    CloseHandle(hFile);
    leave("Error reading from PFX file ...");
  }

	// Open a temporary store from pfx data
	CRYPT_DATA_BLOB pPFX;
  pPFX.cbData = pbData.size();
	pPFX.pbData = &pbData[0];
  cout<<"Verify PFX Blob and Password ..."<<endl;
  if (!PFXIsPFXBlob(&pPFX)) 
    leave("PFXIsPFXBlob failed...");

	vector<BYTE> pwd;
  WORD emptyPwd = 0;
  bool emptyWithNull = false;
  if(pfx_password)
  {
		int len = MultiByteToWideChar(CP_ACP, 0, pfx_password, -1, NULL, 0);
		pwd.resize(len*sizeof(WCHAR));
		MultiByteToWideChar(CP_ACP, 0, pfx_password, -1, (LPWSTR)&pwd[0], len);

		if (! PFXVerifyPassword(&pPFX,(LPCWSTR)&pwd[0],0))
		{
			if (GetLastError()==ERROR_INVALID_PASSWORD)
				leave("PFXVerifyPassword with password return ERROR_INVALID_PASSWORD ...");
			else
				leave("PFXVerifyPassword with password failed ...");
		}
  }
  else
  {
    // Empty password behavior:
    // Empty password can be zero terminated string or null, defined by pfx creator.
		if (! PFXVerifyPassword(&pPFX,(LPCWSTR)&emptyPwd,0))
    {
			if (! PFXVerifyPassword(&pPFX,NULL,0))
      {
				if (GetLastError()==ERROR_INVALID_PASSWORD)
					leave("PFXVerifyPassword return ERROR_INVALID_PASSWORD ...");
				else
					leave("PFXVerifyPassword failed ...");
      }
      emptyWithNull = true;   
    }
  } 	

  cout<<"Import PFX Blob to store to get certificates and any associated private keys."<<endl;
	HCERTSTORE hStore;	// Certificate store

  if(pfx_password)
  {
    if(!(hStore = PFXImportCertStore(&pPFX,(LPCWSTR)&pwd[0],CRYPT_EXPORTABLE|CRYPT_USER_KEYSET)))
		{
			DWORD rv = GetLastError();
			CloseHandle(hFile);
			leave("PFXImportCertStore with password failed ...");
		}  
  }
  else
  {  
		if(emptyWithNull)
    {
			if(!(hStore = PFXImportCertStore(&pPFX,NULL,CRYPT_EXPORTABLE|CRYPT_USER_KEYSET)))
			{
				DWORD rv = GetLastError();
				CloseHandle(hFile);
				leave("PFXImportCertStore with null failed ...");
			}
    }
    else
    {
			if(!(hStore = PFXImportCertStore(&pPFX,(LPCWSTR)&emptyPwd,CRYPT_EXPORTABLE|CRYPT_USER_KEYSET)))
			{
				DWORD rv = GetLastError();
				CloseHandle(hFile);
				leave("PFXImportCertStore with null terminated string failed ...");
			}
    }
  }

  //Handle to certificate context
  PCCERT_CONTEXT pCertCtx = NULL; 
  CRYPT_KEY_PROV_INFO* pKeyProvInfo = NULL;
  vector<BYTE> KeyProv;
  cout<<"Enumerate certificates in Certificate Store..."<<endl;
  while ((pCertCtx = CertEnumCertificatesInStore(hStore,pCertCtx)) != NULL)
  {    
    DWORD cbData = 0;

    //This sample does not import a CA certificate to the token. The user can save them in the local machine certificate store.
    //CERT_KEY_PROV_INFO_PROP_ID property does not exist in CA Certificates.
    //...
    
    if (!CertGetCertificateContextProperty(pCertCtx, CERT_KEY_PROV_INFO_PROP_ID, NULL, &cbData)) continue;
    KeyProv.resize(cbData);
    if (!CertGetCertificateContextProperty(pCertCtx, CERT_KEY_PROV_INFO_PROP_ID, &KeyProv[0], &cbData)) continue;

    pKeyProvInfo = (CRYPT_KEY_PROV_INFO*)&KeyProv[0];
    break;
  }

  if(!pKeyProvInfo) leave("Certificate not found ...");

  HCRYPTPROV hMSProv;
  HCRYPTKEY  hRsaKey;
  HCRYPTKEY  hMSSessionKey;
  cout<<"Open Context to MS provider and get RSA key handel..."<<endl;
  if (!OpenContextAndGetKey(pKeyProvInfo, &hMSProv, &hRsaKey)) leave("OpenContext failed ...");
  
  cout<<"Create RC4 session key in MS provider context..."<<endl;
  if (!CreateSessionKey(hMSProv, &hMSSessionKey)) leave("CreateSessionKey failed ...");

  vector<BYTE> wrappedKey;
  cout<<"Export RSA key pair by session key..."<<endl;
  if (!ExportRsaKey(hMSProv, hMSSessionKey, hRsaKey, wrappedKey)) leave("ExportRsaKey failed ...");

  HCRYPTPROV hTokenProv;
  cout<<"Open context on token ..."<<endl;
  if(! CryptAcquireContextW(&hTokenProv, (LPCWSTR)pKeyProvInfo->pwszContainerName, ET_PROVIDER_W, PROV_RSA_FULL, CRYPT_NEWKEYSET))
    leave("CryptAcquireContext for token provider failed ...");

  HCRYPTKEY  hTokenSessionKey;
  cout<<"Create same RC4 session key in token context ..."<<endl;
  if (!CreateSessionKey(hTokenProv, &hTokenSessionKey)) leave("CreateSessionKey failed ...");
  
  HCRYPTKEY hKey;
  cout<<"Import wrapped RSA key to token ..."<<endl;
  if(! CryptImportKey(hTokenProv, &wrappedKey[0], wrappedKey.size(), hTokenSessionKey,0, &hKey)) 
    leave("CryptImportKey failed ...");

  cout<<"Set certificate to key handle..."<<endl;
  if(! CryptSetKeyParam(hKey,KP_CERTIFICATE, pCertCtx->pbCertEncoded,0))
    leave("CryptSetKeyParam Failed ...");

  cout<<"Delete RSA key from MS context..."<<endl;
  if (!CryptAcquireContextW(&hMSProv, (LPCWSTR)pKeyProvInfo->pwszContainerName, (LPCWSTR)pKeyProvInfo->pwszProvName, pKeyProvInfo->dwProvType, CRYPT_DELETEKEYSET))
    leave("CryptAcquireContext failed to delete RSA key from Microsoft Key container ...");

  cout<<"Close MS store..."<<endl;
  if (!CertCloseStore(hStore,CERT_CLOSE_STORE_FORCE_FLAG))
    leave("CertCloseStore failed ...");

  cout<<"------------- ImportPFX Sample Success ---------------"<<endl;
  leave(NULL);
  return 0; 
}
