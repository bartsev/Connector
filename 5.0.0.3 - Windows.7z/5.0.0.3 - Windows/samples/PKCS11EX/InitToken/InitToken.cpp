/////////////////////////////////////////////////////////////////////////////
// eToken SDK Sample
// 
//  LICENSE AGREEMENT:
//  1. COPYRIGHTS AND TRADEMARKS
//  The eTokenTM system and its documentation are copyright (C) 1985 to present,
//  by Aladdin Knowledge Systems Ltd. All rights reserved.
//
//  eToken is a trademark and ALADDIN KNOWLEDGE SYSTEMS LTD is a registered trademark 
//  of Aladdin Knowledge Systems Ltd. All  other  trademarks,  brands,  and product 
//  names used in this guide are trademarks of their respective owners.
//
//  2. Title & Ownership
//  THIS IS A LICENSE AGREEMENT AND NOT AN AGREEMENT FOR SALE. 
//  The Code IS NOT FOR SALE and is and shall remain as Aladdin's sole property. 
//  All right, title and interest in and to the Code, including associated 
//  intellectual property rights, in and to the Code are and will remain with Aladdin.
//
//  3.   Disclaimer of Warranty
//  THE CODE CONSTITUTES A CODE SAMPLE AND IS NOT A COMPLETE PRODUCT AND MAY CONTAIN 
//  DEFECTS, AND PRODUCE UNINTENDED OR ERRONEOUS RESULTS. THE CODE IS PROVIDED "AS IS", 
//  WITHOUT WARRANTY OF ANY KIND. ALADDIN DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
//  IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
//  AND FITNESS FOR A PARTICULAR PURPOSE.
//  The entire risk arising out of the use or performance of the Code remains with you.
//
//  4.   No Liability For Damages
//  Without derogating from the above, in no event shall Aladdin be liable for any damages 
//  whatsoever (including, without limitation, damages for loss of business profits, business 
//  interruption, loss of business information, or other pecuniary loss) arising out of the 
//  use of or inability to use the Code, even if Aladdin has been advised of the possibility 
//  of such damages. Your sole recourse in the event of any dissatisfaction with the Code is 
//  to stop using it and return it.
/////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#else
#include "wintypes.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#endif

#include "eTPkcs11.h"

#ifdef _WIN32
#define pkcs11_path 			"etpkcs11.DLL"
#else
#define pkcs11_path				"libeTPkcs11.so"
#define LoadLibrary(lib) 	dlopen(lib,RTLD_NOW)
#define GetProcAddress 		dlsym
#define FreeLibrary(lib) 	dlclose(lib)
typedef void * HINSTANCE;
#endif//_WIN32	

// PKCS#11 functions list.
CK_FUNCTION_LIST_PTR pFunc = NULL; 
// PKCS#11 eToken extended functions list.
ETCK_FUNCTION_LIST_EX_PTR pFuncEx = NULL; 
bool wasInit = false;

// Print message and stop execution.
static void leave(const char * message, int rv=0)
{
  if (message) printf("%s ", message, rv);
	if (rv) printf("rv=%x",rv);
	if(wasInit)
	{
		// Close PKCS#11 library.
		if (CKR_OK != pFunc->C_Finalize(0))
		{
			printf ("C_Finalize failed...\n");
		}
	}
	printf("\n\n");
  printf("Press the Enter key to exit");
  getchar();
  exit(rv);
}

// Load eTPKCS11.dll and initialize PKCS#11.
void LoadPKCS11()
{
	//Dynamic load PKCS#11 library
  HINSTANCE hLib = LoadLibrary(pkcs11_path); 
  if (!hLib) leave("Cannot load etpkcs11");
  
	//Get PKCS#11 function list.
  CK_C_GetFunctionList f_C_GetFunctionList = NULL;
#ifdef _WIN32
  (FARPROC&)f_C_GetFunctionList = GetProcAddress(hLib, "C_GetFunctionList");
#else
	*(void**)&f_C_GetFunctionList = GetProcAddress(hLib, "C_GetFunctionList");
#endif
  if (!f_C_GetFunctionList) leave("C_GetFunctionList not found");

	if (CKR_OK != f_C_GetFunctionList(&pFunc)) leave("C_GetFunctionList failed");

	//Get PKCS#11 eToken extended function list.
	CK_ETC_GetFunctionListEx f_CK_ETC_GetFunctionListEx = NULL;
#ifdef _WIN32
  (FARPROC&)f_CK_ETC_GetFunctionListEx = GetProcAddress(hLib, "ETC_GetFunctionListEx");
#else
	*(void**)&f_CK_ETC_GetFunctionListEx = GetProcAddress(hLib, "ETC_GetFunctionListEx");
#endif
  if (!f_CK_ETC_GetFunctionListEx) leave("ETC_GetFunctionListEx not found");

	if (CKR_OK != f_CK_ETC_GetFunctionListEx(&pFuncEx)) leave("ETC_GetFunctionListEx failed");

  if (CKR_OK != pFunc->C_Initialize(0)) leave("C_Initialize failed");
	wasInit = true;
}

// Locate an inserted eToken.
CK_SLOT_ID LocateToken()
{
  CK_ULONG nSlots = 1;
  CK_SLOT_ID nSlotID;
  if (CKR_OK != pFunc->C_GetSlotList(TRUE, &nSlotID, &nSlots)) leave("C_GetSlotList failed");
  if (nSlots<1) leave("No eToken inserted");
  return nSlotID;
}

//Check if the token supports 2048 key size.
CK_BBOOL Is2048Supported(CK_SLOT_ID	nSlotID)
{
	CK_SESSION_HANDLE	hSession = 0;
	CK_RV			rv = CKR_OK;
	CK_BBOOL	b2048 = CK_FALSE;
	CK_BBOOL	b2048supported = CK_FALSE;

	if(rv=pFunc->C_OpenSession(nSlotID,CKF_RW_SESSION|CKF_SERIAL_SESSION,NULL_PTR,NULL_PTR,&hSession)==CKR_OK)
	{
		
		CK_ULONG dataClass = CKO_HW_FEATURE;
		CK_ULONG fType = ETCKH_TOKEN_OBJECT;
		CK_OBJECT_HANDLE hObject;
		CK_ULONG found = 0;

		CK_ATTRIBUTE tokenAttributes[] = 
		{
			{CKA_CLASS,&dataClass,sizeof(dataClass)},
			{CKA_HW_FEATURE_TYPE,&fType,sizeof(fType)}
		};

		//Find token object.
		if(rv=pFunc->C_FindObjectsInit(hSession,tokenAttributes,sizeof(tokenAttributes)/sizeof(CK_ATTRIBUTE))==CKR_OK)
		{
			if(rv=pFunc->C_FindObjects(hSession,&hObject,1,&found)==CKR_OK)
			{
				if(found != 0)
				{
					CK_ATTRIBUTE tokenAttributes[] = 
					{
						{ETCKA_RSA_2048,&b2048,sizeof(b2048)},
						{ETCKA_RSA_2048_SUPPORTED,&b2048supported,sizeof(b2048supported)}
					};

					//Read attributes from the token object.
					rv = pFunc->C_GetAttributeValue(hSession,hObject,tokenAttributes,2);
				}
			
				rv = pFunc->C_FindObjectsFinal(hSession);

				rv = pFunc->C_CloseSession(hSession);
			}
		}
	}

	if(b2048 && b2048supported)
		return CK_TRUE;

	return CK_FALSE;
}

CK_BBOOL LoginTest(CK_SLOT_ID nSlotID, CK_USER_TYPE type, char* pass, size_t passSize)
{
	CK_RV rv=CKR_OK;
	CK_SESSION_HANDLE	hSession = 0;
	
	if((rv=pFunc->C_OpenSession(nSlotID,CKF_RW_SESSION|CKF_SERIAL_SESSION,NULL_PTR,NULL_PTR,&hSession))==CKR_OK)
	{
		if(rv=pFunc->C_Login(hSession, type,(CK_UTF8CHAR_PTR)pass ,(CK_ULONG)passSize))
		{
			printf("login fail rv=%08x\n",rv);
			return CK_FALSE;
		}
		else
			pFunc->C_Logout(hSession);
	}
	return CK_TRUE;
}
//Check PIN policy object.
CK_BBOOL CheckPinPolicy(CK_SLOT_ID nSlotID)
{
	CK_RV rv=CKR_OK;
	CK_SESSION_HANDLE	hSession = 0;
	CK_OBJECT_HANDLE hObject;
	CK_ULONG found = 0;

	CK_ULONG pinPolicyType = ETCKPT_GENERAL_PIN_POLICY;
	CK_ULONG minPinAge = 0;
	CK_ULONG maxPinAge = 0;
	CK_ULONG warnPeriod = 0;
	CK_ULONG pinLen = 0;
	CK_ULONG historySize = 0;
	CK_BBOOL mixChars = CK_FALSE;

	if((rv=pFunc->C_OpenSession(nSlotID,CKF_RW_SESSION|CKF_SERIAL_SESSION,NULL_PTR,NULL_PTR,&hSession))==CKR_OK)
	{
		CK_ULONG dataClass = CKO_HW_FEATURE;
		CK_ULONG fType = ETCKH_PIN_POLICY;

		CK_ATTRIBUTE tokenAttributes[] = 
		{
			{CKA_CLASS,&dataClass,sizeof(dataClass)},
			{CKA_HW_FEATURE_TYPE,&fType,sizeof(fType)}
		};

		//Find PIN policy object.
		if((rv=pFunc->C_FindObjectsInit(hSession,tokenAttributes,sizeof(tokenAttributes)/sizeof(CK_ATTRIBUTE)))==CKR_OK)
		{
			rv = pFunc->C_FindObjects(hSession,&hObject,1,&found);
			
			rv = pFunc->C_FindObjectsFinal(hSession);
		}
	}

	if(!found)
		return CK_FALSE;

	CK_ATTRIBUTE tmpAttrs[] = 
	{
		{ETCKA_PIN_MIN_AGE,&minPinAge,sizeof(minPinAge)},
		{ETCKA_PIN_MAX_AGE,&maxPinAge,sizeof(maxPinAge)},
		{ETCKA_PIN_WARN_PERIOD,&warnPeriod,sizeof(warnPeriod)},
		{ETCKA_PIN_MIN_LEN,&pinLen,sizeof(pinLen)},
		{ETCKA_PIN_HISTORY_SIZE,&historySize,sizeof(historySize)},
		{ETCKA_PIN_MIX_CHARS,&mixChars,sizeof(mixChars)}
	};

	rv = pFunc->C_GetAttributeValue(hSession,hObject,tmpAttrs,6);
	if(minPinAge == 1 && maxPinAge == 10 && warnPeriod == 5 && pinLen == 4 && historySize == 10 && mixChars == CK_FALSE)
		return CK_TRUE;
	
	return CK_FALSE;
}

int main(int argc, char* argv[])
{
	CK_RV rv=CKR_OK;
  LoadPKCS11();

  CK_SLOT_ID	nSlotID = LocateToken();
	
	if(argc < 6)
  {
    leave("Usage:\n"
          "  InitToken <lable> <user-pass> <user-retry-cnt> <admin-passw> <admin-retry-cnt>\n"
          "  Example: InitToken InitTokenEx 1234567890 15 1234567890 3\n");
  }

	CK_SESSION_HANDLE	hSession = 0;

	CK_BBOOL		is2048 = Is2048Supported(nSlotID);
	char*				lable = argv[1];
	char*				userPass = argv[2];
	size_t			userSize = strlen(userPass);
	long				userCnt = atoi(argv[3]);
	char*				adminPass	= argv[4];
	size_t			adminSize = strlen(adminPass);
	long				adminCnt = atoi(argv[5]);
  
	printf("This sample demonstrates token initialization using the PKCS#11 eToken extended functions\n" );
	printf("Also sets the password policy object\n\n");

  printf("Command line params: \n");
  printf(" Token lable(%s)\n",lable);
	printf(" User password(%s) retry counter(%i)\n", userPass, userCnt);
	printf(" Admin password(%s) retry counter(%i)\n", adminPass, adminCnt);
	printf("\n");
  
	
	CK_ULONG pinPolicyType = ETCKPT_GENERAL_PIN_POLICY;
	CK_ULONG minPinAge = 1;
	CK_ULONG maxPinAge = 10;
	CK_ULONG warnPeriod = 5;
	CK_ULONG pinLen = 4;
	CK_ULONG historySize = 10;
	CK_BBOOL mixChars = CK_FALSE;

	
	if(rv=pFuncEx->ETC_InitTokenInit(nSlotID, (CK_CHAR_PTR)adminPass, (CK_ULONG)adminSize, adminCnt, (CK_CHAR_PTR)lable, &hSession))
		leave("ETC_InitTokenInit failed", rv);

	//Supports 2048 key size.
	if(is2048)
	{
		CK_OBJECT_HANDLE hObject;
		CK_ULONG dataClass = CKO_HW_FEATURE;
		CK_ULONG fType = ETCKH_TOKEN_OBJECT;

		CK_ATTRIBUTE tokenAttributes[] = 
		{
			{CKA_CLASS,&dataClass,sizeof(dataClass)},
			{CKA_HW_FEATURE_TYPE,&fType,sizeof(fType)},
			{ETCKA_RSA_2048,&is2048,sizeof(is2048)}
		};

		if(rv=pFunc->C_CreateObject(hSession,tokenAttributes,sizeof(tokenAttributes)/sizeof(CK_ATTRIBUTE),&hObject))
			printf("Failed to initialize RSA key 2048bit rv=%x\n", rv);
		else
			printf("RSA key 2048bit\n");\
	}

	//PIN policy.
	{
		CK_OBJECT_HANDLE hObject;
		CK_ULONG dataClass = CKO_HW_FEATURE;
		CK_ULONG fType = ETCKH_PIN_POLICY;

		CK_ATTRIBUTE tokenAttributes[] = 
		{
			{CKA_CLASS,&dataClass,sizeof(dataClass)},
			{CKA_HW_FEATURE_TYPE,&fType,sizeof(fType)},
			{ETCKA_PIN_POLICY_TYPE,&pinPolicyType,sizeof(pinPolicyType)},
			{ETCKA_PIN_MIN_AGE,&minPinAge,sizeof(minPinAge)},
			{ETCKA_PIN_MAX_AGE,&maxPinAge,sizeof(maxPinAge)},
			{ETCKA_PIN_WARN_PERIOD,&warnPeriod,sizeof(warnPeriod)},
			{ETCKA_PIN_MIN_LEN,&pinLen,sizeof(pinLen)},
			{ETCKA_PIN_HISTORY_SIZE,&historySize,sizeof(historySize)},
			{ETCKA_PIN_MIX_CHARS,&mixChars,sizeof(mixChars)}
		};

		if(rv=pFunc->C_CreateObject(hSession,tokenAttributes,sizeof(tokenAttributes)/sizeof(CK_ATTRIBUTE),&hObject))
			printf("Failed to set PIN policy object", rv);
		else
		{
			printf("PIN policy settings\n");
			printf("PIN maximum age(%i)\n",maxPinAge);
			printf("PIN minimum age(%i)\n",minPinAge);
			printf("PIN warning period(%i)\n",warnPeriod);
			printf("Minimum PIN length(%i)\n",pinLen);
			printf("Maximum PIN history size(%i)\n",historySize);
			printf("PIN mixed characters(%i)\n",mixChars);
		}

	}
	
	//Initializing user PIN.
	if(rv=pFuncEx->ETC_InitPIN(hSession,(CK_CHAR_PTR)userPass,(CK_ULONG)userSize,userCnt,CK_FALSE))
		leave("ETC_InitPIN failed", rv);

	if(rv=pFuncEx->ETC_InitTokenFinal(hSession))
		leave("ETC_InitTokenFinal failed", rv);

	printf("\n");

	if(LoginTest(nSlotID, CKU_USER, userPass, userSize))
		printf("User login succeeded\n");
	else
		leave("User login failed");

	if(LoginTest(nSlotID, CKU_SO, adminPass, adminSize))
		printf("Administrator login succeeded\n");
	else
		leave("Administrator login failed");

	if(CheckPinPolicy(nSlotID))
		printf("PIN policy test succeeded\n");
	else
		leave("PIN policy test failed");
	
	leave("\nToken initialization succeeded");
}
