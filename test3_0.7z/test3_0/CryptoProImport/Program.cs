﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace CryptoProImport
{
    class Program
    {
        static void Main(string[] args)
        {
            //int cbName;
            //int dwType;
            //int dwIndex;
            //StringBuilder pszName;
            //dwIndex = 0;
            //dwType = 1;
            //cbName = 0;

            //while (CryptoPro.CryptEnumProviders(
            //    dwIndex,         // in -- dwIndex
            //    IntPtr.Zero,     // in -- pdwReserved- устанавливается в NULL
            //    0,               // in -- dwFlags -- устанавливается в ноль
            //    ref dwType,      // out -- pdwProvType
            //    null,            // out -- pszProvName -- NULL при первом вызове
            //    ref cbName       // in, out -- pcbProvName
            //    ))
            //{
            //    //  cbName - длина имени следующего провайдера.
            //    //  Распределение памяти в буфере для восстановления этого имени.

            //    pszName = new StringBuilder(cbName);

            //    //  Получение имени провайдера.
            //    if (CryptoPro.CryptEnumProviders(
            //        dwIndex++,
            //        IntPtr.Zero,
            //        0,
            //        ref dwType,
            //        pszName,
            //        ref cbName     // pcbProvName -- длина pszName
            //        ))
            //    {
            //        Console.WriteLine("{0}, {1}\n", dwType, pszName);
            //    }
            //    else
            //    {
            //        Console.WriteLine("ERROR - CryptEnumProviders");
            //    }

            //} // Конец цикла while
            //Console.ReadKey();  

            const uint PROV_GOST_2001_DH = 75;
            const string Container = "3548da7a8-4d31-2858-6a26-780ebb5a88a";
            const uint ALG_CLASS_HASH = 4 << 13;
            const uint ALG_SID_GR3411 = 30;
            const uint CALG_GR3411 = ALG_CLASS_HASH | ALG_SID_GR3411;
            const uint HP_HASHVAL = 0x0002;
            const uint AT_KEYEXCHANGE = 1;
            const uint AT_SIGNATURE = 2;

            const string Node = "<pkg:PaymentsPackage>" +
                "<pkg:ImportedPayment Id = \"I_09bcf2c6-a08a-4ea2-959d-8e198ba689d9\" paymentId = \"10471020010005232407201700000001\" purpose = \"Штраф\"" + 
                "kbk = \"18811630020016000140\" oktmo = \"45348000\" supplierBillID = \"18817072416285972102\" amount = \"50000\" paymentDate = \"2017-11-24\" transKind = \"01\">" +
                    "<pmnt:PaymentOrg>" +
                        "<org:Bank bik = \"047252006\"/>" +
                    "</pmnt:PaymentOrg>" + 
                    "<pmnt:Payer payerName = \"Антонов Борис Константинович\" payerIdentifier = \"1010000000003751379232\"/>" +
                    "<org:Payee name = \"УВД по ЦАО ГУ МВД России по г. Москве\" inn = \"7706012716\" kpp = \"770901011\">" +
                        "<com:OrgAccount accountNumber = \"40101810800000010041\">" +
                            "<com:Bank bik = \"044583001\"/>" +
                        "</com:OrgAccount>" +
                    "</org:Payee>" +
                    "<pmnt:BudgetIndex status = \"01\" paytReason = \"0\" taxPeriod = \"0\" taxDocNumber = \"01\" taxDocDate = \"0\"/>" +
                        "<pmnt:AccDoc accDocDate = \"2017-11-24\"/>" +
                        "<com:ChangeStatus meaning = \"1\"/>" +
                "</pkg:ImportedPayment>" +
            "</pkg:PaymentsPackage>";

            IntPtr hProv = IntPtr.Zero;
            IntPtr hHash = IntPtr.Zero;
            uint dwDataLen = 0;

            if (!CryptoPro.CryptAcquireContext(ref hProv, Container, null, PROV_GOST_2001_DH, 0))
            {
                Console.WriteLine("CryptAcquireContext Error");
                Console.ReadKey();
                return;
            }

            if (!CryptoPro.CryptCreateHash(hProv, CALG_GR3411, IntPtr.Zero, 0, ref hHash))
            {
                Console.WriteLine("CryptCreateHash Error");
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] encodedBytes = utf8.GetBytes(Node);
            if (!CryptoPro.CryptHashData(hHash, encodedBytes, (uint)encodedBytes.Length, 0))
            {
                Console.WriteLine("CryptHashData Error");
                CryptoPro.CryptDestroyHash(hHash);
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            if (!CryptoPro.CryptGetHashParam(hHash, HP_HASHVAL, null, ref dwDataLen, 0))
            {
                Console.WriteLine("CryptGetHashParam Error");
                CryptoPro.CryptDestroyHash(hHash);
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            byte[] pbData = new byte[dwDataLen];
            if (!CryptoPro.CryptGetHashParam(hHash, HP_HASHVAL, pbData, ref dwDataLen, 0))
            {
                Console.WriteLine("CryptGetHashParam Error");
                CryptoPro.CryptDestroyHash(hHash);
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            uint signatureLen = 0;
            if (!CryptoPro.CryptSignHash(hHash, AT_KEYEXCHANGE, IntPtr.Zero, 0, null, ref signatureLen))
            {
                Console.WriteLine("CryptSignHash Error");
                CryptoPro.CryptDestroyHash(hHash);
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            byte[] signature = new byte[signatureLen];
            if (!CryptoPro.CryptSignHash(hHash, AT_KEYEXCHANGE, IntPtr.Zero, 0, signature, ref signatureLen))
            {
                Console.WriteLine("CryptSignHash Error");
                CryptoPro.CryptDestroyHash(hHash);
                CryptoPro.CryptReleaseContext(hProv, 0);
                Console.ReadKey();
                return;
            }

            Console.WriteLine("{0}\n", dwDataLen);
            CryptoPro.CryptDestroyHash(hHash);
            bool result = CryptoPro.CryptReleaseContext(hProv, 0);
            Console.WriteLine("OK");
            Console.WriteLine("result = {0}\n", result);
            Console.ReadKey(); 
        }
    }

    public class CryptoPro
    {
        [DllImport("advapi32.dll", SetLastError = true)]
            public static extern bool CryptEnumProviders(
            int dwIndex,
            IntPtr pdwReserved,
            int dwFlags,
            ref int pdwProvType,
            StringBuilder pszProvName,
            ref int pcbProvName
        );

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool CryptAcquireContext(
            ref IntPtr hProv, 
            string pszContainer,
            string pszProvider, 
            uint dwProvType, 
            uint dwFlags
        );

        [DllImport("Advapi32.dll", SetLastError = true)]
        public static extern bool CryptReleaseContext(
           IntPtr hProv,
           Int32 dwFlags   // Reserved. Must be 0.
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptCreateHash(
            IntPtr hProv, 
            uint algId, 
            IntPtr hKey, 
            uint dwFlags, 
            ref IntPtr phHash
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptHashData(
            IntPtr hHash, 
            byte[] pbData, 
            uint dataLen, 
            uint flags
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptGetHashParam(
            IntPtr hHash, 
            uint dwParam, 
            byte[] pbData, 
            ref uint dwDataLen, 
            uint dwFlags
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptDestroyHash(
            IntPtr hHash
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptSignHash(
            IntPtr hHash,
            uint keySpec,
            IntPtr description,
            uint flags,
            [Out] byte[] signature,
            [In, Out] ref uint signatureLen
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptGetUserKey(
            IntPtr hProv, 
            uint dwKeySpec, 
            ref IntPtr hKey
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptGetKeyParam(
              IntPtr hKey,
              uint dwParam,
              [Out] byte[] pbData,
              [In, Out] ref uint pdwDataLen,
              uint dwFlags
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptExportKey(
            IntPtr hKey, 
            IntPtr hExpKey, 
            uint dwBlobType, 
            uint dwFlags, 
            [In, Out] byte[] pbData, 
            ref uint dwDataLen
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool CryptDestroyKey(
            IntPtr phKey
        );


    }

}
