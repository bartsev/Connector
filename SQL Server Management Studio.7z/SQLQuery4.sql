USE [CurrRates]
GO

/****** Object:  Table [dbo].[SPB_default_bank]    Script Date: 20.02.2021 11:27:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SPB_default_bank](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[id_doc] [varchar](50) NULL,
	[id_client_] [int] NULL,
	[client_name] [varchar](255) NULL,
	[client_phone] [varchar](50) NULL,
	[client_acc] [varchar](34) NULL,
	[client_card] [varchar](16) NULL,
 CONSTRAINT [PK_SPB_default_bank] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


