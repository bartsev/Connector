﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using CryptoPro.Sharpei;
using CryptoPro.Sharpei.Xml;

namespace test3_0
{
    class Program
    {
        static X509Certificate2 cert;
        const string SERVICE_URL = "http://smev3-d.test.gosuslugi.ru:7500/ws?wsdl"; //разработки
                                  //http://smev3-n0.test.gosuslugi.ru:7500/ws?wsdl;   // тестовый

        static void Main(string[] args)
        {
            cert = LoadCertificate("bartsev@mail.ru");
            XmlDocument xmlRequest = new XmlDocument();
            //            doc.Load("AckRequest.xml");
            xmlRequest.Load("SendRequestRequest_Payments.xml");

            SignXmlFile(xmlRequest, cert, "#I_13032ed0-4a7a-49ed-ad46-2a7206d3bca7", 0);
/*
//            using (XmlTextWriter xmltw = new XmlTextWriter("AckRequest_signed.xml", new UTF8Encoding(false)))
              using (XmlTextWriter xmltw = new XmlTextWriter("SendRequestRequest_signed_1.xml", new UTF8Encoding(false)))
              {
                    xmltw.WriteStartDocument();
                    doc.WriteTo(xmltw);
              }
*/
            SignXmlFile(xmlRequest, cert, "#SIGNED_BY_CONSUMER", 1);
            using (XmlTextWriter xmltw = new XmlTextWriter("SendRequestRequest_Payments_signed.xml", new UTF8Encoding(false)))
            {
                xmltw.WriteStartDocument();
                xmlRequest.WriteTo(xmltw);
            }

            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.PreserveWhitespace = true;

            Console.WriteLine("{0:T} Отправляем запрос exportPaymentReceiver...", DateTime.Now);
            if (!SendSoapRequest(xmlRequest, xmlResponse, "urn:SendRequest", "request_resp.xml"))
            {
                Console.WriteLine("SendSoapRequest fails");
            }

        }

        static bool SendSoapRequest(XmlDocument docRequest, XmlDocument docResponse, string SoapAction, string FileName)
        {

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(SERVICE_URL);
            request.Credentials = CredentialCache.DefaultCredentials;
            request.Headers.Add("SOAPAction", SoapAction);
            request.ContentType = "text/xml;charset=\"utf-8\"";
            request.Method = "POST";
            StreamWriter writer = new StreamWriter(request.GetRequestStream());
            writer.Write(docRequest.OuterXml);
            writer.Close();
            request.GetRequestStream().Flush();
            int err = 0;
            string errDescription = string.Empty;
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException wex)
            {
                err = 10001;
                errDescription = wex.Message;
                response = (HttpWebResponse)wex.Response;
            }

            StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.GetEncoding("utf-8"));
            docResponse.LoadXml(reader.ReadToEnd());
            docResponse.Save(FileName);

            if (err > 0)
            {
                Console.WriteLine("Ошибка при передаче сообщения: " + errDescription);
                return false;
            }
            else
            {
                // Проверяете подпись (я испеользую КриптоПро .NET, пример есть у них на сайте)
                //                VerifyXmlData(respDoc);
                //Обрабатываете результат respDoc.OuterXml
                //можете отправить его, как результат работы вашего wcf сервиса
            }
            response.Close();
            return true;
        }

        static X509Certificate2 LoadCertificate(string subject)
        {
            X509Store store = new X509Store(StoreLocation.CurrentUser);
            store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);
            X509Certificate2Collection certs =
                store.Certificates.Find(X509FindType.FindBySubjectName, subject, false);

            // Проверяем, что нашли ровно один сертификат.
            if (certs.Count == 0)
            {
                Console.WriteLine("Сертификат не найден.");
                Console.ReadKey();
                return null;
            }
            if (certs.Count > 1)
            {
                Console.WriteLine("Найдено более одного сертификата.");
                Console.ReadKey();
                return null;
            }

            return certs[0];
        }

        static void SignXmlFile(XmlDocument XmlDoc, X509Certificate2 Certificate, String uri, int SignatureIndex)
        {

            // Создаём объект SmevSignedXml - наследник класса SignedXml с перегруженным GetIdElement
            // для корректной обработки атрибута wsu:Id. 
            SignedXml signedXml = new SignedXml(XmlDoc);

            // Задаём ключ подписи для документа SmevSignedXml.
            signedXml.SigningKey = Certificate.PrivateKey;

            // Создаем ссылку на подписываемый узел XML. В данном примере и в методических
            // рекомендациях СМЭВ подписываемый узел soapenv:Body помечен идентификатором "body".
            Reference reference = new Reference();
            //            reference.Uri = "#SIGNED_BY_CALLER";
            reference.Uri = uri;   // "#SIGNED_BY_CONSUMER";

            // Задаём алгоритм хэширования подписываемого узла - ГОСТ Р 34.11-94. Необходимо
            // использовать устаревший идентификатор данного алгоритма, т.к. именно такой
            // идентификатор используется в СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            reference.DigestMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete;
            //            reference.DigestMethod = CPSignedXml.XmlDsigGost3411Url;
#pragma warning restore 612

            // Добавляем преобразование для приведения подписываемого узла к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            XmlDsigExcC14NTransform c14 = new XmlDsigExcC14NTransform();
            reference.AddTransform(c14);

            XmlDsigSmevTransform smev =  new XmlDsigSmevTransform();
            reference.AddTransform(smev);


//            XmlDsigEnvelopedSignatureTransform env = new XmlDsigEnvelopedSignatureTransform();
//            reference.AddTransform(env);

            // Добавляем ссылку на подписываемый узел.
            signedXml.AddReference(reference);

            // Задаём преобразование для приведения узла ds:SignedInfo к каноническому виду
            // по алгоритму http://www.w3.org/2001/10/xml-exc-c14n# в соответствии с методическими
            // рекомендациями СМЭВ.
            signedXml.SignedInfo.CanonicalizationMethod = SignedXml.XmlDsigExcC14NTransformUrl;

            // Задаём алгоритм подписи - ГОСТ Р 34.10-2001. Необходимо использовать устаревший
            // идентификатор данного алгоритма, т.к. именно такой идентификатор используется в
            // СМЭВ.
#pragma warning disable 612
            //warning CS0612: 'CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3411UrlObsolete' is obsolete
            signedXml.SignedInfo.SignatureMethod = CryptoPro.Sharpei.Xml.CPSignedXml.XmlDsigGost3410UrlObsolete;
#pragma warning restore 612

            // Вычисляем подпись.
            signedXml.ComputeSignature();

            // Получаем представление подписи в виде XML.
            XmlElement xmlDigitalSignature = signedXml.GetXml();

            // Добавляем необходимые узлы подписи в исходный документ в заготовленное место.
            XmlDoc.GetElementsByTagName("ds:Signature")[SignatureIndex].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignatureValue")[0], true));
            XmlDoc.GetElementsByTagName("ds:Signature")[SignatureIndex].PrependChild(
                XmlDoc.ImportNode(xmlDigitalSignature.GetElementsByTagName("SignedInfo")[0], true));

            // Добавляем сертификат в исходный документ в заготовленный узел
            // wsse:BinarySecurityToken.
            XmlDoc.GetElementsByTagName("ds:X509Certificate")[SignatureIndex].InnerText =
                Convert.ToBase64String(Certificate.RawData);

        }

        // Класс SmevSignedXml - наследник класса SignedXml с перегруженным
        // GetIdElement для корректной обработки атрибута wsu:Id. 
        class SmevSignedXml : SignedXml
        {
            public SmevSignedXml(XmlDocument document) : base(document)
            {
            }

            public override XmlElement GetIdElement(XmlDocument document, string idValue)
            {
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(document.NameTable);
                nsmgr.AddNamespace("wsu", WSSecurityWSUNamespaceUrl);
                return document.SelectSingleNode("//*[@wsu:Id='" + idValue + "']", nsmgr) as XmlElement;
            }
        }

        public const string WSSecurityWSSENamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
        public const string WSSecurityWSUNamespaceUrl = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

    }
}
