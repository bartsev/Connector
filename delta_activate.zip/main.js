const {app, BrowserWindow, Menu, ipcMain, screen} = require('electron');
const {spawn, exec} = require('child_process');
const fs = require('fs');
const axios = require('axios');
const fse = require('fs-extra');
const propertiesReader = require('properties-reader');
const baseDir = process.cwd();

let win;
let postgresPort = `9874`;
const configPath = `${baseDir}/delta.config`;
const localhostUrl = 'http://localhost';

//Настраиваемые параметры/////////////////////////////////////
let deltaPort = `8080`;
let homePage = localhostUrl + ':' + deltaPort;

//переменные параметров подключения к БД
let deltaDbDriver;
let deltaDbUrl;
let deltaDbUsername;
let deltaDbPassword;
let deltaDbStartpostgresql = `yes`;
let deltaDBSeparate;

process.env['pgport'] = postgresPort;


const postgresEnginePath = `${baseDir}/backend/sqldb/bin/`;
const postgresDataPath = `${baseDir}/backend/sqldb/data/`;
const postgresLogFile = `${baseDir}/backend/sqldb/serverlog.log`;
const javaPath = `${baseDir}/backend/jdk/bin/`;
const jarPath = `${baseDir}/backend/delta.jar`;
const backendPath = `${baseDir}/backend`;
const updateDeltaBackEndPath = `${baseDir}/backend/update/delta.jar`;

const dbErrorLogFile = 'db-error.log';
const serverErrorLogFile = 'server-error.log';
const dbOutLogFile = 'db-out.log';
const serverOutLogFile = 'server-out.log';

let scale = 0.34;

const xmxPath = `${baseDir}/backend/xmx.setting`;
const winWidth = 531;
const winHeight = 293;
const ratio = winWidth / winHeight;

let isSuccessfulStart = false;
let isStoppingApp = false;

postgresPortIsBusy = () => {
    let postgresCheckPort = spawn(`pg_isready`, ['-p', postgresPort], {cwd: postgresEnginePath});

    postgresCheckPort.stderr.on('data', data => {
        fs.writeFileSync(dbErrorLogFile, data);//'postgresIsBusyLog.log', data);
    });

    return new Promise((resolve, reject) => {
        postgresCheckPort.on('exit', (code) => {
            resolve(code);
        });
    });
};

startPostgresDB = () => {
    let postgresStartResult = exec(`pg_ctl -D "${postgresDataPath}" -t 600 -l "${postgresLogFile}" start`, {cwd: postgresEnginePath});

    postgresStartResult.stderr.on('data', data => {
        fs.writeFileSync(dbErrorLogFile, data); //'startPostgresDBError.log', data);
    });

    postgresStartResult.stdout.on('data', data => {
        fs.writeFileSync(dbOutLogFile, data);//'startPostgresDBOut.log', data);
    });

    return new Promise((resolve, reject) => {
        postgresStartResult.on('exit', (code) => {
            resolve(code);
        });
    });
};

startJavaServer = () => {
	if(fse.pathExistsSync(updateDeltaBackEndPath))	{
		fse.moveSync(updateDeltaBackEndPath, jarPath, { overwrite: true })
	}

    process.env.Path = `${javaPath};` + process.env.Path;

    let xmx = '2G';
	
    try {
		fs.accessSync(`${xmxPath}`, fs.constants.R_OK);
		xmx = fs.readFileSync(`${xmxPath}`, 'utf8');
		
	} catch (e) {	

        try {
            fs.writeFileSync(`${xmxPath}`, xmx, 'utf8');
		
        } catch (writeError) {};
      
    }
    let javaStartResult;
    //если заданы параметры подключения к БД - используем их
	const javaParameters = ['-jar', `${jarPath}`, `-Xmx${xmx}`, `--server.port=${deltaPort}`];

    if (deltaDbDriver && deltaDbUrl  && deltaDbUsername && deltaDbPassword) {
        javaParameters.push(
            `--delta.db.url=${deltaDbUrl}`,
            `--delta.db.username=${deltaDbUsername}`,
            `--delta.db.password=${deltaDbPassword}`,
            `--delta.db.driver=${deltaDbDriver}`);
    }

    if (deltaDBSeparate) {
        javaParameters.push(`--delta.db.separate=${deltaDBSeparate}`);
    }

    javaStartResult = spawn(`java`, javaParameters, {cwd: backendPath});


    javaStartResult.stderr.on('data', data => {
        fs.writeFileSync(serverErrorLogFile, data); // 'startJavaServerError.log', data);
    });

    let successPromise = new Promise((resolve, reject) => {
        javaStartResult.stdout.on('data', (data) => {
            fs.writeFileSync(serverOutLogFile, data ); //'startJavaServerStdOut.log', data);
            resolve(javaStartResult.pid);
        })
    });

    let errorPromise = new Promise((resolve, reject) => {
        javaStartResult.on('exit', (code) => {
            resolve(code);
        });
    });

    return Promise.race([successPromise, errorPromise]);
};

pingServer = () => {
	axios.get(homePage +'/ping/')
        			.then(async response => {						
            		if (response.data.resultCode === 0) {
                //fs.writeFileSync('serverResponse.log', response.data.resultCode);
						if (isStoppingApp) {
							await stopApp();
							setTimeout(() => {app.quit()}, 2000);
						} else {
                    //fs.writeFileSync('serverPing.log', 'open!');
						win.setResizable(true);
                //win.setMinimumSize(1280, 1024);
						win.setMinimumSize(1280, 768);
						win.maximize();
						isSuccessfulStart = true;			
							
						//await win.loadURL(homePage + '/index.html');
						await win.loadURL(homePage);  // Путь при авторизации по LDAP должен быть к главной странице по умолчанию
						}
            		} // else fs.writeFileSync('serverResponse.log', response.data.resultCode);
        		}).catch(error => {
					
            //fs.writeFileSync('serverError.log', i.toString() + ': ' + error.toString());
            //i++;
            //if (error.code === 'ECONNREFUSED' || error.code === 'ENOTCONN') {
				setTimeout(() => {pingServer()}, 2000);
                // return pingServer(win);
            //}
     }); // setTimeout
		
	 // while	
}

readConfig = () => {
    if (fs.existsSync(configPath)) {
        const props = propertiesReader(configPath, 'utf-8', {allowDuplicateSections: true});
        const serverPortConfig = props.get('server.port');
        if (serverPortConfig) {
            deltaPort = serverPortConfig;
            homePage = localhostUrl + ':' + deltaPort;
        }
        //считываем параметры БД
        deltaDbDriver = props.get('delta.db.driver');
        deltaDbUrl = props.get('delta.db.url');
        deltaDbUsername = props.get('delta.db.username');
        deltaDbPassword = props.get('delta.db.password');
        //если заданы параметры БД, то предполагается, что запуск своей БД postgresql не требуется
        if (deltaDbDriver && deltaDbUrl  && deltaDbUsername && deltaDbPassword) {
            deltaDbStartpostgresql = 'no';
        }
        //явно считываем опцию запуска postgress (если по какой-то причине все-таки нужен запуск БД)
        const deltaDbStartpostgresqlConfig = props.get('delta.db.startpostgresql');
        if (deltaDbStartpostgresqlConfig) {
            deltaDbStartpostgresql = deltaDbStartpostgresqlConfig;
        }
        //считываем параметр раздельной БД для расширения (при активации этой опции используется встроенная БД)
        deltaDBSeparate = props.get('delta.db.separate');

    }
}

createWindow = async () => {
	readConfig();
    win = new BrowserWindow({
        webPreferences: {
            nodeIntegration: true,
            backgroundThrottling: false
        },
        movable: true,
        frame: false,
        icon: __dirname + '/img/DeltaLogo.ico'
    });

    win.on('close', function () {
        if (isSuccessfulStart) {
            forceStopPostgresDB();
            stopApp();
        }
        if (process.platform !== 'darwin') {
            app.quit()
        }
    });
    win.on('closed', function () {
        if (isSuccessfulStart) forceStopPostgresDB();
        win = null;
        process.exit(0);
        // if (isSuccessfulStart) stopApp();
    });

    if (screen.getPrimaryDisplay().size.height >= 768 && screen.getPrimaryDisplay().size.height < 1080)
    	scale = (232.8 - 0.09999998 * screen.getPrimaryDisplay().size.height) / 312;
    else if (screen.getPrimaryDisplay().size.height >= 1080) scale = (529.2 - 0.09 * screen.getPrimaryDisplay().size.height) / 1080;
    	
    const width = Math.round(screen.getPrimaryDisplay().size.width * scale);
    const height = Math.round(width / ratio);

    win.setSize(width, height);
    win.setResizable(false);
    win.center();

    await win.loadURL(`${app.getAppPath()}/html/_db.html`);//win.loadURL(`${app.getAppPath()}/html/_database.html`);//win.loadURL(`${app.getAppPath()}/html/load-postgres.html`);

    //проверяем необходимость запуска postgresql
    if (deltaDbStartpostgresql==='yes') {
        //проверяем доступность порта
        let postgresPortIsBusyResult = await postgresPortIsBusy();

        if (postgresPortIsBusyResult === 2) {
            let startPostgresDBResult = await startPostgresDB();

            if (startPostgresDBResult === 0) {

                if (!isStoppingApp) {
                    await win.loadURL(`${app.getAppPath()}/html/_srv.html`); //win.loadURL(`${app.getAppPath()}/html/_server.html`);//win.loadURL(`${app.getAppPath()}/html/load-server.html`);
                    let startJavaServerResult = await startJavaServer();

                    if (startJavaServerResult !== 1) {
                        pingServer();
                    } else {
                        if (deltaDbStartpostgresql==='yes') {
                            await stopPostgresDB();
                        }
                        await win.loadURL(`${app.getAppPath()}/html/_java-err.html`); //win.loadURL(`${app.getAppPath()}/html/_java-error.html`); // win.loadURL(`${app.getAppPath()}/html/java-launch-error.html`);
                        setTimeout(() => {
                            app.quit();
                        }, 	10000);
                    }
                } else {
                    if (deltaDbStartpostgresql==='yes') {
                        await stopPostgresDB();
                    }
                    setTimeout(() => {app.quit()}, 2000);
                }
            } else {
                await win.loadURL(`${app.getAppPath()}/html/_db-err.html`);//win.loadURL(`${app.getAppPath()}/html/_database-error.html`); //win.loadURL(`${app.getAppPath()}/html/postgres-launch-error.html`);
                setTimeout(() => {
                    app.quit();
                }, 10000);
            }
        } else {
            await win.loadURL(`${app.getAppPath()}/html/_port-err.html`);//win.loadURL(`${app.getAppPath()}/html/_port-error.html`);//win.loadURL(`${app.getAppPath()}/html/postgres-port-is-busy.html`);
            setTimeout(() => {
                app.quit();
            }, 10000);
        }

    } else {
        //продолжаем запуск приложения
        if (!isStoppingApp) {
            await win.loadURL(`${app.getAppPath()}/html/_srv.html`); //win.loadURL(`${app.getAppPath()}/html/_server.html`);//win.loadURL(`${app.getAppPath()}/html/load-server.html`);
            let startJavaServerResult = await startJavaServer();

            if (startJavaServerResult !== 1) {
                pingServer();
            } else {
                await win.loadURL(`${app.getAppPath()}/html/_java-err.html`); //win.loadURL(`${app.getAppPath()}/html/_java-error.html`); // win.loadURL(`${app.getAppPath()}/html/java-launch-error.html`);
                setTimeout(() => {
                    app.quit();
                }, 	10000);
            }
        } else {
            //await stopPostgresDB();
            setTimeout(() => {app.quit()}, 2000);
        }

    }

}

app.on('ready', async () => {
    await createWindow();
});

app.on( 'child-process-gone',  async function (event, killed) {
    if (isSuccessfulStart) {
        await forceStopPostgresDB();
    }
    //if (process.platform !== 'darwin') {
    //    app.quit()
    //}
});

process.on('SIGTERM', () => {
    fs.writeFileSync('sigterm.log', 'term');
});

app.on( 'render-process-gone',  async function (event, contents) {
    if (isSuccessfulStart) {
        await forceStopPostgresDB();
    }
    //if (process.platform !== 'darwin') {
    //    app.quit()
    //}
});

forceStopPostgresDB = async () => {
    let postgresStopResult = exec(`pg_ctl -D "${postgresDataPath}" stop`, {cwd: postgresEnginePath});
}

stopPostgresDB = async () => {
    let postgresIsActive = await postgresPortIsBusy();

    if (postgresIsActive === 0) {
        let postgresStopResult = exec(`pg_ctl -D "${postgresDataPath}" -t 600 stop`, {cwd: postgresEnginePath});

        postgresStopResult.stderr.on('data', data => {
            fs.writeFileSync(dbErrorLogFile, data); // 'stopPostgresDBError.log', data);
        });

        postgresStopResult.on('exit', (code) => {
            fs.writeFileSync(dbOutLogFile, code); //'stopPostgresDBResult.log', code);
        });
    }
};

stopJavaServer = async () => {
    let ping = await axios.get(homePage + '/ping/');

    if (ping.data.resultCode === 0) {
        try {
            let stopJavaResult = await axios.get(homePage + '/app/stop/');
        } catch (e) {

        }
    }
};

app.on('window-all-closed', async function () {
	await stopApp();
    if (process.platform !== 'darwin') {
        app.quit()
    }
});

app.on('activate', async function () {
    if (win === null) {
        await createWindow()
    }
});

ipcMain.on('close-app', async (event, arg) => {
    event.returnValue = "received";
	await stopApp();
    app.quit();
});

ipcMain.on('open-console', (event, arg) => {
    event.returnValue = 'received';
    win.webContents.openDevTools();
});

ipcMain.on('update-app', async (event, arg) => {
    event.returnValue = "received";
	await stopApp();
    exec(`start update-tool.cmd`, {cwd: arg});
    
    app.quit();
});

stopApp = async () => {
	await stopJavaServer();
    if (deltaDbStartpostgresql==='yes') {
        await stopPostgresDB();
    }
    await win.webContents.session.clearStorageData();
    await win.webContents.session.clearCache();
};


ipcMain.on('break-app', async (event, arg) => {
    event.returnValue = "received";
    isStoppingApp = true;
    await win.loadURL(`${app.getAppPath()}/html/_shutdown.html`);
});

ipcMain.on('base-url', async (event) => {
   event.returnValue = homePage;
});

ipcMain.on('base-port', async (event) => {
    event.returnValue = deltaPort;
});
